# Surface textures

CC0 (public domain) scans from Poly Haven — https://polyhaven.com/textures
Bundled here at 512 px so the skill works offline; `scripts/fetch_textures.py`
upgrades them to 1K when the network allows. No attribution is required by the
licence; this file records the source anyway.

| id | used for |
|---|---|
| `rock_wall_08` | stone walls, tunnels, ruins |
| `cobblestone_floor_08` | ground, streets, yards |
| `dark_wooden_planks` | timber, crates, beams, carts |
| `green_metal_rust` | iron, rails, hardware, armour |
