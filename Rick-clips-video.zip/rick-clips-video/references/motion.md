# Motion — camera, rig, timing, locomotion, actions

## Contents

- [D. Animation & camera (2D puppets in a 3D world)](#d-animation--camera-2d-puppets-in-a-3d-world)
- [D.1 Camera language](#d1-camera-language)
- [D.2 The rig (build once per character, reuse forever)](#d2-the-rig-build-once-per-character-reuse-forever)
- [D.3 Timing & principles (30fps frame counts)](#d3-timing--principles-30fps-frame-counts)
- [D.4 Locomotion](#d4-locomotion)
- [D.5 Action library (interactions that must feel real)](#d5-action-library-interactions-that-must-feel-real)
- [D.6 Face, speech & idle](#d6-face-speech--idle)
- [D.7 Continuity across cuts](#d7-continuity-across-cuts)

### D. Animation & camera (2D puppets in a 3D world)

Everything the characters do must be **physically plausible**: weight shifts, contacts, anticipation, follow-through. A viewer should never think "that's a sticker sliding".

#### D.1 Camera language
**Framing ladder:** extreme wide establishing → wide group → medium 2–3 characters → close-up (head 30–45% of frame) → prop ECU.
**Angles:** eye-level, low hero angle, high angle over a crowd, over-the-shoulder, symmetric frontal, top-down aerial.
**Moves:** slow push-in (most common), lateral truck, crane up, short orbit, whip-pan on action, locked-off with subject motion.
**Rules:** one move per shot; constant velocity on dollies (no ease), ease-out only when the move stops; handheld drift 1–2px; never orbit a flat cutout more than ~15°.

**Camera is applied to the composite, in this order (executable):**

```python
from math import sin, pi
W, H, TAU = 1080, 1920, 2 * pi

def camera_at(frame, frames, kind, amount=0.06):
    u = frame / max(1, frames - 1)
    v = u if u <= 0.85 else 0.85 + 0.15 * (1 - (1 - (u - 0.85) / 0.15) ** 2)  # ease-out tail
    if kind == "push_in": return 1 + amount * v, 0, 0        # zoom about the feet
    if kind == "truck":   return 1, (0.5 - v) * amount * 2 * W, 0
    if kind == "crane":   return 1, 0, (v - 0.5) * amount * 1.2 * H
    if kind == "handheld":return 1, 1.5 * sin(TAU * u * 3), 1.2 * sin(TAU * u * 2 + 1)
    return 1, 0, 0
```

1. **Actors** get one group transform: `translate(dx,dy) · translate(ax,ay) · scale(z) · translate(-ax,-ay)` with the anchor `(ax,ay)` on the **feet line**. Never scale an actor about the frame centre — the feet lift off the ground and the contact shadow detaches.
2. **Plate** gets a *fraction* of the same move (`zoom ×0.55`, `shift ×0.35`) and is cropped back to 1080×1920. If the plate moves as much as the actors there is no parallax and the push-in reads as a zoom lens, not a dolly.
3. **Foreground plane** gets *more* than the actors (`zoom ×1.75`, `shift ×1.45`) — nearest to the lens moves most. This is what sells depth during the move; without it the three layers slide as one flat picture.
4. **Shadows** are transformed with the actors, and their blur radius scales with `z`, or they slide out from under the feet.
5. **Captions do not move.** They are composited last, in screen space.
6. **Verify the move numerically:** zoom is monotonic per frame, ends exactly on its declared amount, and truck travel is symmetric. A camera that eases in, overshoots or stalls is a bug, not a style.

#### D.2 The rig (build once per character, reuse forever)
A character is a **hierarchy of flat parts with pivots**, not one image:

```
root (x, y, scale, facing)
└─ hips
   ├─ torso (lean/rotate)
   │  ├─ far arm: upper → fore → hand → prop socket
   │  ├─ near arm: upper → fore → hand → prop socket
   │  └─ head (x/y offset, tilt) → brows, eyes, mouth (swap layers)
   ├─ far leg: thigh → shin → foot
   └─ near leg: thigh → shin → foot
```

- **Pivot points:** shoulder at the top of the upper arm, elbow mid-arm, hip at the top of the thigh, knee mid-leg, ankle at the foot. Draw each part so its pivot is at the local origin.
- **Z-order:** far arm behind torso, near arm in front, far leg behind near leg. Two exceptions that must be dynamic, not fixed: an arm that swings **backwards** is drawn behind the torso (else it paints a black stripe across the chest), and the arm that **touches another actor** is drawn after every body so the hand lands on the chest it pushes rather than behind it.
- **Outline:** draw the black outline **on each part** (0.9–1.1% of character height, floored at 2px) so it stays correct when limbs rotate. Never rely on a whole-body outline filter.
- **Hand sockets:** every prop is parented to a hand socket so it cannot drift; transfer the parent at the contact frame. A prop's local **+y axis runs away from the hand** (the hammer head is at +y), so the prop's rotation is simply the forearm's absolute angle — no manual offsets, no props pointing backwards.
- **Prop orientation:** props that must stay world-vertical (flag, lantern, torch) take an absolute angle of 0 instead of the forearm angle. Everything else inherits the arm.
- **Face:** separate eye/brow/mouth layers swapped or morphed — never redraw the head per expression.
- **Scale:** the rig is built in **px at its own height** (330 wide / 700 medium / 1400 close-up) and scaled per shot; never rescale individual parts.

**Auto-plant (mandatory, and the single biggest "it floats" fix).** Authoring legs by angle always leaves the hips at the wrong height: a walk cycle naturally rises and falls ~6–16px. After solving the skeleton, take the lowest foot and translate the root vertically so that foot sits exactly on the ground line:

```python
low = max(foot_l.y, foot_r.y)
root.y += ground_y - low
```

- Run it **every frame**, not once per shot.
- Run it **before** any contact solve, so IK aims at where hands will actually be.
- Do **not** plant airborne frames (fall, jump, thrown): gate it on `bob` or an explicit `grounded: false`.
- Author `bob` as art direction *on top of* the planted result; never use `bob` to fix a bad leg angle.
- The verify harness proves both halves: unplanted walk float must be >0px, planted ground spread must be ≤0.5px.

**Contact by IK, never by sliding the actor.** When two characters touch, do not nudge one of them across the floor to make the hands meet — that shears the feet and the contact shadow. Solve the *arm*:

```python
# two-bone IK: shoulder -> target, elbows bend backwards
u = (target.x - shoulder.x) * facing      # forward +
v = target.y - shoulder.y                 # down +
d = clamp(hypot(u, v), |L1-L2|+0.5, L1+L2-0.5)
theta = atan2(u, v)
alpha = acos((d² + L1² - L2²) / (2·d·L1))
sh = theta - alpha                        # elbow behind the line
el = angle(elbow→target) - sh
```

Rules that make this look real:
- **Both** actors IK onto **one shared grip point** (the midpoint of the pair at chest height). Solving only one side produces a limp, half-extended arm.
- Report the **reach ratio** `d / (L1+L2)`. Keep it **≤0.92**: a locked-straight arm reads as a mannequin. If it is above that, move the actors closer — never lengthen the arm.
- Set the pair's spacing per action (handshake ≈2.15 torso widths, hand-off ≈1.95, push ≈1.75). Wide spacing is the usual cause of a ratio above 1.
- Grip point travels: idle → out to the midpoint by the contact frame → holds with a 2–3px compression pulse → returns. IK weight ramps 0→1 across that, so the arm never snaps.
- Timing: contact frame is exact; the *reaction* starts 2–4 frames later on the receiving actor only.

#### D.3 Timing & principles (30fps frame counts)
| Beat | Frames | Notes |
|---|---|---|
| Anticipation | 4–8 | opposite direction, small |
| Action / strike | 2–4 | fastest part, 1–2 frames of blur if needed |
| Overshoot | 1–2 | 3–8% past the target |
| Settle | 6–10 | ease-out, one small bounce |
| Hold | 2–6 | readable pose, no micro-jitter |
| Reaction delay | 2–4 | after the cause, never simultaneous |
| Full gesture | 12–20 | e.g. point, wave, shrug |

- **Ease everything** except constant-velocity dollies: `easeOut` on stops, `easeInOut` on gestures, `easeIn` on wind-ups.
- **Arcs:** hands and props travel on curves, never straight lines (except a punch/stab).
- **Squash & stretch:** 3–8% on impacts and take-offs, 0 on held poses.
- **Overlapping action:** head, hat, coat and prop lag the torso by 1–2 frames; they settle last.
- **Weight:** heavy = slower anticipation, faster fall, bigger settle; light = snappy, floaty, small settle.
- **No twinning:** left and right limbs never mirror exactly; offset by 2–4 frames.
- **Feet own the motion:** a planted foot does not slide. Root motion must equal stride length.

#### D.4 Locomotion
| Action | Cycle | Key poses | Rules |
|---|---|---|---|
| Idle | 60–90f loop | neutral → weight shift → neutral | breathing ±1–2px, blink every 2–4s, occasional look-off |
| Walk | 12f (slow 16, brisk 10) | contact → down → passing → up ×2 | hip bob 2–4px, shoulder counter-rotate 4–6°, opposite arm swing, heel-to-toe |
| Run | 8f | contact → down → push → flight | 4–6px bob, forward lean 8–12°, arms bent 90° |
| Turn | 8–12f | plant → pivot → settle | head leads by 2f, feet re-plant, no sliding pivot |
| Sit / stand | 16–24f | anticipation → lower → settle | hands reach back, weight on feet, torso leans forward |
| Stairs / ladder | 10–14f per step | reach → pull → step | hand and foot alternate, body rises smoothly |
| Carrying | walk variant | both arms fixed to the prop | prop stays level, hips lead |

**Foot planting:** in world space the contact foot's x is constant during stance. If the root moves 60px over 4 frames, the leg angles change to absorb it — never translate the whole character with the foot glued to the sprite.

**Front-on walk (the rig has no depth axis).** Hip swing is a horizontal angle, so a 24° stride on a front-facing character *scissors the legs through each other*. For front-on/¾-front views: hip swing **≤10°**, knee lift **20–24°**, body bob 3px, shoulder counter-swing ≤7°. Big 20–30° strides only read in a profile view. Test at thumbnail size — if the legs make an X, the swing is too big.

**Arm depth follows the swing.** A backward-swinging arm is drawn *behind* the torso, a forward one *in front*; fixing the layer order per character paints a black stripe across the chest on every alternate step. Decide per arm, per frame: `sh < 0 → behind`.

#### D.5 Action library (interactions that must feel real)
Every action = **anticipation → contact → force → reaction → settle**. Contact happens on one exact frame; both actors and the prop agree on it.

| Action | Frames | Key beats | Physics rules |
|---|---|---|---|
| Handshake | 18–24 | reach 6–8 · grip 2 · 2–3 shakes of 5–6 · release 4–6 | hands meet at one point, 2–3px compression on grip, taller actor leans 2–3°, both settle after release |
| Hand-off / give object | 14–20 | extend 6 · contact 2 · transfer 1 · withdraw 6 | prop parent switches on the contact frame; receiver's hand closes 1 frame before the giver lets go |
| Push | 16–22 | plant 4 · lean 6 · drive 6 · recover 6 | feet staggered, back leg straight, torso 10–15°, object moves only after contact |
| Pull | 16–22 | grip 2 · lean back 6 · haul 6 · stumble 4 | weight shift backwards, object lags 1–2 frames behind the hands |
| Lift | 20–28 | squat 8 · grip 2 · stand 8 · settle 4 | back straight-ish, knees bend, object rises with the hips, small wobble on top |
| Hammer / strike | 14–18 | raise 6 · hold 2 · strike 2 · recoil 4 · settle 4 | impact frame = 1-frame freeze + 2f shake of the struck object, dust puff |
| Dig / shovel | 20–26 | stab 4 · scoop 6 · lift 6 · toss 6 | tool enters the ground, resistance on the scoop, arc on the toss |
| Throw | 18–24 | wind-up 8 · release 2 · follow-through 8 | opposite foot forward, torso rotates 15–25°, released hand opens on the release frame |
| Catch | 8–12 | reach 4 · close 1 · absorb 4 | hand meets the object's path, slight give on impact |
| Light a fuse | 16–20 | strike 4 · cup 4 · touch 4 · recoil 4 | flame/smoke starts on the touch frame, hand shields it |
| Point | 10–14 | raise 6 · hold 4 | arm straight, eyeline follows the hand, torso twists 3–5° |
| Shrug | 10–12 | raise 4 · hold 3 · drop 4 | shoulders up 4–6px, brows lift, palms turn up |
| Nod | 8–10 | down 3 · hold 2 · up 4 | head only, 4–6° max, never the whole torso |
| Fall | 12–18 | stagger 4 · drop 8 · impact 2 · settle 4 | gravity accelerates, no easing on the drop, 1-frame squash on impact |
| Hit / recoil | 10–14 | impact 1 · recoil 6 · recover 6 | reaction opposite the force, hat/hair lag 2f, 2-frame freeze on impact |
| Row / pump | 16–20 loop | catch · drive · recover | body leans with the stroke, tool stays in contact with the medium |
| Pour / inspect | 14–20 | lift 4 · tilt 6 · hold 6 | fluid/contents follow gravity, magnifier hand steady 2f before the reveal |
| Count / sort | 8f per item | pick · move · place | fingers contact each item, items stack with a tiny settle |

**Two-character contact:** decide the contact frame first, then work backwards for the reach and forwards for the reaction. Both actors must be on screen for the contact frame (or use a cut exactly on it).

**Above-head actions (hammer, overhead throw, axe, raising a flag)** are the one place this rig fights back: the head is a third of the body, so an arm swung past ~140° disappears behind it. Swing out to **120–140°** and let the **prop** carry the height (the hammer head, not the hand, is the silhouette), or cut to a 3/4 framing where the arm passes *beside* the head. Never let a limb cross the face.

#### D.6 Face, speech & idle
- **6 mouth shapes** (closed, small, wide, round, teeth, frown) at 6–8 changes/second, synced to the VO's word timings.
- **Blinks:** 2 frames, every 2–4s, occasional double-blink; never on a stressed word.
- **Brows:** key on emphasised words only (max 1 per 6–8 words), 3-frame transitions.
- **Eyes:** micro-darts every 1–2s, look at what the character is acting on (never off-screen for no reason).
- **Head:** 1–2px bob on emphasis, 3–6° tilt for curiosity, counter-rotate on turns.
- **Idle always on:** breathing sway, weight shift, a small hand adjustment — no character is ever frozen for >2.5s.

#### D.7 Continuity across cuts
- **Pose matching:** the last pose of shot N equals the first pose of shot N+1 when the action continues (or cut mid-action and mirror the pose).
- **Screen direction:** a character moving left keeps moving left across the cut unless the story turns them.
- **Eyeline:** consistent look direction; don't cross the line between two characters.
- **Prop hand:** the same hand holds the prop before and after a cut.
- **State:** wet/dry, clean/dirty, hat on/off, injuries — tracked per scene in `characters.json`.
- **Action match on cut:** cut on the fastest frame of the action (strike/impact), not mid-settle.
