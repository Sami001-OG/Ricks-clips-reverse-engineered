# The 3D world — quality contract

## Contents

- [C. The 3D world (quality spec — this is the constant)](#c-the-3d-world-quality-spec--this-is-the-constant)
- [C.1 Materials & texture](#c1-materials--texture)
- [C.2 Weather & atmosphere](#c2-weather--atmosphere)
- [C.3 Light & colour (colour comes from light, not from tinting)](#c3-light--colour-colour-comes-from-light-not-from-tinting)
- [C.4 Depth & staging](#c4-depth--staging)
- [C.5 Post & grade](#c5-post--grade)
- [C.6 Reference environments (same grammar, other worlds)](#c6-reference-environments-same-grammar-other-worlds)
- [C.7 World QA (measure, don't vibe)](#c7-world-qa-measure-dont-vibe)

### C. The 3D world (quality spec — this is the constant)

The world carries the production value. Characters are flat; **everything behind them must look like a real, weathered, physically lit 3D set**. Think low-budget cinematic game environment, not clip-art.

**Non-negotiable contrast:** semi-realistic 3D background (PBR materials, real shadows, atmosphere) + flat 2D-style outlined characters. Never unify the two styles.

#### C.0 How a plate is built here (read before stage 4)

No image model, no GPU. The plate is a small 3D scene rendered on the CPU by `scripts/plate3d.py`:
photographic CC0 surface scans, a key/fill rig with real shadow maps, screen-space occlusion, and a
film post stack (haze, bloom, depth of field, grain, chromatic offset, vignette, split tone).
12–45 s for 1080×1920 depending on primitive count, deterministic, seeded.

What that buys, and what it does not:

- **Surfaces are photographic** — scanned stone, timber and rust, tiled at 0.5–1.6 m per repeat. This
  is the cheapest realism in the whole pipeline: a scan costs a file read, not a render.
- **Light is rasterised, not path-traced.** There is no bounce light and no soft area shadow. The
  plate reads *cinematic 3D*, not photograph — that is the accepted bar, and the honest ceiling.
- **Composition carries the rest:** one shadow direction, contact under every prop, atmosphere that
  increases with distance, and grain. Resolution buys almost nothing here; these buy everything.
- **No photographic backplate is used.** Geometry is built from the spec, never borrowed from an image.
- **Material follows the maker.** Scans for stone, timber, rust; `{"solid": true}` for anything manufactured — panels, seats, carpet, paint. A rock scan on an aircraft cabin is the loudest possible tell, and it is free to avoid.
- **pyrender's `ambient` is additive**, not multiplied by albedo: 0.1 lifts every black in the frame to grey. Keep it 0.02–0.05 and use a dim directional as fill. This one line is the difference between a graded frame and a washed one.

If `probe.py` reports `world.plate: vector` (pyrender or EGL missing), build the plate from the
recipes below as layered vector + noise and hold it to the same measured table. Never a flat
background, never a borrowed image.

The requirement stays measurable — `plate3d.py` prints these and records them in `build/plates.json`:

| Check | Measured by |
|---|---|
| ≥3 material families, no flat surface | `flat_lit` < 0.35, `hue_clusters` ≥ 3 |
| contrast and split tone | `contrast` (p95−p5) in 0.42–0.92 |
| atmosphere present | haze in the post spec; luma variance in the top band at stage 7 |
| depth separation | detail(fg)/detail(bg) ≥ 1.15 — measured after the foreground plane exists, i.e. stage 7 |

Shadow-direction agreement, material *names*, and "does the light source motivate the haze" are not
measurable from pixels. Record them as claims in `plan.md`; do not present them as measured.

**What is never acceptable:** a flat single-colour background, a gradient with no objects, or a plate borrowed from another project. A procedural plate that passes the table above is the honest fallback; a blank one is a stall with extra steps.

#### C.1 Materials & texture
Every surface needs three things: **albedo variation, a roughness break-up, and a wear story** (who touched it, how old it is).

| Material | Albedo | Roughness | Detail / wear | Must avoid |
|---|---|---|---|---|
| Stone / brick | `#8A8A8E` base, ±12% per block, darker mortar | 0.75–0.9 | chipped corners, damp patches at the base, moss in shade | perfectly uniform blocks |
| Timber (beams, planks, carts) | `#C0A080` ±15%, grain along the length | 0.6–0.8 | knots, splits, nail heads, darker ends where handled | smooth plastic wood |
| Metal (iron, brass, armour) | iron `#4A4A50`, brass `#B08A3E` | 0.25–0.45 + sharp highlight | rust streaks running down, edge wear, dents | chrome-bright everything |
| Fabric (robes, flags, sacks) | flat identity colour | 0.8–0.95 | weave at close-up, frayed hem, dirt at the bottom third | glossy cloth |
| Leather (belts, boots, tack) | `#5A3A22` | 0.5–0.7 | creases at flex points, scuffed toes | uniform brown |
| Dirt / gravel / sand | `#A08060` ±10% | 0.9–1.0 | footprints, wheel ruts, scattered pebbles, damp darker edges | flat colour fill |
| Grass / foliage | `#4A8A3A` ±15%, yellow tips | 0.85 | clumps at different heights, wind lean, trampled paths | lawn-like uniform green |
| Water / wet stone | base + 0.05 roughness | 0.05–0.15 | puddles in low spots, ripples, reflections of the key light | mirror-flat lakes |
| Gold / treasure | `#C08020`–`#E0A040` | 0.2–0.35 | tarnish in crevices, dust, uneven nuggets | flat yellow |
| Paper (newspapers, signs) | `#EFE6CE` | 0.9 | curled corners, fold creases, ink bleed | pristine white |

**Texture rules**
- Detail must survive 1080p: features ≥ 4px. No micro-noise that turns to mush.
- Tiling must be invisible: vary scale 0.8–1.3× per instance and rotate slightly.
- Every shot needs **three material families** (e.g. stone + wood + cloth) so the frame reads as a real place.
- Ground is never one flat colour: add a lighter path, a darker wet patch, debris.
- Wet = darker albedo (−15%), sharper highlight, visible reflection. Dry = lighter, matte, dust on top.
- Age the set: one broken thing, one repaired thing, one thing out of place.

#### C.2 Weather & atmosphere
Weather is a **lighting and grade decision**, not a particle overlay.

| Weather | Visual treatment | Lighting / grade effect |
|---|---|---|
| Clear day | crisp shadows, blue sky gradient, warm bounce | key 5600K, high contrast, saturation +8% |
| Golden hour | long shadows, rim light on every edge, dust in the air | key 3000K, warm highlights, cool shadows |
| Overcast | soft shadowless light, flat sky, mist in the distance | key 7000K, contrast −25%, desaturate 10% |
| Rain | streak particles + splash kernels at ground contact, wet albedo, puddle reflections | key cooler, contrast −15%, specular +, fog + |
| Storm | low clouds, wind lean on grass/flags, hard flicker light | key 8000K, shadow lift, occasional flash |
| Night (moon) | blue ambient, deep blacks, practical lanterns | moon 9000K, practical 2200K, warm pools every 3–4m |
| Dust / desert | haze layer, motes in light shafts, dust on every surface | key 5000K, low saturation in distance |
| Snow | soft bounce from the ground, cold shadows, breath puffs | bounce 7000K, highlight bloom, low contrast |
| Fog | 3 depth bands (near clear, mid 30%, far 70%) | desaturate with distance, lift blacks |
| Smoke / embers | plume with warm underlight, embers rising with wind | local orange bounce on characters nearby |
| Wind | grass, flags, coats, hair all lean the same direction | motion 2–4px amplitude, phase-offset |

**Atmosphere rules:** every exterior has haze; every interior has a light source visible or implied; never a background with zero air between camera and subject.

#### C.3 Light & colour (colour comes from light, not from tinting)
Build every shot as a **4-light rig**:

| Light | Job | Typical |
|---|---|---|
| Key | defines form and shadow direction | sun / window / lantern / forge, 45° off camera, 1.0 intensity |
| Fill | keeps shadow side readable | sky bounce or a second practical, 0.2–0.35, opposite the key |
| Rim | separates characters from the set | behind subject, 1.2–1.8× key, warm or cool opposite the key |
| Ambient / bounce | ground colour bleeding up | grass = greenish underlight, sand = warm, stone = neutral grey |

**Colour temperature by time of day** (use these, don't "eyeball warm"):

| Light state | Key (K → hex) | Shadow (hex) | Fog / air (hex) | Feel |
|---|---|---|---|---|
| Dawn | 3200K `#FFB774` | `#5D6E96` | `#C9B6A6` | cool air, warm first light |
| Midday | 5600K `#FFF6E8` | `#8FA8C8` | `#BFD2E6` | hard, high contrast |
| Golden hour | 3000K `#FFA457` | `#5C6E9E` | `#E0C49A` | long shadows, glow |
| Overcast | 7000K `#DCE6F0` | `#A9B6C4` | `#C8D2DC` | soft, low contrast |
| Moonlit night | 9000K `#7E9AD6` | `#141A2E` | `#2A3350` | blue, deep blacks |
| Lantern interior | 2200K `#FF9A3C` | `#2A1A12` | `#4A3222` | warm pools, dark corners |

**Light-based colouring rules**
- Final colour = **albedo × light**. Never apply one global tint; let shadows go cool and highlights go warm.
- Atmospheric perspective: with distance, desaturate 10–30% and shift toward the fog hue. Mountains are never as saturated as the foreground.
- Contrast targets: day 5:1 key-to-shadow, night 12:1 with practicals, interior 3:1 with a hot practical.
- Characters are lit *as if* they're in the scene: warm edge on the lantern side, cool edge on the moon side. Keep the flat fill but add a 3–6px warm/cool rim.
- Practicals (lanterns, forge, window) must cast visible light: a pool on the floor, a gradient on the wall, a highlight on a nearby prop.
- God rays/volumetric shafts only where geometry allows (window, canopy gap, tunnel mouth).

#### C.4 Depth & staging
- Three depth layers minimum: **foreground occluder** (blurred 3–8px), **mid-ground stage** (where actors stand), **background silhouette** (mountains, roofs, tunnel dark).
- Horizon at 40–55% of frame on exteriors; floor line readable in every interior.
- Put something between camera and subject in ~40% of shots (grass, beam, cart edge, rock) — instant depth.
- Scale cues: doorways, crates, rails, rails and grass must agree with character height.
- Background blur 2–5px when a character is in focus; never blur the character.
- Fog/haze gradient with distance; foreground has the most contrast, background the least.

#### C.5 Post & grade
1. Exposure: protect highlights, lift blacks only at night.
2. Saturation +8–12% (never +25%).
3. Split-tone: warm highlights, cool shadows (or inverse at night).
4. Bloom only on practicals and sun glints (threshold high).
5. Vignette 10–15%, soft.
6. Grain 2–3%, uniform, 35mm-ish.
7. Slight sharpen on the character silhouette so the outline stays crisp.
8. No chromatic aberration, no fisheye, no Instagram filters.

#### C.6 Reference environments (same grammar, other worlds)
*Ref 1 (fort / siege):* fort exterior (grey stone, timber balconies, tiled pagoda roofs, blue tiger banners, tall grass) · courtyard (stone paving, timber sheds, lanterns, cart wheel) · the two-wheel cart with a drilled-hole side panel · rainy night courtyard (wet stone, paper lanterns, mist) · terraced farmland aerial · massed army on green grass.
*Ref 2 (1899 mine / con):* ore tunnel (hewn rock, timber props, rails, cage lanterns) · desert canyon road with a vintage motorcar · mine facade "SURE THING MINE / EST. 1899" with bunting · assayer's office (plank walls, green felt, gold pans) · salting props (newspaper, `100` notes, nuggets, dynamite) · collapse with dust and a revealed gold vein.

**Palettes sampled from the locked frames** (use as targets for the *same* lighting states; new stories may shift hue but keep the value structure):
- Ref 1 day: sky `#2060C0`, grass `#4A8A3A`, gold `#E0C060`, timber `#C0A080`, stone `#8A8A8E`, banner blue `#1E3E9C`.
- Ref 1 night rain: shadow `#202040`/`#202020`, lantern pool `#E8A030`, wet rim `#3C6FA8`.
- Ref 2 day: sky `#4080C0`, sandstone `#A08060`, crate red `#C02828`, gold `#C08020`–`#E0A040`.
- Ref 2 mine: shadow `#402000`/`#604020`, gold vein `#E0A040`, rock `#402020`, lantern `#FFB040`.

#### C.7 World QA (measure, don't vibe)
- [ ] ≥3 material families visible; no surface is a flat untextured colour.
- [ ] Shadow direction identical on every object in the shot and matches the key.
- [ ] Visible atmosphere (haze/fog/rain/dust) and a light source that motivates it.
- [ ] Foreground/mid/background separation readable in thumbnail size.
- [ ] Palette sits in the chosen time-of-day row of C.3 (±1 step), not a random tint.
- [ ] Practicals cast real light; no floating "glow" shape.
- [ ] Character rim light colour matches the environment key/fill.
- [ ] No mirrored-tiling repeat visible, no stretched textures, no untextured primitive.

---
