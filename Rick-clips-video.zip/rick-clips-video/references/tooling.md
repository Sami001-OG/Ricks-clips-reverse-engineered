# Tooling, render tiers and sandbox setup

## Tooling & sandbox install playbook (for Claude's code sandbox)

Claude should not assume anything is installed. Run the probe, install only what is missing, and pick the **highest tier the sandbox supports**. Everything below is CPU-only, no root required, and works on a fresh Linux sandbox.

```bash
bash scripts/bootstrap.sh     # installs everything optional, safe to re-run
python3 scripts/probe.py      # prints JSON + the render tier to use
```

### What is worth installing (and what it buys)

| Tool | Install | Size / cost | Unlocks | Notes |
|---|---|---|---|---|
| **ffmpeg** | `pip install imageio-ffmpeg` (bundled static binary) or `apt-get install -y ffmpeg` | ~30–80 MB | concat, overlay, zoom/pan, `ass` burn, `loudnorm`, mux, CRF encode | Works without root via the pip binary; symlink it onto `PATH`. |
| **Pillow + numpy** | `pip install pillow numpy` | ~40 MB | caption cards, palette sampling, frame measurement, QC math | Core of the tier-3 pipeline. |
| **pysubs2** | `pip install pysubs2` | <5 MB | generate/validate `.ass` caption tracks programmatically | Prevents hand-written ASS syntax errors. |
| **opencv-python-headless + scikit-image** | `pip install opencv-python-headless scikit-image` | ~90 MB | caption bbox/baseline measurement, SSIM/frame diff, cut detection | Use for the Section I gate, not for eyeballing. |
| **soundfile + pyloudnorm** | `pip install soundfile pyloudnorm` | ~10 MB | true −14 LUFS measurement and normalization | Cheaper than `ffmpeg loudnorm` for spot checks. |
| **faster-whisper** | `pip install faster-whisper` | ~200 MB + model | word-level timestamps when the user has no transcript | `small` + `int8` ≈ 0.1–0.3× realtime on CPU. |
| **Montserrat ExtraBold** | bundled at `assets/fonts/…`, or `curl` from gstatic | 180 KB | the exact caption face | Register with `fc-cache` so libass finds it. |
| **Remotion** | `npm i remotion @remotion/cli react react-dom` + `npx remotion browser ensure` | ~300 MB | tier 1: exact React/CSS text, spring-free hard cuts, per-shot transforms | CPU renders fine; keep clips ≤10s per render to avoid timeouts. |
| **Playwright + Chromium** | `pip install playwright && python -m playwright install chromium` | ~250 MB | tier 2: render HTML/CSS caption or full scene screenshots per frame | Slower than Remotion but gives real `paint-order: stroke fill`. |
| **cairosvg / resvg** | `pip install cairosvg` (or the `resvg` binary) | ~10–20 MB | rasterise SVG puppets per frame on tier 3 — real limb animation without a browser | Needs `libcairo` on some images; `resvg` is a static binary. This is what makes tiers 1–3 animate identically. |
| **scipy** (optional) | `pip install scipy` | ~40 MB | connected components in `measure_captions.py`, morphology in QA | The bundled tools fall back to pure numpy, so it is a speed-up, not a dependency. |
| **Blender (`bpy`)** | `pip install bpy` | ~350 MB | optional true-3D characters | **Usually unnecessary** — the references' characters are flat cutouts. Skip unless the user asks for 3D characters. |
| **git** | `apt-get install -y git` or preinstalled | small | version the project, diff renders | Nice for QC history. |

**Do not attempt in a sandbox:** local Stable Diffusion / SDXL (no GPU), local video diffusion, or any model download >2 GB. Use an image **API** instead (below).

### The three render tiers (pick automatically from `scripts/probe.py`)

**Tier 1 — Remotion (best fidelity).** `video/` scaffold, `<Sequence>` per shot, SVG puppets from `rig.svg` driven by `anim.json`, Section E `Caption` component unchanged, camera moves via `interpolate` on a wrapper div. Render per shot, then concat:
```bash
npx remotion render Short out/shot_07.mp4 --frames=426-492
```

**Tier 2 — HTML/CSS + Chromium.** One static `scene.html` per shot (background `<img>`, **inline SVG puppets** positioned per frame by a small JS driver reading `anim.json`, caption div with `-webkit-text-stroke` and `paint-order`), screenshot at each frame time with Playwright, pipe PNGs to ffmpeg. Use only when Node/Remotion is unavailable but Chromium is.

**Tier 3 — SVG rasterise + PIL caption cards + ffmpeg (always works, pixel-exact captions).** This is the safe default: rasterise the puppets with `cairosvg`/`resvg`, composite with PIL, and overlay Section E caption cards exactly — no browser:
```bash
# 1. caption cards from the timed JSON
python3 scripts/caption_cards.py build/captions.json
# 2. overlay them + encode
bash build/cards/overlay.sh
```
`scripts/caption_cards.py` draws Montserrat ExtraBold 70px, 11px black stroke, +3px/6px shadow, centred at baseline 1376, wraps at 900px, and emits a ready `overlay.sh`.

### Image / character generation from a sandbox

There is no local image model. Options, in order of preference:
1. **API with reference-image support** (best for character consistency): Replicate / fal / OpenAI images — pass the locked character sheet as the reference for every shot, plus the Section H prompt and negative prompt.
2. **Free fallback** (Pollinations-style GET endpoints): no key, heavily rate-limited (~1 image/45s) and may add a watermark — only for drafts, never for the final.
3. **Composite locally**: generate only backgrounds via API, and build characters as **flat vector/SVG cutouts** (easy to keep pixel-consistent, no model drift) rasterized with `cairosvg` or PIL. This is the most reliable way to guarantee the black outline and head ratio never drift.

### QA tools that ship with this skill
| Tool | Measures | Gate items |
|---|---|---|
| `scripts/measure_captions.py` | caption bbox, baseline, centre, stroke, per-card drift — from the encoded video | 2 |
| `scripts/consistency_check.py` | silhouette IoU, garment ΔE, outline coverage, head/body ratio, face purity, prop IoU | 7, 8 |
| `scripts/anim_check.py` | contact resolution, easing, idle/blink presence, frozen runs, frame pops | 10–15 |
| `scripts/world_check.py` | flat-region coverage, colour/material variety, contrast, split tone, depth, atmosphere | 3, 6 |
| `scripts/puppet.py` | the rig itself: solved skeleton, auto-plant, IK contact, prop sockets, derived proportions; `--verify` asserts ground spread, contact residual, reach ratio, prop ownership and joint limits | 7, 10–14 |

If a check cannot be measured by a script, it must be judged from uploaded frames and cited by frame number — never asserted.

Never silently substitute a different style if generation fails — stop and report the gap.

### MCP / connector options (when Claude can use them)
- **filesystem MCP** — read/write the project so Claude edits `build/*.json` and scripts directly.
- **shell MCP** — run `ffmpeg`/`npm` and read output instead of round-tripping commands through the user.
- **fetch MCP** — pull font files and API responses.
- **Playwright MCP** — drive the tier-2 renderer and screenshot previews for QC.
- **Artifacts** (Claude app) — quick visual check of the caption card at 1080×1920 and the character compositing; not a renderer.

### Sandbox constraints to design around
- **Ephemeral disk**: cache fonts/models under the project dir, not `/tmp`.
- **Wall-clock limits**: render shot-by-shot (≤10s each) and concat; never one 60s Remotion render in a constrained sandbox.
- **Egress allowlists**: if downloads are blocked, the bundled font + tier 3 still produce the full video; only asset generation needs the network.
- **Memory caps**: `faster-whisper` `small/int8`, and process frames streaming (PIL `Image.open`, no full-video arrays).

---
