# Story patterns, shot maps and the replication kit

### G. Story patterns & shot maps (cast invented per story)

These two maps are **story shapes**, not casts. Copy the *structure* — hook, mechanism, escalation, reversal, payoff — and invent characters for the new story using the builder in Section B.

**Ref-1 pattern (siege / “clever device” story)** — ~30 shots:
hook: extreme close-up of the drilled board + black nozzle (“holes”) → artisan drilling the cart-bed in a fort courtyard → wide establishing shot of the fort with blue tiger banners → guards at the gate, bored/angry → the official in red supervising → detail of the trick: holes, rope, white-wrapped projectiles → rain at night, the cart under a lantern, the official sneaking → a guard notices, a hand slaps him, “dead.” → the cart is wheeled into the courtyard → a man lies on the board and a yellow parasol floats above him (“human umbrella.”) → soldiers climb aboard → the enemy hears → ladders slam against the walls → wide: the yellow-armoured army charges → the warlord under his yellow parasol → “Everyone screams at him something” → close-up: a hand lights the fuse → the device discharges → dozens of trails rip across the sky → aerial of the terraced fields with crossing white smoke trails → final one-word punchline (“way.”).

**Ref-2 pattern (con / “too good to be true” story)** — ~28 shots:
hook: close-up of a gold pan / revolver on a table → “the hole” blasted in the tunnel wall → buddy at the candle counter with a blue kettle → “watch it vanish into the rock” → spark/crack in the wall → salting the tunnel from a ladder → red crates on a cart → the vintage motorcar driving the canyon road → the mine facade with the “SURE THING MINE / EST. 1899” signboard → newspaper “MILLIONAIRE DUE TO MORROW” → the assayer's office: green felt table, gold pan, `100` notes → “gold dust instead.” → gold pan with black sand spun in a barrel → magnifier over the pan → “Somebody salted this gold into the wall” → the “expert” in the bowler hat inspecting, then smashing the wall with a pickaxe → the investor in the white top hat arriving → crowd reaction → dynamite → fuse lit → toss → explosion → collapse, dust → revealed gold vein with “10 FT” marks → final two-shot at the vein → last word punchline.

**Structural skeleton to copy (any story):** striking prop close-up (0–2s) → world establishing (2–5s) → who wants what (5–10s) → the mechanism explained by showing (10–20s) → first attempt / complication (20–30s) → reversal or reveal (30–45s) → consequence at maximum scale (45–55s) → single-image payoff + last word (55–60s).

---

### G.1 Elaboration — the VO is a seed, not a script

A voiceover sentence names a few nouns; the film it becomes is a roomful of things. Before any
shotlist or plate is authored, run the elaboration stage (`elaboration.md`): expand each noun into
an **atom** — a physical object with a build source, a location, a shot and a time window. Never add
spoken words; add on-screen detail mapped onto the existing word timings. The rule is absolute:
**whatever the script names must be in the video when it is named.** A postmaster's VO expands to a
post office — counters, a pigeonhole almirah, envelopes, a stamp, a scale, other employees — not to
a person floating in an empty room.

Plan scenes, not just shots: ≥3 distinct locations for a film over ~20 s (≈one every 9 s), each with
≥6 inventory items, none taking more than 60% of shots, and a **cut** on every location change.

A single location repeated is a failure **even when every per-shot check passes**. Shot-size
variety, correct captions, clean rigs and perfect contacts can all be true of thirteen shots in the
same empty room; the film still fails the story because the world never opens up. Location variety
is its own gate (26, 31) and is not implied by the others. Detail density (`--detail 3`) is the
default; anything less leaves the walls, floor and human trace undescribed.

### H. Unified replication kit (apply to ANY new voiceover)

1. **Pick a story** with a concrete “mechanism” (a device, a scam, a botched plan) that can be shown as props + reactions, 120–160 words (≈50–65s at 145–160 wpm).
2. **Write the script**, then cut it into 1–4 word caption units (typical 2–3).
3. **Design the cast from the script** — 3–6 characters, each with a filled builder card (Section B). Their roles, silhouettes and colours come from *this* story; nothing is inherited from the references.
4. **Design the shot list** (≈ duration/2.2 shots) with the framing ladder in D, the story skeleton in G, and one idea per shot.
5. **Build the 3D world** from Section C: 4–6 locations, reused with different lighting/weather, dressed deeper than the actors so camera moves create parallax.
6. **Lock the cast first:** one canonical sheet + `characters.json` per character (B.1), then generate every shot against that sheet — never from text.
7. **Rig and animate** per D.2–D.6 — SVG puppet per character, eased joint keys, anticipation/contact/follow-through, idle sway, blinks, mouth flaps, contact shadows, parallax; 30fps with sub-pixel transforms.
8. **Composite & grade** per the layer stack in H (Assembly), then **mix** VO + music + SFX to −14 LUFS.
9. **Measure, don't vibe:** run the five QA tools, write `QA_REPORT.md` with numbers, and fix failures before delivery.

#### Generation prompt recipe (cast is per story)
**Character sheet (make once per character, reuse as the reference image for every shot):**
> `stylised toon-shaded 3D cartoon character rendered to look like a 2D animation cutout, full body, front view, SOLID BLACK OUTLINE around the entire silhouette, oversized rounded PURE WHITE head (one third of body height) with a flat featureless face, small solid black dot eyes, thick angular black eyebrows, tiny simple black mouth, thin black stick arms and legs, small black mitten hands, black shoes, [ROLE: e.g. 1890s mine owner], [SILHOUETTE CUE: e.g. brown campaign hat with gold badge], [GARMENT: e.g. red-and-black vertically striped vest over a white shirt], [IDENTITY COLOUR hex], [PROP: e.g. gold pan], neutral studio light on a plain light-grey background, no text`

Then generate a **turnaround + expression sheet** from that same reference image: front, ¾, side, back; plus neutral, talking, happy, angry, shocked. This sheet is the canonical asset every shot must reference.

**Background (one per shot, no characters):**
> `Empty [LOCATION] in [ERA], cinematic semi-realistic 3D environment, physically based materials, worn wood / chipped stone / wet ground, strong directional [LIGHTING: golden hour / blue moonlight / warm lantern light], volumetric haze and god rays, atmospheric depth with foreground, mid-ground and background layers, rich saturated colour, shallow depth of field, 9:16 vertical composition with clear mid-ground standing space, no people, no text, no watermark`

**Motion (only if a video model is available):**
> `Locked-off camera with a slow [push in / truck left / crane up], subtle handheld float, subject stays centred, no morphing, no new objects, no text`

**Negative prompt (all):** `photorealistic human, nose, detailed eyes, text, watermark, logo, extra fingers, deformed hands, fisheye, lens distortion, blurry, low-res, flat cartoon background, painted 2D background, duplicated characters`

#### Consistency rules (non-negotiable)
- One canonical sheet per character; every shot references that sheet (or its rig). Text descriptions never replace it.
- Colour, outline weight, proportions and props come from `characters.json`, not from the prompt — the prompt is generated from the file.
- Measure drift on every generated frame (B.1) and reject rather than patch.
- Same black outline weight on every character in every shot; it is a stroke per part, not a whole-body filter.
- Same caption font/size/stroke/position in every shot — captions are the strongest brand signal.
- Same environment asset reused when a location repeats; change lighting state rather than rebuilding geometry.
- Never mix rendering styles (no realistic human faces, no painterly backgrounds, no 2D flat art).

#### Assembly & compositing (layer stack)
The references are **composites**: a semi-realistic 3D background plate with flat, black-outlined characters pasted on top. Build every shot in this order (bottom → top):

1. **Background plate** 1080×1920, sharpened or lightly blurred depending on shot.
2. **Atmosphere behind characters** — god rays, haze, rain, smoke, embers (`screen`/`plus` blend, 20–60% opacity).
3. **Contact shadows** on the ground plane, under each actor (black, 25–35% opacity, 20–30px blur), so the actors sit *on* the plate.
4. **Characters** as RGBA cutouts, sorted back-to-front (z = feet line, far rows first).
5. **Foreground plane** — a real RGBA layer between the actors and the captions. In Ref 1 grass passes **in front of** the boots; that one overlap is the strongest depth cue in the whole frame and it cannot be faked by a shadow. Derive it from the plate's own bottom band (sample the ground colour, seeded blade/tuft silhouettes, 0.5× darken, 3–6px blur, alpha ramp) or supply `--fg path.png`.
6. **Foreground FX** — dust puffs, sparks, splashes, embers (these go over everything except captions).
7. **Grade** — saturation +8–12%, warm highlights / cool shadows, vignette 10–15%, film grain 2–3%.
8. **Captions** — always last, always on top (Section E).

The layer order is the depth order: plate → shadow → actor → foreground → caption. A foreground plane that is **behind** the actors does nothing; it must overlap at least the ankles. Keep its top edge below the faces (y ≥ 860) and its coverage 8–45% of the frame — more than that becomes a green wall, less is invisible.

**Scale ladder** (measured from the locked references; character height in px of the 1920 frame):
| Shot type | Character height | Head height | Feet line | Use |
|---|---|---|---|---|
| establishing / wide | 300–420px | 100–140px | y 1100–1250 | crowd, landscape, staging |
| medium (default) | 620–820px | 205–270px | y 1250–1380 | dialogue, action beats |
| close-up | 1000–1400px | 330–460px | off-frame | reaction, prop hero, punchline |
| prop ECU | — | prop fills 50–80% of frame | — | the object the story turns on |

Keep the same character at the same scale across consecutive shots of the same framing — the references do not re-scale characters shot to shot.

**Clean-plate rule (hard).** A background plate must contain **no characters**. If the plate already has a baked-in figure, you can only ever add a character at that exact scale and depth, and any mismatch reads as a cut-out sticker — this is the single most common way these videos look wrong. Generate or select plates with *standing space* and nothing standing in it, then place your actors. Never paste actors over an existing cast.

**Caption band is staging, not overlay.** Captions occupy **y 1300–1400** at the reference metrics. Choose the shot so the *action* happens **above y 1250**:
- wide/medium: set the feet line to **≤1380** — at a 620–820px character the hands hang ~1150–1200, so the body clears the band. If the feet line is 1500 the hands land at ~1370 and sit inside the caption; that is a staging bug, not a caption bug;
- close-up: the caption may overlap the lower body — that is correct and matches Ref 2 — but never let a **hand, prop or contact point** land inside 1300–1400 while that caption is on screen. Move the beat up, or cut before the caption.
- If the story needs a floor-level action (digging, falling), the caption at that moment goes in the upper third instead; state the exception per shot in the caption plan.

**Camera on a composite:** apply the move once, to the whole scene, with depth-scaled parallax — actors zoom 1.00×, background 0.55×, foreground 1.75× (Section D.1). Anchor actors on the feet line so the push-in grows them without lifting them. Whip moves get 2–4 frames of directional motion blur. A locked-off shot is a valid choice; an *accidentally* frozen shot is not.

**Depth:** background softens 2–5px when characters are in focus; characters are always sharp. Do not blur characters for fake depth of field.

**Contact/grounding:** never let feet float — the shadow ellipse is the tell. In wide shots the shadow shrinks with the character.

---
