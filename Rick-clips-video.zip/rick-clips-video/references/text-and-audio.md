# Captions and audio

### E. Caption system (measured — implement exactly)

Measured on full-res caption frames (r1 t13.0 “it gets”, r1 t63.0 “way.”, r2 t16.0 “and”, r2 t21.5 “and”):

| Property | Value |
|---|---|
| Content | **verbatim word-by-word** of the narration; **1–4 words** per caption (typical 2–3); lowercase with the spoken punctuation attached (`"mine."`, `"mine?"`, `"nobody's"`, `"Not a"`); no trailing period added |
| Font | **Montserrat ExtraBold** — bundled at `assets/fonts/Montserrat-ExtraBold.ttf`. The giveaway is the **double-storey “a”** and single-storey “g”: Poppins/Inter are wrong. Acceptable stand-ins: Archivo Black (bundled), Arial Black. |
| Font size | **70px @1080 wide** (measured: `and` = 135px wide, 54px tall; `it gets` = 232px wide, 68px incl. descender — exactly Montserrat ExtraBold @70px) |
| Fill | **#FFFFFF** (measured 252–255) |
| Stroke | **#000000**, **11px**, round joins, centred on the glyph edge |
| Shadow | subtle black drop shadow, offset ≈+2/+3px, blur ≈4px, ~50% opacity |
| Position | horizontally **centred** (glyph centre x ≈ 540); **baseline y = 1376px** (descender bottom ≈1389px) → caption band ≈ y 1322–1390 (69–72.4% of height); text block bottom ≈ 530px from the bottom edge |
| Max width | ≤ 900px (≈84% of width); longer phrases wrap to a second line, second line centred, line-height ≈1.15× |
| Timing | **one card per spoken word-group, ≈2.0–2.7 cards/second**; a card holds for its whole group (measured ≈0.4–0.9s) and is replaced **on** the next spoken word, never mid-word |
| Animation | **hard swap — no pop, no bounce, no type-on, no fade.** Frame-level inspection of a card change (`ref2` t=46.967→47.000) shows the new word at full size on its first frame. Do not add a scale/spring. |
| Layering | captions are drawn **on top of everything** (above characters, above FX) |
| Never | all-caps, drop shadows larger than 4px blur, captions in the top third, more than 4 words, yellow/animated “TikTok” captions |

**Implementation (Remotion / React) — drop-in component**
```jsx
import {AbsoluteFill, useCurrentFrame} from 'remotion';
// load once: useFont(require('./assets/fonts/Montserrat-ExtraBold.ttf'), 'Montserrat', {weight: '800'})

export const Caption = ({text, from, duration}) => {
  const frame = useCurrentFrame();
  const local = frame - from;
  if (local < 0 || local >= duration) return null;   // hard swap: no fade, no scale
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: 530}}>
      <div style={{
        fontFamily: 'Montserrat, sans-serif', fontWeight: 800, fontSize: 70, lineHeight: 1.15,
        color: '#fff', WebkitTextStroke: '11px #000', paintOrder: 'stroke fill',
        textShadow: '0 3px 6px rgba(0,0,0,0.5)', letterSpacing: 0,
        whiteSpace: 'pre-wrap', maxWidth: 900, textAlign: 'center',
      }}>{text}</div>
    </AbsoluteFill>
  );
};
```
**Implementation (ffmpeg/ASS fallback)**
```ass
[Script Info]
ScriptType: v4.00+
PlayResX: 1080
PlayResY: 1920
[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Cap,Montserrat ExtraBold,70,&H00FFFFFF,&H00FFFFFF,&H00000000,&H80000000,-1,0,0,0,100,100,0,0,1,11,2,2,80,80,530,1
```
(BorderStyle 1 = opaque outline; Outline 11 = 11px black; MarginV 530 puts the baseline at y≈1376.) Install the font first with `fc-cache`/fontconfig so libass can find "Montserrat ExtraBold".

---

### F. Audio treatment
- **VO:** user-provided (11Labs / Fish Audio). Keep the user's voice; match the reference's pacing by aligning captions to the actual speech, never by time-stretching the VO.
- **Music bed:** cinematic, mid-tempo (85–100 BPM), builds across the escalation and peaks at the climax; sits ~14–18 dB under VO.
- **SFX:** hard punctuation on every cut and caption swap (soft click/thumb), whoosh on whip-pans, impact boom on explosions, dust rumble on collapses, prop sounds (drill, hammer, pan, coin) on the corresponding shots. `scripts/make_sfx.py` synthesises these deterministically from `captions.json` + `shotlist.json`; `finish.py --sfx` ducks the bed under the VO and limits the result.
- **Loudness:** final mix ≈ −14 LUFS integrated, true peak ≤ −1 dBTP; VO ducked under SFX hits. Measure it on the encoded file, not the filter graph: `loudnorm` as a meter reports `input_i` / `input_tp`. A speech-only track needs gain **and** limiting to reach −14 without breaking the peak ceiling, and AAC adds ~0.3 dB of inter-sample overshoot.
- The reference has **continuous narration with no pauses** — measured: no silence gap ≥0.6s at −35dB across either reference; captions therefore advance continuously. Reference audio measures ≈ −17 dBFS mean, ≈ −2.5 dBFS peak.

---
