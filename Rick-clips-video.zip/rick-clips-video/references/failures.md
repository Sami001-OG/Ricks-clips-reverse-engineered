# Continuity, failure modes, determinism, crowds

## Contents

- [D.8 Implementation](#d8-implementation)
- [D.9 Storytelling rules (what makes it read)](#d9-storytelling-rules-what-makes-it-read)
- [D.10 Animation QA (measurable)](#d10-animation-qa-measurable)
- [D.11 Failure modes — what it looks like, what actually caused it](#d11-failure-modes--what-it-looks-like-what-actually-caused-it)
- [D.12 Preflight & determinism](#d12-preflight--determinism)
- [D.13 Groups, crowds and depth](#d13-groups-crowds-and-depth)

#### D.8 Implementation
**Default: SVG puppet in Remotion** (no browser rig tool, exact and versionable).
```jsx
const ease = Easing.bezier(0.33, 0, 0.2, 1);

const limb = (frame, keys) => interpolate(frame, keys.map(k => k.f), keys.map(k => k.a), {
  easing: ease, extrapolateLeft: 'clamp', extrapolateRight: 'clamp',
});

// one joint = one rotating group; children inherit the transform
<g transform={`translate(${hip.x} ${hip.y})`}>
  <g transform={`rotate(${thighAngle})`}>
    <rect x={-7} y={0} width={14} height={90} rx={7} fill="#111" />
    <g transform={`translate(0 90) rotate(${shinAngle})`}>
      <rect x={-6} y={0} width={12} height={88} rx={6} fill="#111" />
      <ellipse cx={10} cy={88} rx={18} ry={8} fill="#111" />
    </g>
  </g>
</g>
```
- Drive every joint from `build/anim.json`; never hand-place per frame.
- Root motion + foot IK check: log foot x per frame, assert |Δ| < 1.5px while planted.
- Character parts exported as individual SVGs/PNGs from the canonical sheet, named `char_<id>_<part>.svg`.

**Shipped reference implementation:** `scripts/puppet.py` is a complete tier-3 rig, not a sketch. It builds the character from the measured proportions above, solves the skeleton in world space, auto-plants the feet, samples eased joint keys, draws outlined SVG per frame, rasterises (cairosvg) and composites with PIL + ffmpeg — no browser. Features:

| Capability | What it does |
|---|---|
| `build_rig(card)` | head/body/legs proportions, **6 body archetypes**, eye + brow + mouth metrics, limb and outline weights, 6 hat types, 4 hair types, optional beard, hunch, hex set |
| `solve_skeleton` | world-space joints for any pose (shoulders, elbows, hands, hips, knees, feet) — every draw call reads this |
| `plant` | per-frame ground correction; returns the root that puts the lowest foot on the line |
| `action_pose(name, f, rig)` | 14 D.5 actions with declared contact frames (`handshake`, `handoff`, `push`, `pull`, `lift`, `strike`, `throw`, `catch`, `light_fuse`, `point`, `shrug`, `nod`, `fall`, `hit`) |
| `reach` / `_arm_ik` | two-bone IK with reach-ratio reporting |
| `duo_layout` | one shared grip point, both actors IK'd, per-action spacing, prop ownership transfer |
| `prop_svg` | 8 props in hand sockets, correct orientation, world-vertical option |
| `camera_at` / `scene_svg` | push-in, truck, crane, handheld; feet-anchored actor transform with depth-scaled parallax |
| `foreground_sheet` | derives an RGBA foreground plane from the plate's bottom band (seeded, deterministic) or takes a PNG; occludes the ankles |
| `crowd_scene` | N cast rigs across depth rows with per-actor phase and blink, z-sorted |
| `--verify` | asserts all of the above numerically (see below) |

```bash
python3 scripts/puppet.py --demo out/wide.mp4 --bg plates/courtyard.png --height-px 330 --feet-y 1200
python3 scripts/puppet.py --demo out/strike.mp4 --action strike --prop hammer --height-px 700 --feet-y 1320
python3 scripts/puppet.py --demo out/handshake.mp4 --duo handshake --height-px 820 --feet-y 1340 --camera push_in
python3 scripts/puppet.py --demo out/handoff.mp4 --duo handoff --cards build/cards/card_0001.png
python3 scripts/puppet.py --demo out/crowd.mp4 --crowd 5 --cast a.json b.json c.json --height-px 620 --feet-y 1300
python3 scripts/puppet.py --demo out/wide.mp4 --bg plates/courtyard.png --height-px 330 --feet-y 1200 --body armour
python3 scripts/puppet.py --verify      # numeric proof, exits non-zero on failure
python3 scripts/consistency_check.py --frames analysis/frames/s07 --chars assets/characters/characters.json
```

`--verify` currently prints and gates on:

```
walk stride                        29.9px  15-70px
walk ground spread after plant      0.0px  <= 0.5px
joint limits                        0 bad   0
handshake grip residual             0.00px <= 0.5px
handshake reach ratio               0.86    <= 0.92
handoff grip residual / reach       0.00px / 0.78
push grip residual / reach          0.00px / 0.88
prop/hand distance                  0.00px <= 0.5px
prop ownership                      a/b     a and b
camera push-in monotonic               yes  monotonic
camera zoom range           1.000 -> 1.060  1.000 -> 1.060
camera truck travel            65 -> -65px  symmetric
foreground coverage                  18.8%  8-45%
foreground below faces               y1450  >= 860
crowd actors / x span           5 / 565px  5 / >= 420px
crowd depth rows                    5 rows  >= 3
crowd phase stagger                5 states  >= 2
actions sampled (14)            all frames  no error
```

Two behaviours worth copying exactly: `plant` runs **before** the contact solve (otherwise the hands separate by the amount the feet were corrected), and props are drawn **after** the torso but **before** the near arm, so the hand always closes over the handle.

**Alternative rigs:** Rive (`.riv`, free tier) or Spine (paid) if the user has them — same hierarchy, same timing tables. **Avoid** sprite-sheet flipbooks for anything except crowds and FX.

#### D.9 Storytelling rules (what makes it read)
- **One idea per shot.** If it needs explaining, split it.
- **Cause → effect within 2 shots.** Show the action, then the consequence.
- **Establish before you subvert:** wide, then the detail.
- **Props carry the plot:** the mechanism is shown 3–4 times before the payoff.
- **React after every reveal** (0.5–0.8s), then move on.
- **Escalate scale:** detail → medium → wide → detail; never two identical framings in a row.
- **Payoff on the last word**, biggest composition, last shot.

#### D.10 Animation QA (measurable)
- [ ] Planted feet slide <1.5px/frame; no floating above the ground line.
- [ ] Every action has anticipation, contact, follow-through — no pose-to-pose teleporting.
- [ ] Hands touch what they hold; props never detach or change hands without a transfer frame.
- [ ] All keys eased (no linear snaps except dollies); no 1-frame pops.
- [ ] Idle, blink and breath present in every shot with a visible character.
- [ ] Mouth movement lands on the spoken word (±2 frames).
- [ ] Two-character interactions share one contact frame.
- [ ] Pose/screen-direction/eyeline match across cuts.
- [ ] Hat, coat, hair and props lag and settle (no rigid attachments).

#### D.11 Failure modes — what it looks like, what actually caused it
Every entry below was hit and fixed while building `scripts/puppet.py`. Read this before debugging by eye; the symptom almost never points at the real cause.

| Symptom (what you see) | Real cause | Fix |
|---|---|---|
| Character **floats or sinks** between frames | legs authored by angle; hips at a fixed height leave the feet off the ground | auto-plant every frame (`root.y += ground_y − lowest_foot.y`) |
| Character **slides** while walking | root motion authored independently of stride | derive root speed from stride length; the stance foot owns world position |
| Legs **scissor into an X** (front-on view) | hip swing 20–30° on a rig with no depth axis | ≤10° swing + 20–24° knee lift + 3px bob; big swings only in profile |
| **Black stripe across the chest** every other step | arm layer order fixed per character | arm drawn behind the torso when `sh < 0`, in front when `sh > 0` |
| Two hands **don't meet** despite a "contact" | one side solved, other side posed; or the actor was translated after solving | both arms IK to one shared grip point, after planting |
| Grip looks **limp or mannequin-straight** | reach ratio ≥1, arm locked | move the pair closer (spacing per action); never lengthen the arm; check ratio ≤0.92 |
| **Prop points backwards / sideways** | prop local axis doesn't match the limb convention | local +y runs *away from the hand*; rotate by the forearm's absolute angle; world-vertical props take 0° |
| Prop **detaches at a hand-off** | parent switched on a different frame than the contact | ownership switches exactly on the contact frame; caller holds 1 frame longer |
| Raised arm **disappears** | head is 1/3 of the body; the arm is behind it | cap the swing at 120–140°, let the prop carry the height, or cut to ¾ |
| Limb **crosses the face** | head drawn before the arm | head is always the last layer; re-pose rather than re-layer |
| **Hammer/axe head missing** at the wind-up | prop parented below the hand's pivot | prop drawn after the torso but before the near arm, with the head at +y beyond the hand |
| Caption sits **across the hands** | staging ignores the caption band | keep action above y1250; captions own y1300–1400 |
| Actor looks like a **sticker on the plate** | plate already had characters, or scale doesn't match the standing space | clean-plate rule; derive height and feet line from the plate's ground plane |
| Body looks **short, legs twice as long** | torso path drawn from the body centre instead of the hip — a silent half-height bug | measure the garment bbox in the render: height ≈0.38 × character height, width ≈0.92 × head width. Fix the path, not the numbers |
| Character **too small to read** | wide-shot scale used for a dialogue beat | medium 620–820px for dialogue; wide only for establishing |
| **Outline too thin** in wide shots | outline scaled with the character | outline is a stroke at 0.9–1.1% of height, floored at 2px |
| Face **gains a nose/chin** | an image model was asked to "improve" the head | head is generated once per character; expressions swap layers only |
| Push-in **lifts the character off the ground** | actors scaled about the frame centre | scale about the **feet line**; regenerate the contact shadow inside the same transform |
| Push-in reads as a **zoom lens**, not a dolly | plate moves as much as the actors | depth-scaled parallax: plate 0.55×, actors 1.00×, foreground 1.75× |
| Foreground becomes a **green wall** | plane too tall/opaque, or derived from a bright plate at full strength | coverage 8–45%, top edge y ≥ 860, darken 0.5×, blur 3–6px |
| Foreground **does nothing** | composited *before* the actors | layer order is plate → shadow → actor → foreground → caption |
| Crowd **breathes and blinks in unison** | one shared phase | per-actor idle phase (0–2.4s) and blink offset (0–74f) |
| Crowd reads as **clones in hats** | one rig repeated, hat only changed | cycle 3–6 **body archetypes**; no body+hat pair twice |
| Caption sits **across the hands** | feet line at 1500 puts hands at ~1370 | medium dialogue feet ≤1380; captions own 1300–1400 |
| Dress/coat **legs vanish** | skirt painted over the whole leg | skirt hangs past the hip and hides the *top* of the leg only; feet and shins stay visible and planted |
| Beard **kills lip-sync** | solid mass over the mouth | horseshoe beard: jaw masses + chin patch + moustache, mouth clear |
| Tall hat **fails the head-ratio gate** | gate calibrated on a campaign hat | 0.28–0.42 includes headwear; do not shrink a top hat to pass a metric |
| Plate has **40% pure black** and the shadows look clipped | film grain added *additively* drives dark pixels negative | grain must be **multiplicative**; verify `p05 luma > 0.004` and that the top colour bucket is not `0,0,0` |
| Every black in the plate turns **grey and milky** | pyrender's `ambient` is **additive**, not multiplied by albedo | `ambient` 0.02–0.05 only; use a dim directional as fill instead of raising ambient |
| Silhouettes **wash out** into the background | `haze` pushed hard to fake depth | haze ≤ 0.34; depth comes from the floor line and light falloff, not fog |
| A cabin/bunker wall reads as **stone that grew there** | a photo texture scan applied to a manufactured surface | `{"solid": true, "color": [...]}` for panels, seats, carpet, paint; scans are for stone, timber, rust |
| Aircraft/vehicle seen **from outside is a pale slab** | raster lighting on a large smooth body has nothing to catch | keep the camera inside, or give the body panel lines, windows and a strong rim; a silhouette against sky still needs an outline |
| `flat_coverage` **fails** on a legitimately dark night interior | metric measured over the whole frame | judge `flat_lit` (largest bucket over luma > 0.10), not `flat_coverage` |
| Caption burn **OOMs a phone / the process dies mid-encode** | one full-frame RGBA overlay per card: 8 MB each, ~500 MB peak for 26 cards | crop each card to the caption band (`y 1288-1448`) and overlay at `0:1288`; pixel-identical, ~40 MB peak |
| Film is **one frame short** of the shotlist | `-shortest` against an audio stream a few ms shorter than the video | bound the output with `-t <base duration>` and assert `nb_frames` afterwards |
| Mix lands **~1 LU under −14 LUFS** | `loudnorm` runs into its true-peak ceiling on a speech track and stops there | gain first (+~10 dB), hold peaks with `alimiter=limit=0.851:level=0`, then measure `input_i` / `input_tp` on the *encoded* file |

Elaboration / object failures (from `elaboration.md` and `objects.md`):

| Symptom | Cause | Fix | Check |
|---|---|---|---|
| **Postmaster with no post office** — the role is named but no setting appears | elaboration stage skipped; nouns never expanded into locations and inventory | run elaboration with `--domain post_office --detail 3`; add the three locations and their ≥6 items | gate 26 `elaborate.py --check`; gate 31 |
| **Bag / phone named but never held** — VO names it, no hand carries it | object declared as `set:` or missing from the character's `props[]` | make it a `puppet:<kind>` hand prop, add its id to `cast[].props` and the shot's `objects` | gate 28 `shotlist.py --check --objects --words`; gate 33 |
| **One location for 13 shots** — the film is a single repeated room | `--detail 1` or no scene-planning pass; no location variety rule applied | raise to `--detail 3`; split into ≥3 locations (≈1 per 9 s), cut on every change | gate 31 location variety; `story.md` G.1 |
| **Object in contract but not rendered** — `objects.json` promises it, frame lacks it | `objects.json` / `beats.tsv` disagree with `shotlist.json` | run `shotlist.py --fill` then `--objects`, then `--check`; reconcile `appears` with the shot list | gate 28 bidirectional check; gate 29 |
| **Inventory with no build source** — item named in prose with no `make` | dressing never assigned `plate:` / `set:` / `puppet:`, or the primitive/kind does not exist | assign a resolvable `make`; verify `puppet.py --list-props` and the location scene spec | gate 29; `objects.md` build sources |
| **Unclassified content words** — warnings left open at delivery | a content noun is neither a declared object nor in `abstract` | add it to `objects.json` as an object or to `abstract`; clear `coverage.unclassified` | gate 27 coverage; gate 28 warnings |
| **Props ballooning on close-ups** — a held object jumps size between framings | prop sized in absolute screen px instead of rig-relative units | size props as a fraction of character height (`~0.20`), keep `scale` rig-relative; re-derive from the sheet | gate 9 prop IoU; gate 30 framing; `objects.md` hand-socket rules |
| **Caption band crossed by an insert's subject** — stamp/letter overlaps y1300–1400 | insert framed too low; staging ignores the caption band | move the action above y1250 or cut before the caption; caption may cover lower body, never a hand/prop/contact | gate 21 staging; gate 30 shot-size variety |

#### D.12 Preflight & determinism
Run this before rendering a single frame; it turns "it worked once" into "it renders the same every time".

```bash
set -euo pipefail
python3 -c "import sys; print(sys.version)"          # pin the interpreter in notes
python3 -c "import cairosvg, PIL, numpy; print('ok')"  # tier 3 deps
ffmpeg -version | head -1
fc-list | grep -i montserrat | head -2               # caption face actually installed
python3 scripts/probe.py                               # tier + capabilities
python3 scripts/puppet.py --verify                     # rig numerics
```

- **Seeds:** every generated plate records `seed`, `model`, `prompt_hash` in `build/plates.json`. Same seed + same prompt hash must reproduce the plate; if it doesn't, the model is not deterministic — pin the output file and never regenerate it.
- **No wall-clock, no randomness in render code.** Animation sampling is a pure function of `(frame, pose_table, rig_version)`. Any `random` call in a renderer is a bug: use a seeded `numpy.random.default_rng(seed)` for grain/FX and store the seed.
- **Version pins:** `rig_version`, `sheet_version`, `caption_version`, `font_sha256`. A shot records all four in its manifest; changing any one invalidates the frames rendered before it.
- **Frame cache:** render to `build/frames/<shot>/%05d.png`, then encode. Re-running a shot reuses frames unless its manifest changed — this is what makes a 30-shot film re-renderable in minutes rather than hours.
- **Determinism check:** render frames 0 and 60 twice; the PNG bytes must be identical. If not, something time- or state-dependent leaked into the renderer.

#### D.13 Groups, crowds and depth
A crowd is **not** one character repeated. Six clones in six hats is the most obvious "AI-made" tell in the format — the reference cast is readable at thumbnail size because every figure has a different **body**, not a different colour.

- **Cast the crowd:** cycle 3–6 rigs from `characters.json`; never place the same body + hat pair twice in one shot. 3–5 figures read as a group; 6 is the practical ceiling before it becomes noise at 1080 wide.
- **Depth rows:** the front row is **1.04× scale** and the back row **0.74×**, with the back row's feet **150–220px higher** in frame; far rows also compress toward the centre line, near rows fill the frame. Front rows overlap back rows; sort by feet line (far first). All rows stay auto-planted on their own ground line. Children take an extra **0.72–0.80×** on top of their row scale.
- **Desynchronise:** every actor gets an idle phase offset (0–2.4s) and a blink offset (0–74 frames). A crowd that breathes and blinks in unison is a chorus line; the fix is per-actor phase, not more animation.
- **Foreground in front of the group:** the foreground plane must overlap the **front row's ankles**. The front row is the nearest thing in the shot; if nothing occludes it, the group floats on the plate.
- **Dialogue stays a duo:** two actors, one shared grip point, spacing per action (D.5). Never run an IK contact across a crowd — keep the interacting pair in their own depth row and let the crowd hold idle behind them.

`scripts/puppet.py --crowd N --cast a.json b.json c.json` builds this: per-actor x/scale/feet-line/phase/blink, z-sorted, with the same plant and pose maths as a single actor.

---
