# The object contract — every noun gets a build source

## The rule

The VO names physical things. Each named thing must be declared, given a build source, and be on
screen when its word is spoken. This file defines the schemas and the checks that make that
enforceable. It is the contract between elaboration (`elaboration.md`) and the renderer.

## Frozen input: `build/words.json`

The timing clock the object contract is checked against. Written by `vo_timing.py`, never by
elaboration. One entry per word:

```json
[{"w": "stamped", "start": 7.80, "end": 8.20, "seg": 3, "conf": 0.95, "est": false}]
```

`w` is the token (lowercased, punctuation stripped for matching), `start`/`end` are seconds. A word's
`[start, end]` is what the bidirectional check compares to shot windows. If `words.json` is absent,
`shotlist.py --check` warns that object timing is not checked — that is not a pass.

## `build/placements.json` — the "needed spot" contract

`objects.json` says *which* shot an object is in. `placements.json` says **where in that
shot** it is, which hand holds it, and exactly when it arrives. One row per shot/object:

```json
{"shot": "s04", "scene": "post_office_front", "start": 7.2, "end": 9.4,
 "object": "envelope", "form": "hand", "make": "puppet:envelope",
 "slot": "hand", "anchor": {"x": "right", "y": "middle"}, "hand": "r",
 "spot": "hand / right middle", "at": 8.1, "source": "voice"}
```

- `slot`: `hand`, `near` (floor / foreground), `mid` (working surfaces), or `far` (walls/back).
- `anchor`: the screen region the object must occupy — blocking and scene authoring must honour it.
- `hand`: `r` or `l` for hand props; `null` for plate/set dressing.
- `at`: seconds, always inside the shot window; for a VO-named object it is the word's midpoint.
- `source`: `voice` (the script named it) / `inventory` (the place requires it) / `cast` (a role carries it).

`elaborate.py --check` fails when a row has no slot, a hand prop has no socket, `at` falls
outside its shot, or a spoken object's word midpoint is not inside a shot that places it
(±0.35 s). A listed object with no placement is the same failure as a missing object.

## `build/objects.json`

The small, machine-readable declaration consumed by `shotlist.py --objects`.

```json
{"objects": [{"id":"envelope","kind":"hand","words":["envelope","mail"],"appears":["s01","s04"]}],
 "abstract": ["never","again"]}
```

| Field | Meaning | Required |
|---|---|---|
| `objects[].id` | stable identity of the thing; used in `beats.tsv` `objects` column | yes |
| `objects[].kind` | `hand`, `plate` or `set` — which build family resolves it | yes |
| `objects[].words` | word tokens that trigger it; matched lowercased, punctuation stripped | yes |
| `objects[].appears` | shot ids where it is on screen; must exist in `shotlist.json` | yes |
| `abstract` | content words that are deliberately not physical (never, again, time) | no |

`--check` refuses on an entry without an `id` or an `appears` shot that is not in the shotlist.

## `build/story_bible.json`

The full elaboration record — domains, locations, inventory, cast, objects, expanded script and
coverage.

```json
{
  "version": 1,
  "domain": "post_office", "domain_label": "Post office",
  "voice": {"script": "...", "words": 73, "duration": 28.3},
  "locations": [
    {"id": "post_office_front", "label": "Front counter", "why": "...", "time_of_day": "day",
     "palette": ["#...", ...],
     "inventory": [
       {"id": "sorting_counter", "label": "sorting counter", "form": "plate",
        "make": "plate:box", "where": "mid", "words": ["counter","desk"], "essential": true}
     ]}
  ],
  "cast": [
    {"id": "postmaster", "role": "postmaster", "body": "coat", "hat": "cap",
     "garment": "navy uniform", "hex": "#3B5B8C", "props": ["envelope"],
     "words": ["postmaster"], "location": "post_office_front"}
  ],
  "objects": [
    {"id": "envelope", "label": "envelope", "words": ["envelope","mail","letter"],
     "form": "hand", "make": "puppet:envelope", "appears": ["s01","s04"],
     "source": "voice", "at": [1.2, 4.6]}
  ],
  "abstract": ["never", "again", "time"],
  "expanded_script": [
    {"shot": "s01", "start": 0.0, "end": 2.1, "voice": "Never grab your bag",
     "detail": "Wide of the front counter; postmaster behind it, mailbag at their feet, envelopes stacked on the sorting surface.",
     "framing": "wide", "scene": "post_office_front", "on_screen": ["mailbag","sorting_counter","envelope"]}
  ],
  "coverage": {"words_total": 73, "classified": 73, "unclassified": [], "objects": 18, "locations": 3}
}
```

Field notes:

- `locations[].inventory[].make` is the build source; `essential: true` marks the domain's
  must-supply items. `where` is staging (`near`/`mid`/`far`), `words` links the VO, `form` mirrors
  the build family.
- `cast[].props` lists the prop ids that character holds; `location` is the role's home — the role
  must appear in a location that makes sense (postmaster in the post office).
- `objects[].at` is the time window derived from the triggering word; `source: "voice"` means the
  noun came from the VO (never invent a spoken object that is not in the script).
- `coverage` is the classification census. `unclassified` must be empty before the gate passes.

## The bidirectional check

`shotlist.py --check` reads `words.json`, `objects.json` and `shotlist.json` and checks both
directions:

1. **Object declared but never on screen = fail.** Every `objects[].id` must appear in at least one
   shot's `objects` list. A contract entry with no `appears` hit is a defect.
2. **Word spoken while its object is off screen = fail.** For each word matching a declared
   `words` token, some listed object must be on screen in a shot whose window covers the word's
   `[start, end]` (with a ±1.0 s tolerance). This is the same defect seen from the audio.
3. **Unclassified content word = warn.** A non-stopword that is neither a declared object nor in
   `abstract` must be resolved — make it an object or declare it abstract. Warnings are not
   delivery-passing; resolve them.

Worked example of the two failure directions:

- `objects.json` declares `envelope` with `appears: ["s01","s04"]`, but no shot lists `envelope`
  → **fail**: "object 'envelope' is declared but never appears in the film".
- A word `stamped` at 11.00–11.40 s matches the `rubber_stamp` object, but the only shot containing
  it runs 6.10–7.80 s → **fail**: "stamped is spoken at 11.00s while rubber_stamp is not on screen"
  (the ±1.0 s tolerance covers a shot ending at 10.00 s or later; 7.80 s is too far). Move the shot
  window, never the word.
- A token like `morning` that is neither a declared word nor in `abstract` → **warn**: resolve it
  before delivery.

This is why elaboration and shotlist are one pipeline: the word timing (`words.json`) and the object
declaration (`objects.json`) must agree with the shot's on-screen list.

## Canonical build sources

| Prefix | Meaning | Resolution requirement |
|---|---|---|
| `puppet:<kind>` | hand prop drawn in a hand socket | `<kind>` must exist in `PROP_KINDS` from `puppet.py --list-props`; if it does not, declare the object as `set:` or add the kind — never leave it unresolved |
| `plate:<primitive>` | geometry in the plate | `<primitive>` ∈ `box` / `cylinder` / `sphere` / `cone` / `quad` / `room` / `floor`, and it must appear in **that location's** scene spec (`build/scenes/<location>.json`) |
| `set:<id>` | dressing authored into the plate | `<id>` is a named dressing entry in the location's scene spec; it is placed, not held |

Rules:

- A noun with no resolvable `make` is a fail (gate 29). Do not rely on the beat text to conjure it.
- Use `solid` manufactured materials (`{"solid": true, "color": [...]}`) for panels, cabinets,
  counters, painted metal; reserve photo scans for stone, timber and rust (`world.md` C.1).
- `plate:` primitives need sufficient count and scale to read at 1080×1920: the almirah is a set of
  box pigeonholes, not one untextured cube.

Primitive → object cue:

| Primitive | Typical dressing |
|---|---|
| `box` | counter, almirah, cabinet, shelf, sign, crate, desk |
| `cylinder` | stamp handle, scale weight, tin, pot, post, lamp base |
| `sphere` | mailbag, sack, cushion, fruit pile |
| `cone` | lampshade, barrier, hat on a hook |
| `quad` | notice surface, poster, picture, floor decal |
| `room` / `floor` | the standing space itself (not a dressing item) |

A `plate:` source whose primitive is not in the location's `geometry` list cannot render: add it to
the scene spec or reclassify as `set:`.

## Domain → essential inventory

Each domain supplies these concrete nouns as a minimum. This is the seed of its location
inventories; add from the eight atom questions for `--detail 3`.

| Domain | Essential objects |
|---|---|
| `post_office` | sorting counter, pigeonhole almirah, envelopes, parcels, rubber stamp, weighing scale, mailbag, notice board |
| `airport_cabin` | seat back, tray table, seatbelt, overhead bin, window, safety card, cabin bag, flight attendant |
| `kitchen` | counter, sink, stove, pot, knife, cutting board, cupboard, tea towel |
| `street_market` | stall canopy, crates, produce piles, weighing scale, price board, canvas bags, vendor, coins |
| `office` | desk, chair, monitor, keyboard, paper stack, filing cabinet, pen, wall clock |
| `classroom` | desks, chalkboard, chalk, books, satchel, teacher's pointer, notice board, chairs |
| `clinic` | examination couch, stethoscope, medicine cabinet, chart, syringe, tray, lamp, waiting chair |
| `workshop` | workbench, vice, hammer, tools, timber offcuts, lantern, shelf, apron |
| `station` | platform, bench, timetable board, ticket window, luggage, clock, rails, signal post |
| `home` | door, table, chairs, lamp, shelves, cup, rug, coat hook |
| `bank` | counter, grille, ledger, cash drawer, pen, queue rail, notice board, vault door |
| `restaurant` | table, chairs, plates, cutlery, menu, counter, till, kitchen pass |
| `library` | bookshelves, books, reading table, lamp, catalogue drawers, stamping desk, chair, quiet sign |

## Hand-socket rules

Hand props are resolved by `puppet.py`:

- `hand` — which socket owns the prop (`left` / `right`); `upright` — world-vertical option (a scale
  or a stamp stays upright while the arm rotates); `scale` — rig-relative size.
- `at` — the socket position; `parent_switch_at` — the contact frame on which ownership changes in
  a handoff. It must equal the hand-grip contact frame (`build-contracts.md` 3.4).
- Props are drawn at **rig-relative scale** (`size` is a fraction of character height, ~0.20 of it
  for a full prop), so a hammer is never a giant club in a wide shot or a toy in a close-up. A prop
  that "balloons on close-ups" is a prop sized in absolute screen pixels — a fail (gate 8/30,
  failures.md).
- Draw order: props after the torso, before the near arm, so the hand closes over the handle.

## Continuity

- Identity is stable across shots: `id`, colour, wear do not change. The creased letter in s03 is
  the creased letter in s05.
- A handoff uses one contact frame; both actors' IK resolve to the same grip point at that frame.
- A prop that leaves frame is accounted for: put down, handed over, or exits with its owner.
- Wardrobe + prop state per shot range comes from `characters.json` (`wardrobe_states`);
  `objects.json` says which shots the object is on screen.
- Prop IoU ≥0.80 against the sheet prop; prop/hand distance ≤0.5px — measured on every frame
  (`characters.md` B.1, gate 9/15).

---

Every object in the contract must resolve to geometry or a rig part, appear in a shot, and match a
word. If any of those three links is missing, the object is a promise the film does not keep.
