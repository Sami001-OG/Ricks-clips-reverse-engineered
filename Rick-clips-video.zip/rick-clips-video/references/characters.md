# Character system — 2D cutout actors

## Contents

- [B. Character system (2D cutout actors — cast is story-driven)](#b-character-system-2d-cutout-actors--cast-is-story-driven)
- [B.1 Consistency system (the part that usually breaks)](#b1-consistency-system-the-part-that-usually-breaks)

### B. Character system (2D cutout actors — cast is story-driven)

**The rule:** the cast is **not fixed**. Every new story gets its own characters, designed from the roles that story needs. What stays fixed is the **rig** and the **rendering grammar** below. Never reuse the reference films' cast unless the new film is the same story.

**Rig (invariant — never changes between characters or shots)**
These numbers were measured off the locked references (Ref 2 close-up, Ref 1 mid shot) and the
`prospector` test rig; use them, do not re-invent them.

- Head: large oval, ≈**1.02× as wide as tall**, **no neck** — it sits directly on the torso and overlaps its top edge by ~3% of head height. **Head height = 0.33 of total character height.**
- Body: the **base body** is a **rounded-square capsule**, not an ellipse — flat-ish base, top corners rounded to ~0.17 of body width, **body height = 0.38**, body width = **0.92 × head width** (the body is almost as wide as the head; a narrow body reads as a stick figure). Story-specific silhouettes are variants of this body (see **Body archetypes** below); the proportions and the skeleton maths never change.
- Legs: **0.29 of height**, hung from the body's bottom edge at ±0.21 of body width, near-vertical when idle. Limbs are **solid black strokes** of **2.2–2.6% of character height** — the outline *is* the limb; never draw a coloured sleeve inside a black casing.
- Hands: solid black discs ≈1.0× limb width. Shoes: flattened black ellipses ≈1.55 × 0.72 limb width, nudged forward of the ankle.
- Face plate: **pure white (#FFFFFF)**, perfectly flat, no nose/ears/chin. Reference faces are pure white with **no gradient** — ambient shading belongs to the 3D plate, not the face.
- Eyes: **white discs with a black outline and a solid black pupil.** Diameter ≈**0.21 of head width**; centres ±0.205 head width from the centre line. Pupil diameter ≈0.55 × eye diameter (0.42 when shocked), offset 0.12 eye-radius toward the look direction. Closed/happy = thick ∩ arc. Blink = 2-frame closed arc. *(This replaces the earlier "solid black dots, no whites" note — the references clearly show whites.)*
- Eyebrows: **solid black rounded bars**, 0.175 × 0.058 of head width, sitting 1.65 eye-radii above the eye centre. Angry = inner ends **down**; worried = inner ends **up**; neutral = flat. Rotate the pair in opposite directions, never move them apart.
- Mouth: thick black stroke ≈**0.235 of head width** wide. Neutral = shallow upward curve; talking = maroon oval (#7A1F24) with a 0.36 width ratio; happy = wide smile arc (optionally a white teeth band); angry = downward curve; shocked = small tall oval.
- Hair: solid near-black (#17130F), chunky shapes only — `short` (fringe + top), `bob` (fringe + side mass to 0.52 head height), `long` (to 0.72), `bald`.
- **Outline:** every part is wrapped in a solid black stroke of **0.95% of character height** (≈3px at 330px tall, ≈9px at 950px). The stroke is constant in *screen* px, so it must not be scaled with the head.
- Hats are the silhouette cue and are drawn **larger than life**: brim ≈1.56 head widths for a campaign hat, crown height ≈0.26 head height; top hat crown ≈0.60 head height, flat top, band at the base; bowler = low dome + band; cone/straw = wide brim + cone; helmet = dome + plume + brow band; cap = low dome + forward brim.

Proportions never change between shots: `head 0.33 · body 0.38 · legs 0.29`, and the visible height is ≈0.97 of the nominal height because the head overlaps the body.

**Body archetypes (the silhouette is the body, not the hat).** A hat alone cannot make a cast read at thumbnail size — a crowd of different hats on one body still looks like clones. Six archetypes cover the reference cast; pick one per character *before* choosing headwear, and keep the same rig maths so every pose, action, IK contact and prop socket still applies:

| Archetype | head / torso / legs | torso w (× head w) | hem (× torso w) | Shape | Use |
|---|---|---|---|---|---|
| `capsule` | .33 / .38 / .29 | 0.92 | 1.00 | rounded-square body | default adult |
| `dress` | .33 / .44 / .23 | 0.90 | 1.26 | A-line skirt past the hip, V neck, waistband | women, robes, gowns, cassocks |
| `coat` | .33 / .40 / .27 | 0.94 | 1.14 | flared body, dark lapels, centre seam, belt | duster, frock coat, merchant, gambler |
| `armour` | .33 / .38 / .29 | 0.88 | 1.08 | trapezoid + shoulder pauldrons + chest ridge + rivets | soldier, knight, conquistador |
| `child` | .37 / .35 / .28 | 0.88 | 1.02 | rounder capsule, bigger head | child, sidekick, apprentice |
| `elder` | .34 / .37 / .29 | 0.90 | 1.04 | 7° hunched spine, shawl bands | elder, veteran, hermit |

Rules:
- The archetype is **geometry, not costume paint**: skirt/coat tails hang past the hip and hide the top of the legs, so the legs stay rigged and plant normally underneath.
- Two characters may share a hat; they may **not** share the same body + hat pair. Test the cast in pure black at 100px tall — if two silhouettes are indistinguishable, change a body.
- A beard is a head layer, not a body: draw a **horseshoe** (jaw masses + chin patch + moustache) that leaves the mouth clear, or lip-sync dies under it. `beard: true` on the card.
- Elder hunch is a **body trait**, applied to the torso lean every frame, so it survives walking, talking and gesturing.
- A `child` at the same depth is **0.72–0.80× the adult height in px** as well as having a bigger head ratio; the archetype alone is not enough — a child drawn at adult height reads as a short adult.
- On flared bodies the **arms draw in front of the garment** (a hanging forearm would otherwise vanish inside the skirt). That is a layering rule, not a pose change.
- The consistency gate is a *sanity band*, not a target: tall headwear legitimately pushes head/height to ~0.41 and a flared dress pushes face/body to ~0.97. Strict drift is caught by sheet IoU, not by the absolute range.

**Character builder (variable — solved per story, before any asset is generated)**
Design 3–6 characters that the script actually needs. For each one fill this card:

| Slot | What to decide | Constraint |
|---|---|---|
| Story function | protagonist / obstacle / ally / victim / crowd | must be readable in one shot |
| Silhouette cue | hat, helmet, hood, parasol, apron, height delta | **no two characters share a silhouette cue** |
| Headwear / hair | campaign hat, top hat, bowler, war helmet, headband, top-knot, bowl cut | shape must read at thumbnail size |
| Garment | robe, vest, cuirass, sweater, suit | one flat identity colour + black trim |
| Identity colour | one hex per character | pick from a **6-colour story palette** (see below) |
| Prop | drill, pan, fuse, letter, magnifier, flag | carried in the hand or planted in the scene |
| Expression range | which 3–5 of the expression set the role uses | must include neutral + talking |
| Notes | age/era cues, uniform details, badges | era-consistent for the setting |

**Expression set (bake these for every character):** neutral (dots), talking (small open oval), happy/smiling (∩ eyes + wide open mouth, sometimes with teeth), smug (half-lidded + flat brows), angry (down-inward brows), scared (small dots + raised brows), dead/unconscious (x or flat-line eyes, open mouth), shocked (big open mouth), sly (one brow raised). Each character uses 3–5 of these — not all nine.

**Story palette method:** choose 6 colours, 2 warm, 2 cool, 1 neutral, 1 accent. Give the protagonist the accent, the antagonist the darkest, the crowd a single desaturated colour. Keep every character's colour at least ~30° of hue away from the environment's dominant hue so they pop off the 3D plate.

**Casting checklist (stage 5 exit, before any sheet is drawn):** every character has one card; silhouettes are distinguishable in pure black; no two characters share identity colour + shape; the protagonist is identifiable in the first 3 seconds; the crowd reuses 3–6 of the *story's own* characters with different body archetypes — never invent one-off extras, and never repeat one body+hat pair (D.13).

#### B.1 Consistency system (the part that usually breaks)
Consistency is not "prompt it carefully". It is **one canonical asset + one data file + measured drift checks**. A character is finished only when it is *reproducible*, not when it looks good once.

**1. One canonical sheet per character — the only source of truth**
`assets/characters/<id>/sheet.png` — 4096×2048, four views and an expression grid:
- Row 1: front · 3/4 · side · back (same scale, same ground line, same light).
- Row 2: the 3–5 expressions that character actually uses (Section B expression set), plus one neutral "rest" pose used for every idle.
- Row 3: the limb parts laid out flat with **pivot dots marked** (upper arm, forearm, hand, thigh, shin, shoe, hat, prop) — these are the parts the rig is built from (Section D.2).

Every downstream shot **references this file**. If an image model is used, pass `sheet.png` as the reference image (or LoRA/seed locked from it) — never re-describe the character from text alone. Text descriptions drift; pixels do not.

**2. `assets/characters/characters.json` — the machine-readable identity**
```json
{
  "story": "mine_con_1899",
  "version": 3,
  "palette": {"sky":"#4080C0","sandstone":"#A08060","key_prop":"#C02828"},
  "characters": [
    {
      "id": "prospector",
      "role": "protagonist",
      "sheet": "assets/characters/prospector/sheet.png",
      "rig": "assets/characters/prospector/rig.svg",
      "rig_version": 3,
      "height_ref_px": 780,
      "proportions": {"head_h": 0.33, "torso_h": 0.38, "leg_h": 0.29,
                      "head_w_ratio": 1.02, "torso_w_ratio": 0.92},
      "outline_px": 3,
      "hex": {"garment": "#C8282C", "garment_alt": "#1A1A1A", "hair": "#17130F",
              "face": "#FFFFFF", "trim": "#111111", "accent": "#E0B020"},
      "silhouette_cue": "campaign hat, wide brim",
      "props": [{"id": "gold_pan", "hand": "right", "socket": "hand_r"}],
      "expressions": ["neutral", "talking", "happy", "angry", "shocked"],
      "wardrobe_states": {"s01-s18": "clean", "s19-s28": "dusty, hat brim bent"},
      "forbidden": ["nose", "ears", "realistic eyes", "textured fabric", "neck"]
    }
  ]
}
```
Rules: **one hex set per character, reused verbatim in every prompt and every SVG fill**. `rig_version` increments whenever geometry changes; a shot records the version it was rendered with so drift is traceable. `wardrobe_states` maps shot ranges to physical state (wet, dusty, injured, hat lost) — this is what makes continuity feel real.

**3. Measured drift checks (run on every generated frame that contains a character)**
Cut the character out (alpha or silhouette threshold) and compare against the sheet:

| Check | Method | Pass |
|---|---|---|
| Silhouette | IoU of character mask vs sheet pose, after scale/translate align | **≥ 0.85** when that pose exists on the sheet; otherwise advisory (a walk or handshake changes the outline legitimately) |
| Identity colour | mean ΔE (CIEDE2000) in garment region | **≤ 4** |
| Outline present | dark-pixel ring width around silhouette | **0.9–1.1% of height, ≥90% of perimeter** |
| Proportions | head (incl. headwear) / total height | **0.28–0.42** (target 0.33 for a plain capsule; headwear adds up to 0.08) |
| Head width vs body | face width / **torso band** width (just below the face) | **0.92–1.20** (target 1.09; a flared skirt must not be measured) |
| Limb thickness | limb width / character height | **2.2–2.6%** |
| Face purity | % of face plate near-white | **≥ 96%**, no features inside |
| Prop identity | prop mask IoU vs sheet prop | **≥ 0.80** |

Any failure = **reject the frame**, re-render from the sheet, never "fix in post". Log the result per shot in `analysis/consistency.csv` so a reviewer can see which shot broke and how badly.

**Measure the render, not the spec.** Every number in B is a *rendered* measurement: cut the mask out of a PNG and take its bbox. Two real bugs survived visual review and were caught only by measuring — a torso drawn at half height (garment 171px tall on a 342px body) and eyes sized off the head *width* while the code used head *height*. If a character looks wrong but the code "matches the spec", measure the output before changing either.

**4. Drift you must actively prevent**
- **Scale drift** — a character slowly getting bigger/smaller across shots. Fix: lock `height_ref_px` and derive per-shot scale from depth, never from eyeballing.
- **Outline drift** — thinner outline in wide shots, vanishing in dark scenes. Fix: outline is a stroke, not a filter; it does not scale with distance below 2px.
- **Colour drift** — garment shifts warm/cool with the grade. Fix: grade the plate and the characters *separately*, or grade the whole frame then re-check ΔE.
- **Face drift** — a nose, chin or ears appear. Fix: flat white plate is a hard rule; regenerate, never paint over.
- **Wardrobe drift** — hat on/off, stains appearing and disappearing. Fix: `wardrobe_states` is authoritative; a shot must match its range.
- **Prop-hand drift** — the object switches hands across a cut. Fix: `props[].hand` is fixed unless a D.5 hand-off action explicitly transfers it.

**5. Versioning**
`sheet.png` and `rig.svg` are versioned together (`rig_version`). Changing either bumps the version, and **every shot rendered from the old version is re-rendered** — partial upgrades are how casts end up looking like two different films.

**Reference design vocabulary (examples of the grammar — not a fixed cast)**
Use these as mark-making references when the new story has an equivalent role; do not copy the role itself.

**Ref 1 (fort / “Trojan horse” siege)**
| Role | Design |
|---|---|
| Official (protagonist) | **Red robe (#C02030)** with black trim and belt, dark brown hair combed back, white face, small black dot eyes. Appears in most scenes: at the cart, in the rain, at the finale. |
| Artisan / carpenter | **White headband** over dark brown hair, bare cream-tan torso or light tan tunic, working at the horse-cart with a drill. |
| Guards | **Grey wide-brim war helmet** with gold band and red trim + **green robe (#3E7A3A)**; a second variant in blue robe (#2F5FA0). White faces, bored/angry brows. |
| Fort commander | **Silver helmet with tall red crest (#C8202A)**, **navy studded cuirass (#2A3E70) with gold dots**, gold trim and **red skirt panel**; heavy black brows. Primary antagonist at the gate. |
| Warlord / general | **Black robe**, tall dark helmet, white face, holds a **yellow parasol (#E8C040)** above himself; appears in the army-charge wide shot. |
| Massed army | Hundreds of identical **yellow-gold lamellar soldiers (#E0C040)** with black chevron rows and dark helmets, carrying **yellow flags**. |

**Ref 2 (Australian “Sure Thing Mine” con)**
| Role | Design |
|---|---|
| Prospector / owner | **Brown campaign hat (#6B4A2A)** with a round gold badge, **red-and-black vertically striped vest (#C8282C / #1A1A1A)** over a white shirt, thin black limbs, big confident smile. |
| His buddy | **Yellow hard hat (#E0B020)** with brim, **green sweater (#2E8C5A)**, black bowl-cut hair, white face; frequently beside a crate stamped `CANDLES` with a blue enamel kettle. |
| Rich investor | **White/ivory top hat (#F2EFE6)** with black band, **plain white-ivory suit body**, **black handlebar moustache**, tiny round spectacles, often arms spread wide. |
| The “expert” | **Black bowler hat**, **plum/maroon suit (#5E2A3C)** with gold watch chain, white face, permanently angry brows; magnifying glass, later a pickaxe. |
| Crowd / townsfolk | 1890s extras — dark suits, bowler/top hats, bonnets and dresses, small in frame, static idle poses. |

---
