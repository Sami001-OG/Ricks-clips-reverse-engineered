# Voice understanding and caption timing

## Contents
- What "word timing" means here
- The five modes, best first
- Commands
- What forced alignment actually does
- What it measures (and what it does not)
- Files it writes
- Refusal rules
- Speech recognition: what to install, what is usually blocked
- Sanity numbers

## What "word timing" means here

A caption is only allowed to change on a word that was actually spoken at that
instant. There are three ways to know that instant:

1. **The timings are given to you.** An SRT/VTT from the recorder or TTS tool carries
   real cue times. This is the highest-fidelity input and needs no inference.
2. **A model listens.** Whisper / Vosk produce word timestamps directly.
3. **The audio is measured, and the text is placed into it.** With a transcript but no
   model, the speech/silence structure of the audio still tells you where a sentence
   starts, ends and pauses. That is forced alignment, and it is what this skill uses
   when no model is reachable.

What is **not** allowed: writing captions from pause segments alone, or spreading a
script evenly across the timeline and calling it synced. Both produce captions that
visibly lag or lead the voice.

## The five modes, best first

| Mode | Needs | Timing source | Accuracy | When chosen |
|---|---|---|---|---|
| `srt` | SRT/VTT file | real cue boundaries | exact cues, words inside a cue interpolated | a subtitle file exists |
| `asr` | local Whisper/Vosk | model word timestamps | ±1–2 frames typically | a model imports successfully |
| `align` | transcript + audio | energy-segmented speech + syllable distribution + boundary snapping | measured **21 ms mean / 40 ms max** on synthetic ground truth; expect 30–70 ms on real speech | transcript exists, no model |
| `estimate` | transcript + audio | even syllable spread inside each segment | 100–250 ms | the user explicitly asks for estimates |
| `segments` | audio only | none | — | nothing else is possible; **writes no captions** |

`--mode auto` picks the first available in that order. It never silently downgrades:
the mode it used is written to `build/audio.json` and printed.

## Commands

```bash
# best case: the recorder or TTS gave you subtitles
python3 scripts/vo_timing.py voice.mp3 --srt voice.srt

# the normal case: the user pasted the script
python3 scripts/vo_timing.py voice.mp3 --transcript script.txt

# forced alignment, even when the transcript arrives after the first attempt
python3 scripts/vo_timing.py voice.mp3 --transcript script.txt --mode align

# only when the user says "estimate is fine"
python3 scripts/vo_timing.py voice.mp3 --transcript script.txt --mode estimate

# nothing to align yet: learn the pause structure, ask one precise question
python3 scripts/vo_timing.py voice.mp3
```

Then burn the captions:

```bash
python3 scripts/caption_cards.py build/captions.json \
        --base out/base.mp4 --out out/final.mp4 --run
```

`caption_cards.py` writes `build/cards/overlay.sh` either way; `--run` executes it.
The default base is `build/base.mp4`, the default output `out/final.mp4`.

## What forced alignment actually does

1. **Decode** to 16 kHz mono through ffmpeg (no extra Python audio dependency).
2. **Envelope**: 20 ms window, 10 ms hop, RMS in dB → 10 ms boundary resolution.
3. **Segment** with two thresholds: `lo = noise + 0.22·(peak−noise)` decides how far a
   phrase extends, `hi = noise + 0.35·(peak−noise)` decides whether it exists at all.
   Hysteresis beats a single threshold, which either clips quiet consonants or lets
   breaths become segments. Runs shorter than 80 ms are dropped; gaps shorter than
   140 ms are merged; each segment is padded 30 ms.
4. **Distribute sentences over segments** with dynamic programming: minimise the
   mismatch between each segment's share of speech time and its share of syllables.
   This is what handles the awkward real case — a 4.5 s segment that clearly holds
   two sentences next to a 1 s segment that holds one — without guessing per-line.
5. **Distribute words inside their own segment** by syllable weight.
6. **Snap every internal boundary** to the middle of the quietest run within
   ±30% of the shorter neighbouring word (capped at 250 ms). Boundaries between
   segments are never snapped, so a word cannot be dragged across a real pause.

The snapping step is the difference between "approximately synced" and "on the word":
a caption edge that lands in a measured valley is where the speaker actually paused.

## What it measures (and what it does not)

Reported per run in `build/audio.json`:

- `mode` — srt / asr / align / estimate / segments
- `segments`, `words`, `captions`
- `mean_conf` — mean boundary confidence (0.0–1.0). Low confidence means syllables
  ran together; it does **not** mean the caption is wrong, but it does mean you should
  not claim frame accuracy.
- `longest_word_s` — above ~1.0 s usually means a boundary was missed
- `warnings` — named degradations, never silent

It does **not** measure which words were said. With no model, the words come from the
transcript — so if the transcript is wrong, the captions are wrong in the same way.

## Files it writes

| File | Contents |
|---|---|
| `build/segments.json` | speech segments: `i, start, end, dur, db` |
| `build/words.json` | `w, start, end, seg, conf, est` per word |
| `build/captions.json` | `text, start, end, words[], est` — feeds `caption_cards.py` |
| `build/audio.json` | the run record: mode, counts, confidence, warnings |
| `analysis/vo_report.json` | same payload, for the QA report |

`captions.json` is generated, never hand-edited. If the timing is wrong, rerun the
tool with better input; editing the JSON puts the track out of step with the audio.

## Refusal rules

- **No transcript and no model → do not write captions.** Run in `segments` mode,
  show the segment table, and ask one question: *"Paste the words you said, or an SRT
  from your recorder — then captions land on the word."* Do not offer a menu of
  guesses as if they were equal options.
- **Estimates are opt-in.** Only after the user says so. Then every card gets
  `est: true` and the delivery note states the drift.
- **Name the fallback out loud.** "No ASR model was reachable, so I aligned your
  transcript to the audio's pauses (21 ms mean boundary error)" is honest and useful.
  "I can't do word timings" is not true, and stopping before `align` wastes a turn.
- **Never import a caption track from another video, never reuse the previous
  project's timings.** VO is the clock.

## Speech recognition: what to install, what is usually blocked

| Option | Install | Reality in a sandbox |
|---|---|---|
| faster-whisper | `pip install faster-whisper` | model downloads from Hugging Face — **often blocked** |
| openai-whisper | `pip install openai-whisper` | weights from openaipublic — also often blocked |
| vosk | `pip install vosk` + model zip | model from alphacephei.com — smaller, sometimes reachable |
| whisper.cpp | build + `ggml-*.bin` | needs a compiled binary and a model file |

`scripts/probe.py` reports which of these exist before planning (`asr` block, plus
`voice.mode`). `WITH_ASR=1 bash scripts/bootstrap.sh` attempts the pip install but
does not download models.

**Do not treat "no ASR" as "no captions".** It only means free transcription is
unavailable; a transcript gives word timings regardless of whether a model exists.

## Sanity numbers

Check these before trusting a caption track:

- **Speaking rate** 2.0–3.6 words/second. Outside that, the transcript and audio are
  probably different takes.
- **Word count** within ±5% of the transcript's word count. A large gap means tokens
  were dropped (empty segments, punctuation-only transcript).
- **`longest_word_s`** ≤ 1.0 s. A 2 s "word" is two words merged by a missed pause.
- **Caption count** ≈ words / 3 (1–4 words per card).
- **Duration**: `build/audio.json.duration` must equal the video duration ±0.3 s, or
  captions drift at the end even if every boundary is right at the start.
