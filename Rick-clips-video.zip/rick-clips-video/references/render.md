# Asset production and rendering

## Stages 4–5 — Produce assets (Claude specifies; user generates; Claude verifies)
Produce in this order — **world first, then characters, then rigs**. Never start a character before its location lighting state exists, because the character's rim colour comes from that light.

**4.1 The 3D world**
- Generate one background per location/lighting state (not per shot). Aim for 4–6 locations × 1–3 states = 8–15 plates for a 60s film.
- Every plate must pass **C.7 World QA**: ≥3 material families, consistent shadow direction, visible atmosphere, readable fg/mid/bg separation, palette from the correct C.3 row.
- Ask for 1080×1920 (or 1620×2880 then downscale), lower ~20% free of important detail, no people, no text.
- Reject: flat colour fills, uniform tiling, missing shadows, plasticky materials, a background with no depth cues.

**GPU rendering note.** `plate3d.py --quality high|cinema` is for **GPU machines**; use it when
`build/plates.json` shows a real GPU. Tiers: `low` (ss 1.0 / shadow 1024 / SSAO 8 / texture 256),
`standard` (1.0 / 2048 / 12 / 512), `high` (1.5 / 2048* / 20 / 1024), `cinema` (2.0 / 2048* / 32 /
2048). `plates.json` now records `gl_renderer / gl_vendor / gpu / quality` per plate — check those
fields to confirm the GPU was actually used. **llvmpipe is software**: llvmpipe with `cinema` is very
slow; `standard` is the validated CPU fallback and the honest choice on a software backend.

**4.2 Characters — the canonical sheet**
- Per character: one `sheet.png` (front/¾/side/back + expression grid + flat limb parts with pivot dots) per **B.1**.
- Write `assets/characters/characters.json` at the same time — hexes, proportions, outline width, props, wardrobe states. Prompt text is generated *from* this file, never typed by hand.
- Verify the sheet itself before generating any shot: outline present all round, head 0.31–0.36 of height, face pure white and featureless, silhouette cue readable in solid black.
- Then derive `rig.svg`: one layer per part, pivot at the local origin, outline drawn per part (D.2).

**4.3 Shot frames**
- For each shot, give the model the **background plate + the character sheet** as references. Never re-describe a character in words when a sheet exists.
- Run the **B.1 drift checks** on every generated frame; write results to `analysis/consistency.csv`. Failures are re-rendered, not patched.
- If the tool cannot take reference images, do not use it for characters — build the character as SVG from the sheet instead (tier 1/2). This is the fallback that guarantees consistency.

**4.4 Typography / audio** — Montserrat ExtraBold from `assets/fonts/Montserrat-ExtraBold.ttf` (fallbacks Archivo Black / Arial Black; never a thin, condensed or single-storey-`a` face). VO is master; music bed and SFX per Section F, never ducking the VO.

**Organization:** `assets/bg/`, `assets/characters/<id>/`, `assets/rigs/`, `assets/props/`, `assets/fonts/`, `assets/audio/`, `analysis/`.

## Stages 6–8 — Compose & render (Claude authors; user/runner renders)
**Claude:** author the stack for the tier reported by `scripts/probe.py` (1 Remotion → 2 Chromium → 3 PIL cards + ffmpeg). Keep it data-driven from `build/shotlist.json` + `build/anim.json` + `build/captions.json`. Optionally provide a React/HTML **Artifact** to preview caption styling — never a substitute for the final render.

### Option A — Remotion with SVG puppets (preferred)
- 1080×1920 `Composition` at 30 fps; `durationInFrames = build/vo.json.frames`; one `<Sequence>` per shot.
- **Characters render as SVG groups, not single images.** Each part is a `<g>` with its pivot at the local origin; joints rotate; children inherit. Per-character component generated from `rig.svg` and driven by `anim.json` (D.2/D.8).
- Motion: joint keyframes eased with `Easing.bezier(0.33,0,0.2,1)`; camera on `interpolate` with `linear` for dollies; per-frame floats only (no integer snapping).
- Always-on layers: idle sway, blink, breath, mouth shapes, secondary lag on hat/coat/prop, contact shadow ellipse per actor.
- Camera + parallax from `anim.json` (`bg 0.55 / mid 1.00 / fg 1.75` — the shipped `camera_plate()` defaults).
- **Assert contacts** at build time: every entry in `contacts` must resolve within `tol_px`; foot-plant check must report <1.5px drift. Fail the render if not.
- Captions: the Section E `Caption` component unchanged (Montserrat 800, 70px, `WebkitTextStroke: '11px #000'`, `paintOrder: 'stroke fill'`, `paddingBottom: 530`, hard swap, no spring/fade).
- Render: `npx remotion render Short out/final.mp4` (Node + headless Chrome required).

### Option B — HTML/CSS + headless Chromium (tier 2), or Motion Canvas
- **HTML/CSS:** one `scene.html` per shot, background full-bleed; characters as **inline SVG puppets** (same part/pivot structure) positioned per frame by a small JS driver reading `anim.json`; caption div with `-webkit-text-stroke: 11px #000` + `paint-order: stroke fill`. Screenshot every frame with Playwright at 1080×1920, then `ffmpeg -framerate 30 -i frames/%05d.png`.
- **Motion Canvas:** scene graph with the same puppet hierarchy, timed to the caption clock (hard swaps, no easing on text); easing only on camera/limb keys; export frames and mux with ffmpeg.
- **Never** animate by sliding a flat PNG of the whole body — that is what makes it look like a slideshow.

### Option C — ffmpeg assembly (works anywhere, no browser)
- Tier 3: render caption cards with the exact metrics, then overlay and encode — no browser, no Node.
```bash
python3 scripts/caption_cards.py build/captions.json   # 1080x1920 RGBA cards + overlay.sh
bash build/cards/overlay.sh                          # overlay + H.264/AAC master
```
- On this tier, characters can still be animated: rasterise the SVG puppets per frame with `cairosvg`/`resvg` (pure-Python/C, no browser), composite with PIL, and pipe frames to ffmpeg. Slower, but the motion is identical — `scripts/puppet.py` is this pipeline, working.
- **Measured cost** (phone-class ARM CPU, 1080×1920): ~1.5–3 s/frame for one actor on a plate, ~4 s/frame with a five-actor crowd. A 60 s film is 25–45 min — plan the render as one background job, not a step you wait on.
- **Grain over the composite, once.** Renders are per-shot; concatenate them with a single re-encode and lay film grain over the result:
```bash
ffmpeg -f concat -safe 0 -i build/concat.txt -vf "noise=alls=5:allf=t+u" \
  -c:v libx264 -preset medium -crf 18 -pix_fmt yuv420p -r 30 out/base_silent.mp4
```
  One grain field across plate and actor is what makes a flat-shaded puppet read as standing *in* the plate rather than pasted on it. Per-shot grain resets at every cut and looks like noise.
- **Loudness before captions.** Normalise the voice and mux before burning text, so the caption pass is a single overlay step:
```bash
ffmpeg -i out/base_silent.mp4 -i voice.mp3 \
  -filter_complex "[1:a]volume=10.6dB,alimiter=limit=0.851:attack=3:release=60:level=0,aresample=48000[a]" \
  -map 0:v -map "[a]" -c:v copy -c:a aac -b:a 192k -shortest build/base.mp4
```
  `loudnorm=I=-14:TP=-1.5` alone **does not hit −14** on a speech track with an 18 dB crest factor: it runs into the true-peak ceiling and settles ~1 LU low (measured −15.4). Apply the gain first, hold the peaks with a limiter, then verify on the encoded file — `loudnorm` reports the *input* level when used as a meter:
```bash
ffmpeg -i build/base.mp4 -af loudnorm=print_format=json -f null -   # read input_i / input_tp
```
  Two traps: `alimiter` auto-levels by default (`level=0` to disable, or it *raises* the level), and AAC overshoots the sample peak by ~0.3–0.4 dB, so limit at **−1.4 dBFS** to land at ≤ −1 dBTP after encoding.
- Or burn an ASS track when you prefer subtitle-based captions over PNG cards:
```bash
ffmpeg -i scene.mp4 -vf "ass=build/captions.ass" -c:a copy out/scene_cap.mp4
# master: 1080x1920, 30fps, H.264, AAC, faststart
ffmpeg -i video.mp4 -i voice.mp3 -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \
  -r 30 -s 1080x1920 -c:a aac -b:a 192k -ar 48000 -shortest -movflags +faststart out/final.mp4
```

If Claude Desktop computer-use or an MCP shell is available, Claude may write and run these directly; otherwise hand over copy-paste-ready files.
Note: tier 1 (Remotion) and tier 2 (Chromium) require tooling installed in the host project; this skill package ships and validates **tier 3** only. `probe.py` selects a higher tier automatically when that tooling exists.


### Fast finish — one encode, adaptive encoder (default)

The legacy stage 8 encodes the picture twice (base_silent with grade+grain, then the
caption burn) and used `-preset slow`. Both are wasteful. Two optimizations ship now:

**1. `caption_cards.py` picks the fastest encoder that actually works.** Every H.264
encoder in `ffmpeg -encoders` is proved with a throwaway 16×16 / 2-frame encode before
it is chosen — a listed NVENC without a driver fails here and is skipped. Order:
NVENC → QSV → AMF → VideoToolbox → `libx264 -preset veryfast -crf 19`. If no hardware
works, software always does. If there is **no ffmpeg at all**, it stops with one clear
message (`set FFMPEG_BIN` or run `bootstrap.sh`) instead of pretending.

```bash
python3 scripts/prop3d.py --build                   # lit 3D hand-prop sprites (once)
python3 scripts/fastencode.py --check              # prints the chosen profile
python3 scripts/caption_cards.py build/captions.json \
  --base build/base.mp4 --out out/final.mp4 --run \
  --profile auto                                   # auto | software | safe | gpu | <encoder>
```

`--profile safe` restores the old `libx264 -preset slow` path for A/B comparison.
**Preset changes speed, not the quality target:** CRF stays 19, so the picture is aimed
at the same quality; a faster preset simply writes a larger file. Never raise CRF to
go faster.

The burn also builds **one** band-sized caption stream (1080×160) and applies **one**
full-frame overlay, instead of 26 chained full-frame overlays. The cards and their
metrics are unchanged, so captions remain pixel-exact.

Measured on an 8 s CPU-only clip: `-preset slow` 33.8–48.6 s, `--profile auto`
10.5–12.2 s. This device has no working hardware encoder (llvmpipe), so that number
is the software floor; a real GPU will be faster again.

**2. `finish.py` does the whole final pass in one encode** — concat the shots, grade,
grain, overlay captions, mix the voice, encode once:

```bash
python3 scripts/finish.py --concat build/concat.txt --voice voice.mp3 \
  --captions build/captions.json --out out/final.mp4
```

It uses the same cards, the same caption filter and the same encoder probe, bounds the
output with `-frames:v` from `shotlist.json` (so the last frame cannot be dropped), and
prints the legacy fallback command if the single pass fails. Use it when the shot
clips, voice and captions are final; keep the three-pass path when debugging a grade
or a single shot. Verify the encoded result with `measure_captions.py` and `loudnorm`
either way — a faster path is only valid if the gate still passes.

## Stage 8 — Quality control (measured, against Section I)
**User:** upload output frames/contact sheets (and short preview clips) back into Claude.
**Claude:** score every item in the Section I gate and write `QA_REPORT.md`. Measure where a measurement exists — don't eyeball:

```bash
# captions: bbox, baseline, stroke width
python3 scripts/measure_captions.py out/final.mp4
# character drift: silhouette IoU, ΔE, outline coverage, head ratio
python3 scripts/consistency_check.py analysis/frames/ --chars assets/characters/characters.json
# motion: foot slide, contact misses, frozen actors, pop frames
python3 scripts/anim_check.py build/anim.json --frames analysis/frames/
# world: material variety, shadow direction, palette vs C.3 row
python3 scripts/world_check.py analysis/frames/ --palette build/plan.md
```
If a script does not exist yet, write it before scoring — an unmeasured gate item is a fail.

Score sheet to emit:
- [ ] **Format:** 1080×1920, 30 fps, duration = VO ± 0.3s.
- [ ] **Captions:** 70px Montserrat ExtraBold, baseline 1376 ±8px, 11px stroke, 1–4 words, no drift over the full duration.
- [ ] **World:** materials/texture, shadow direction, time-of-day colour, depth separation (C.7 checklist).
- [ ] **Cast:** rig correct in every shot + all four consistency metrics pass (B.1) + wardrobe/prop state correct.
- [ ] **Animation:** anticipation/contact/follow-through, two-actor contacts resolved ≤0.5px through the hold (reach ratio ≤0.92), planted-ground spread ≤0.5px, foot slide <1.5px, idle/blink/breath present, mouth ±2 frames, secondary lag, prop ownership switched on the contact frame, pose continuity across cuts.
- [ ] **Story & pacing:** shot count, mean length, hard cuts, cause→effect, reaction shots, punchline on the final shot.
- [ ] **Mix:** ≈ −14 LUFS, true peak ≤ −1 dBTP, VO clear, SFX on cuts.
- [ ] **Evidence:** cite the frame number and the measured number for every pass/fail.

Iterate (assets, rig, timing, grade, or caption styling) until every gate item passes or the user explicitly accepts a named deviation.
