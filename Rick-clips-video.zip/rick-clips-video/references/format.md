# Format contract — the two locked references

## Locked references & embedded spec (these videos)
- **Ref 1:** `https://m.youtube.com/shorts/i4hYq1oSXTg` — 66.854s, 1080×1920, 30fps, ~2005 frames, vp9+opus.
- **Ref 2:** `https://m.youtube.com/shorts/TRUkQ1wbV2E` — 61.094s, 1080×1920, 30fps, ~1832 frames, vp9+opus.

**You do not need the source footage to run this skill.** Every number in Sections A–I was measured from full-resolution frames of these two videos, and the measurements are written into this document. Re-acquire the videos only if you want to re-derive a figure or do a frame-accurate diff:

```bash
yt-dlp -f 'bestvideo[height<=1920]+bestaudio' -o ref/raw/ref%N.mp4 <url>
ffmpeg -i ref/raw/ref1.mp4 -vf fps=30 ref/frames1/%05d.png
```

**Programmatic notes (non-visual, detected):**
- Ref 2 hard cuts (`select='gt(scene,0.12)'`): ~9.2s, 10.7s, 16.1s, 21.47s, 24.53s, 27.47s, 35.67s, 43.17s, 45.33s, 46.23s, 51.2s, 53.77s, 54.73s.
- Ref 1 hard cuts: ~2.03s, 24.9s, 25.9s, 37.9s, 60.73s — the rest is achieved with continuous camera moves (see Section A/D).

### Embedded visual spec (STATUS: COMPLETE — extracted from the reference frames)

Everything below was read directly off the reference frames (full-resolution pixels) and is written out here so the footage is not needed. Treat these numbers as the contract: a new video is “the same video” when a frame-accurate diff against these values is clean.

---

### A. Master format (both references)

| Property | Value |
|---|---|
| Canvas | 1080×1920 (9:16 vertical) |
| Frame rate | 30 fps (constant) |
| Duration | Ref 1 = 66.854s (2005 frames) · Ref 2 = 61.094s (1832 frames) |
| Video codec | VP9 (YouTube) — deliver H.264 High, yuv420p, CRF 18–20, AAC 128–192k, +faststart |
| Camera motion blur | present on fast moves (simulate with 2–4 frame directional blur on whip moves) |
| Depth of field | yes — backgrounds soften ~15–25px at 1080 when a character is in focus |
| Film grain | light, uniform, ~2–3% opacity |
| Color | rich, saturated, warm highlights / cool shadows; never flat or desaturated |

**Shot rhythm:** shots are short (1.5–3.0s, mean ≈2.2s) → **26–30 shots for a 60s video**. Cuts are **hard cuts** — no dissolves, wipes, fades or zooms-as-transitions. Detected hard cuts in Ref 2: 9.2, 10.7, 16.1, 21.47, 24.53, 27.47, 35.67, 43.17, 45.33, 46.23, 51.2, 53.77, 54.73s. Ref 1 has few cuts (2.03, 24.9, 25.9, 37.9, 60.73s): it holds a scene and moves the camera instead — **shot changes can be achieved by moving the camera**, not only by cutting.

**Narrative grammar (both refs, ~60s):**
`0–5s HOOK` (a striking image + first caption word) → `5–15s SETUP` (who/where, wide establishing shots) → `15–40s ESCALATION` (problem, plan, execution; alternating detail/medium/wide) → `40–55s CLIMAX` (complication, reveal, payoff) → `55–61s RESOLVE` (final wide/hero shot + last word). Last caption word is the punchline; video ends ~0.3–0.5s after the last word.

---
