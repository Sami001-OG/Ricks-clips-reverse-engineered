# Story elaboration — the mandatory stage

## Why this stage exists

A voiceover line is a **seed, not a script**. "A postmaster sorted the letters" names one verb and
two nouns; the film it must become contains a room, furniture, tools, paper, light, other people and
the marks they leave. Elaboration is the stage that expands each seed into the physical inventory a
camera can shoot. It runs **after** `vo_timing.py` (word times exist) and **before** shotlist, cast,
plates and animation. It is not optional: a film that skips it is a film of a narrator describing
things the audience never sees.

The controlling rule, verbatim: **"simply what'll be in the script must be in the video also."**
Every physical thing the VO names must be **on screen at the moment it is named**. A bag the
narrator says is grabbed must be in the hand in that shot; a letter that is "sorted" must be in the
hand at the almirah, not cut away to a reaction shot of a clock. Elaboration enforces that by giving every
noun a build source, a location, a shot and a time window.

The output of the stage is an **atom list**: one row per physical detail, each row carrying:

- the **noun** (and the word timing that triggers it),
- a **build source** (`puppet:`, `plate:`, `set:` — see `references/objects.md`),
- a **location** it belongs to,
- a **shot** it appears in,
- a **time window** `[at, until]` inside that shot.

The atom record (the unit the tools pass around):

| Field | Meaning | Example |
|---|---|---|
| `noun` | the physical thing, from the VO | `envelope` |
| `words` | tokens that trigger it | `["envelope","mail","letter"]` |
| `make` | build source | `puppet:envelope` |
| `location` | home location id | `post_office_sorting` |
| `shot` | where it is on screen | `s03` |
| `at` / `until` | seconds, from the trigger word / shot end | `4.6 / 6.1` |
| `source` | provenance | `voice` |

**Never add spoken words.** Elaboration adds on-screen detail mapped onto existing word timings. The
VO, `words.json`, `captions.json` and the audio are frozen inputs to this stage. Compare hashes
before and after: if any of them changed, the stage was done wrong.

**Why one sentence becomes many shots.** A 2.1 s clause such as "sorted the letters" can carry a
close on hands at the almirah, an insert on a bundle, a stamp ECU and a scale-pan dip. The words set
the *when*; elaboration sets the *what* and *where*. Detail is cut by changing framing and by
packing atoms into a window — never by dropping the nouns the VO utters. A film that shows fewer
things than it names is the complaint this stage exists to prevent.

## The eight atom questions

For every shot, answer all eight. A shot that cannot answer all eight is under-elaborated; do not
move on. These are the detail pass at `--detail 3`.

1. **Place** — what is the location, and which corner of it are we in?
2. **Hands** — what is in the character's hand (or hands)? Name the prop kind.
3. **Surfaces** — what is on the counter / table / desk / shelf the action touches?
4. **Walls** — what hangs on the walls (notices, boards, hooks, a clock, a poster)?
5. **Floor** — what is on the floor (a mailbag, a dropped bundle, a basket, a mat)?
6. **Light** — what is the light source, and where does it fall? (source from `world.md` C.3.)
7. **Human trace** — what shows somebody has been here (a half-sorted pile, an open drawer, a
   chair pushed back, a smudge on the glass)?
8. **Change** — what is different at the end of the shot from the start (a stamp pressed, a letter
   moved from pile to slot, a scale pan dipping)?

Questions 3–5 are where "too few objects" gets fixed: they turn a bare room into a room full of
things. Question 8 is what makes a shot a beat rather than a still.

## Command sequence

```bash
python3 scripts/elaborate.py --voice script.txt --words build/words.json --captions build/captions.json
python3 scripts/elaborate.py --voice script.txt --words build/words.json --domain post_office --detail 3
python3 scripts/elaborate.py --check build/story_bible.json --words build/words.json --shotlist build/shotlist.json
```

- The first pass reads the voice and the frozen timings; it detects the domain and proposes a
  location inventory and an atom per content word.
- The second pass pins `--domain` (skip when detection is correct) and sets `--detail`.
- The third pass is a gate: it checks classification coverage, object visibility and that every
  atom's `at` falls inside a shot window.

`--detail 1|2|3` (default **3**):

| Level | What it supplies |
|---|---|
| 1 | Essentials only — the nouns the VO names, plus the one location they require. Minimum viable, fails the location-variety gate on any film over ~20 s. |
| 2 | Inventory + hand props — every location's ≥6 items and the props characters actually hold. Passes object coverage; still thin on walls, floor and human trace. |
| 3 | Full atom pass — all eight questions answered for every shot. Default and required for delivery. |

## Worked example: "postmaster"

**Seed line (VO):** *"Every morning the postmaster sorted the letters, weighed the parcels, and
stamped the last of them before the counter opened."*

**Domain detection:** `postmaster`, `letters`, `parcels`, `counter`, `stamped` → `post_office`
(label "Post office"). The domain decides the essential inventory (`objects.md`); detection is a
proposal, `--domain post_office` confirms it. Detection reads noun clusters, not single words —
`counter` alone could be kitchen, bank or shop; `postmaster` + `letters` + `stamped` is decisive.

| Signals | Domain |
|---|---|
| postmaster, envelope, stamp, parcel, mailbag | `post_office` |
| seat, tray, seatbelt, cabin, attendant | `airport_cabin` |
| pot, stove, sink, knife, cutting board | `kitchen` |
| desk, chalkboard, books, satchel, teacher | `classroom` |
| workbench, vice, hammer, offcuts | `workshop` |

If detection is ambiguous, pin `--domain` from the strongest noun cluster; never accept a wrong
domain because it was the tool's first guess.

**Locations (≥3, one roughly every 9 s):**

| id | label | why | time of day |
|---|---|---|---|
| `post_office_front` | Front counter | the counter opens; customer + clerk face each other across it | day |
| `post_office_sorting` | Sorting room | the almirah and the sorting of letters | day |
| `post_office_steps` | Outside steps | the mailbag arrives / the last letter goes out | day |

**Inventory** (≥6 items per location; concrete nouns, not abstractions):

- `sorting_counter`, `pigeonhole_almirah`, `bundles_of_envelopes`, `rubber_stamp`,
  `weighing_scale`, `keyboard`, `notice_board`, `queue_rail`, `parcel_shelves`, `uniformed_clerk`,
  `customer`, `mailbag`.
- Map each to a build source: `mailbag` / `envelope` / `parcel` → `puppet:<kind>` if held, else
  `set:<id>`; the almirah, counter, rail, shelves and board → `plate:<primitive>` authored into the
  `post_office_*` scene spec; the stamp and scale are hand props where touched, set dressing where
  standing on the counter.

**Object → shot mapping and framing.** The VO timings constrain *when* each atom can appear, but
never shrink the detail: the 2.1 s of "sorted the letters" carries a close on hands at the almirah,
an insert on a bundle, a rubber-stamp ECU and a scale-pan dip — four atoms inside one word window.

| Shot | Words | Framing | Objects on screen | Detail (atoms 2/3/6/7/8) |
|---|---|---|---|---|
| s01 | "Every morning" | wide establishing | front counter, queue rail, notice board, clerk | light from the high window; a queue of letters already stacked; rail scuffed at the base |
| s02 | "the postmaster" | medium OTS past counter | postmaster, keyboard, sorting counter, rubber stamp | uniform sleeve, stamp ink pad, a half-sorted pile; stamp is picked up |
| s03 | "sorted the letters" | close on hands at almirah | almirah, envelopes, bundles, clerk's hands | pigeonholes labelled A–F, one drawer ajar, letters moving slot to slot |
| s04 | "weighed the parcels" | insert / prop ECU | weighing scale, parcel, parcel shelves | pan dips, a brass weight rolls, dust on the shelf lip |
| s05 | "stamped the last" | insert on the stamp | rubber stamp, envelope, ink pad | ink smudge on the clerk's thumb, impression appears on the flap |
| s06 | "before the counter opened" | OTS past the counter | customer, mailbag, counter, queue rail | mailbag at the feet, customer steps forward, board notice flips to OPEN |

Note the framing ladder: wide → medium → close → insert → insert → OTS. No two consecutive
framings repeat (gate 30). The location changes at s03 (cut, never a dissolve) and s06 (cut back to
the front); the sorting room never exceeds 60% of shots.

**Atom-list excerpt** (the rows behind the table above):

| atom | words | make | location | shot | at / until | source |
|---|---|---|---|---|---|---|
| mailbag | bag, mailbag | `puppet:mailbag` | `post_office_steps` | s01 | 0.0 / 2.1 | voice |
| almirah | almirah, pigeonholes | `plate:box` | `post_office_sorting` | s03 | 4.6 / 6.1 | voice |
| envelope | letters, mail | `puppet:envelope` | `post_office_sorting` | s03 | 4.6 / 6.1 | voice |
| weighing_scale | weighed, scale | `plate:cylinder` | `post_office_sorting` | s04 | 6.1 / 7.8 | voice |
| rubber_stamp | stamped | `puppet:stamp` | `post_office_sorting` | s05 | 7.8 / 9.0 | voice |
| counter | counter | `plate:box` | `post_office_front` | s01, s06 | 0.0 / 2.1, 9.0 / 11.0 | voice |

Each atom resolves to a build source, a location that owns it, a shot and a window. The `at` values
come straight from the words; `until` is the host shot's end. An atom whose `at` is outside every
shot window is the condition that forces a shot-boundary shift (see Timing contract).

**Why the timing does not shrink the detail.** Each noun's `at` is the start of the word that names
it. "letters" at 4.6 s triggers the almirah close; "parcels" triggers the scale insert. If two
objects are named inside a short window, the shotlist arithmetic splits or shifts a **shot**
boundary to give each atom a window; it never stretches, trims or re-times the voice. Detail is
adjusted by framing and by how many atoms share a shot, not by deleting inventory.

## Location rules

- A film over ~20 s has **≥3 distinct locations**, introduced at roughly one every **9 s**. A
  60 s film therefore has 4–6.
- Each location carries **≥6 inventory items** in the story bible.
- No location occupies **>60%** of the shots.
- A change of location is a **cut**. Never a dissolve, cross-fade or morph in this format — the
  reference grammar is hard cuts only.
- Reuse the scene spec when a location repeats; change lighting state rather than rebuilding
  geometry (`story.md` consistency rules).
- Every location used by a shot must have a plate (`gate.md` 35).

## Hand props vs set dressing vs plate geometry

Decide by **what the character does**, not by what the object is:

| Question | Answer → category | Build source |
|---|---|---|
| Is it picked up, held, handed over or pressed during a shot? | hand prop | `puppet:<kind>` — `<kind>` must be in `PROP_KINDS` (`puppet.py --list-props`) |
| Is it touched but never carried — sits on a surface, hangs on a wall? | set dressing | `set:<id>` authored into the plate |
| Is it part of the standing space (counter, almirah, rail, shelf, room, floor)? | plate geometry | `plate:<primitive>` — primitive must exist in that location's scene spec |

- A prop that is named in a character's hands **must** be a `puppet:` kind that exists — an
  `envelope` kind that `puppet.py --list-props` does not report is a fail, not a reason to describe
  it in the beat text.
- A plate object not present in the location's scene spec cannot be rendered as a plate; it must
  be declared `set:` or added to the spec.
- When an object appears both held and standing (a stamp on the counter, then in the hand), declare
  both an atom for the `set:` instance and one for the `puppet:` instance; do not let one silently
  stand in for the other.

## Continuity

An object's identity is stable across shots: same `id`, same colour, same wear. A letter that is
creased in s03 is the creased letter in s05. A handoff uses a **contact frame** — ownership switches
on exactly that frame, never one frame early or late (`build-contracts.md` 3.4). A prop that leaves
frame must be accounted for: it is put down, handed over, or exits with the character; it does not
evaporate between cuts.

## Timing contract

- Elaboration **never** edits `words.json`, `captions.json` or the audio. Those are the frozen clock.
- Each atom carries an `at` in seconds, taken from the word that triggers it.
- An atom's `at` must fall inside a shot window in `shotlist.json`.
- If it does not, the **shot boundary is moved by the shotlist arithmetic**, never the voice. The
  frame sum must still equal the voice duration exactly (`shotlist.py --check`).
- The bidirectional object check uses the word's `[start, end]` against on-screen shot windows with
  a ±1.0 s tolerance (`shotlist.py --check`); an object named while off screen is a fail from the
  audio side, and an object declared but never shown is the same fail from the contract side.

## How elaboration feeds downstream

| Output | Consumed by |
|---|---|
| `build/beats.tsv` (8 columns `id beat scene characters action camera framing objects`) | `shotlist.py --fill` |
| `build/objects.json` | `shotlist.py --objects`; the bidirectional word/object check |
| `build/placements.json` | the "needed spot" contract: per shot/object `slot`, `anchor`, `hand` socket, `at` and `source`; blocking and scene authoring must match it, and `elaborate.py --check` fails when a spoken object is not placed in a covering shot (±0.35 s) |
| `build/expanded_script.md` | human-readable detail script — the eight-question pass per shot |
| `build/story_bible.json` | domains, locations, inventory, cast, objects, coverage; source for all of the above |
| cast roles in `story_bible.json` | `assets/characters/characters.json` (characters.md "Roles from elaboration") |
| location inventory | `build/scenes/<location>.json` for `plate3d.py` (world.md "Dressing and prop geometry") |

`expanded_script.md` is not decoration: it is the script the gaffer and the set dresser would read.
A detail that is not in it will not be in the render.

## Exit gate for this stage

Before shotlist is built, all must hold:

- [ ] Domain detected or pinned with `--domain`; inventory complete for that domain.
- [ ] ≥3 locations for a film over ~20 s, one every ~9 s; each with ≥6 items; none >60% of shots.
- [ ] Every content word classified as an object or `abstract`; `coverage.unclassified` empty.
- [ ] Every named physical object has a resolvable build source.
- [ ] Every object has a shot and a time window; every shot answers the eight atom questions.
- [ ] `words.json` / `captions.json` / audio unmodified by this stage (compare hashes).
- [ ] `elaborate.py --check` passes.

## Failure signatures

| Signature | Cause | Fix |
|---|---|---|
| **postmaster with no post office** | Stage skipped; nouns written into beats but never turned into locations | Run elaboration; pin `--domain post_office`; add the three locations and their inventory |
| **bag named but not held** | Object declared as `set:` or omitted from the character's `props` | Make it a `puppet:<kind>` hand prop and list it on the card |
| **one location for 13 shots** | `--detail 1` or no location pass | Raise to `--detail 3`; split into ≥3 locations, cut on every change |
| **props in the contract but not in the render** | `objects.json` and `beats.tsv` disagree with `shotlist.json` | Run `shotlist.py --fill` and `--objects`, then `--check` |
| **inventory object with no build source** | Item named in prose with no `make` field | Assign `plate:` / `set:` / `puppet:` and verify the primitive/kind exists |

---

Elaboration is the bridge from words to things. If a noun in the VO has no atom in this stage, it
will have no pixels in the film.
