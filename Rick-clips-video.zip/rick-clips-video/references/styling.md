# Look — light, lens, palette, set

The numbers that decide whether a plate reads as a real, calm set or as flat CG. Distilled from
standard cinematography practice and the MIT-licensed `blender-skills` pack
(`lighting`, `camera-cinematography`, `materials`, `environment-artist`, `set-dressing`,
`stylized-style`, `realistic-style`, © arjun988). Those files are written for Blender operators we
cannot run; the values are what transfer, so they live here as numbers a spec can use.

Read at stage 4 (world) and stage 5 (palette). Not before.

## L.1 Light rig

One key, one fill, one practical. Nothing else, unless the story needs it.

| Key : fill | Reads as | Use for |
|---|---|---|
| 8 : 1 | hard, noir | threat, night exterior, single source |
| 4 : 1 | filmic | default for a shot with a person in it |
| 2 : 1 | soft, even | **soothing** — interiors, daylight, safety |

Rules:

- **One shadow direction for every object in the frame.** Two directions is the single loudest CG tell.
- **A practical motivates the highlight**, and it must be in frame or just out of it — never a glow shape with no source.
- **Cool fill, warm key.** That split (not a colour LUT) is what reads as film.
- Falloff is physical: `intensity ∝ 1/d²`. If the far wall is as bright as the near one, the scene is flat.

Colour temperature (one row per location, never mixed):

| Source | K |
|---|---|
| candle / firelight | 1800 |
| tungsten / sodium lamp | 2700–3200 |
| warm LED | 4000 |
| daylight | 5500 |
| overcast | 6500 |
| open shade / moonlight | 8000+ |

## L.2 Lens and framing

Vertical video: the sensor's long side is vertical, so `yfov = 2·atan(18 / f_mm)`.

| Lens | `yfov_deg` | Reads as |
|---|---|---|
| 24 mm | 73.7 | wide, tense, distorted edges |
| 28 mm | 64.9 | environmental |
| **35 mm** | **54.5** | **default — natural, calm** |
| 50 mm | 39.6 | portrait, compressed |
| 85 mm | 23.9 | intimate, background melts |
| 135 mm | 15.2 | surveillance, isolation |

- Camera height: **1.55–1.70 m** for a standing adult's eye; 0.9–1.2 m for a low, tense shot.
- Horizon around 45–55% of frame height unless the shot is deliberately low or high.
- Depth of field: focus on the actor's plane, soften the far field. A plate that is sharp everywhere looks like a level editor, not a camera.

## L.3 Palette

Six colours, fixed per story: 2 warm, 2 cool, 1 neutral, 1 accent (the protagonist's).

| | Soothing | Tense |
|---|---|---|
| Saturation of the world | 15–35% | 45–70% |
| Contrast (p95−p5) | 0.42–0.62 | 0.65–0.92 |
| Hue count in frame | 3–4 | 5–6 |
| Key : fill | 2:1 | 4:1 or harder |
| Haze | present, soft | thin or absent |
| Edges | rounded, worn | straight, sharp |

Character hues sit **≥30°** from the plate's dominant hue, or they disappear into it.

## L.4 Set dressing

- **Density:** one hero prop per 2–3 m² of visible floor. Under-dressed reads as a test scene; over-dressed reads as clutter.
- **Cluster, don't scatter:** props arrive in groups of three (one large, two small), plus one outlier that breaks the rhythm.
- **Every prop touches something.** Contact shadow, or it floats.
- **A human trace** — the thermos, the folded coat, the stool pulled out. It implies a person and costs nothing.
- **Wear concentrates where hands and feet go:** door edges, stair nosings, rail tops, floor in the traffic line.

## L.5 Materials

| Surface | Roughness | Metallic | Scale check |
|---|---|---|---|
| Stone / brick | 0.75–0.90 | 0.0 | block 0.2–0.5 m long |
| Timber | 0.60–0.80 | 0.0 | grain runs along the length |
| Iron / steel | 0.30–0.50 | 0.8–1.0 | bolt heads 10–20 mm |
| Brass | 0.25–0.45 | 1.0 | tarnish in the recesses |
| Fabric | 0.80–0.95 | 0.0 | weave reads at 1 m, not 10 m |
| Ground / cobble | 0.70–0.90 | 0.0 | stone 0.1–0.2 m across |

Real-world scale, always: door 2.1 m, domestic ceiling 2.4 m, industrial ceiling 3.5 m+, chair seat
0.45 m, table 0.75 m, crate 0.5–0.7 m, step riser 0.18 m. A room that is 20% off reads as a dollhouse
and no texture fixes it.

## L.6 The check, before you believe any of it

1. Squint: can you name the key direction without looking for it?
2. Thumbnail: are three depth planes readable (foreground occluder, actor's plane, far silhouette)?
3. Is every prop's shadow pointing the same way as the key?
4. Does one surface have no visible material? (a flat painted panel, a pure-colour wall)
5. Is the brightest thing in frame the source you said was lighting the scene?

If any answer is no, fix that before adding detail. Detail on a wrong light rig makes it worse.
