# Acceptance gate — 35 checks

### I. Definition of “same video” (acceptance gate)
A new video passes only if all of these are true (check by measuring, not eyeballing):

**Format & captions**
1. 1080×1920, 30fps, duration = VO duration ± 0.3s.
2. **Caption timing provenance:** `build/audio.json` records the `mode` used (srt / asr / align / estimate) and the word count it produced. `estimate` is allowed only when the user asked for estimates; then every card carries `est: true` and the report names the expected drift. Captions are never written from silence alone, and a mode that failed is named, not hidden.
3. Captions: Montserrat ExtraBold 70px, baseline y = 1376px (±8px), white fill with 11px black stroke, centred, 1–4 words, word-by-word, synced to speech, hard swap.

**The 3D world (C)**
4. Every location shows ≥3 material families with visible albedo variation, roughness break-up and wear — no flat untextured surface anywhere in frame.
5. Shadow direction is identical across all objects in a shot and matches the stated key light; a visible light source motivates the atmosphere.
6. Time-of-day colour sits in the correct C.3 row (dawn / midday / golden / overcast / moonlit / lantern) — highlights and shadows are split-toned, not globally tinted.
7. Depth reads: foreground occluder, mid-ground stage and background silhouette are separable at thumbnail size; atmospheric perspective increases with distance.

**The cast (B, B.1)**
8. Every character follows the rig (white head 0.28–0.42 of height including headwear, white eye discs with pupils, solid black limbs 2.2–2.6% of height, outline 0.9–1.1% of height, torso 0.88–0.94 head-widths wide at the shoulders, no nose/ears/chin) in **every** shot, and every character has a declared **body archetype** from the B table.
9. Consistency metrics pass on every character frame (measure with `scripts/make_sheet.py` + `consistency_check.py --sheet-dir assets/characters/`): garment ΔE ≤4, outline on ≥90% of the perimeter at 0.9–1.1% of character height, head ratio 0.28–0.42, face/torso width 0.92–1.20 (measured on the torso band, not the hem), limb 2.2–2.6%, prop IoU ≥0.80, and silhouette IoU ≥0.85 against the matching sheet pose where one exists. Results logged in `analysis/consistency.csv`.
10. Wardrobe/prop state matches the shot range in `characters.json` (no hat appearing after it was lost; the same hand holds the prop across cuts).

**Animation (D)**
11. Every action has anticipation → contact → follow-through; no pose-to-pose teleporting. Two-actor contacts resolve within **0.5px** at the contact frame and stay resolved through the hold; reach ratio ≤0.92 on both arms.
12. Auto-plant is applied every frame: planted-foot ground spread ≤0.5px, no sliding >1.5px/frame, no character floating; airborne frames are the only ones allowed to leave the line, and they carry a shadow that shrinks and softens.
13. Idle, breath and blink are present in every shot with a visible character; no actor is frozen for >2.5s.
14. Mouth shapes land within ±2 frames of the spoken word; brows key only on stressed words.
15. Secondary lag exists on hats/coats/hair/props (1–2 frames) — no rigidly attached accessories; props ride hand sockets (distance to the owning hand ≤0.5px) and change owner exactly on the hand-off contact frame.
16. Pose, screen direction, eyeline and prop hand match across every cut.

**Story & mix**
17. Shot count = duration / 2.2 (≈26–30 for 60s), mean shot 1.5–3.0s, hard cuts; one idea per shot, cause→effect within two shots, a reaction after every reveal, punchline on the final shot.
18. Mix at −14 LUFS, true peak ≤ −1 dBTP, VO clear, SFX on cuts. Generate the bed with `scripts/make_sfx.py`; `finish.py` ducks it under the VO and re-limits the mix.
19. Composite: characters sharp on a softened plate, grounded by contact shadows, caption on top, warm-highlight/cool-shadow grade, 2–3% grain, no chromatic aberration.
20. **Clean plate:** the background contains no characters, and every placed actor's scale and depth match the plate's standing space. `build/plates.json` shows a plate per location with `flat_lit` < 0.35, `contrast` 0.42–0.92, `hue_clusters` ≥ 3, a measured `feet.y`, and a sha256 that is unchanged on a second render.
21. **Staging:** the action (hands, props, contact points) sits outside the caption band y1300–1400 while the caption is on screen.
22. **Camera:** every shot declares one move (or a justified lock-off); zoom/travel is monotonic, ends exactly on its declared amount, and the actors are scaled about the feet line so no foot lifts. Background parallax **0.55×** (never above 0.6×) and foreground **1.75×** (never below 1.5×) the actor move.
23. **Foreground plane:** an RGBA layer sits in front of the actors, overlaps at least the front row's ankles, stays out of the faces (top edge y ≥ 860), and covers 8–45% of the frame. A shot without one must be a deliberate close-up or ECU.
24. **Crowd:** every figure has a different body + hat pair, per-actor idle/blink offsets differ, depth rows are scaled 0.74–1.04× and z-sorted by feet line, and the interacting pair keeps its own depth row.
25. Side-by-side with reference frames: layout, character proportions, caption treatment, motion feel, depth layering and pacing are visually indistinguishable.

**Story elaboration & objects (26–35)**
These checks measure the contracts in `elaboration.md`, `objects.md` and `build-contracts.md` §3.2c.
Checks 26–33 and 35 are run by `scripts/elaborate.py --check` and `scripts/shotlist.py --check`
against the generated contracts; check 34 reads the plate records written by `plate3d.py`.
A `PASS` in a report must name the command that produced it — a check that was not run is a
gap, never a pass.

| Check | What is measured | Command / script | PASS | Failure signature |
|---|---|---|---|---|
| **26. Story bible + location inventory** | `domain`, `locations[]` count and each `inventory[]` length in `build/story_bible.json` | `python3 scripts/elaborate.py --check build/story_bible.json --words build/words.json --shotlist build/shotlist.json`; inspect `locations` | domain set; ≥3 locations for a film over ~20 s; each location ≥6 inventory items; no location >60% of shots | "postmaster with no post office"; one bare room dressing every shot |
| **27. Word classification coverage** | `coverage.words_total / classified / unclassified`; every content word resolved to an object or `abstract` | `elaborate.py --check`; read `coverage` in `story_bible.json` | `unclassified` empty; `classified == words_total`; stopwords and `abstract` exempt | "unclassified content words" left for the renderer to guess |
| **28. Object visibility, right shot + right spot** | Each `objects[].id` appears in a shot; word `[start,end]` vs shot window ±1.0 s (`shotlist.py`); **plus** `build/placements.json` gives every object a `slot` (hand/near/mid/far), `anchor` (screen region), a `hand` socket for hand props, and an `at` inside its shot; `elaborate.py --check` tightens word-to-shot matching to ±0.35 s | `python3 scripts/shotlist.py build/captions.json --check --objects build/objects.json --words build/words.json`; `python3 scripts/elaborate.py --check build/story_bible.json --words build/words.json --shotlist build/shotlist.json` | no "declared but never appears"; no "named object is not placed in a covering shot"; no "no placement slot in frame"; no "hand prop … has no hand socket"; no "placed at … outside the shot" | "object in contract but not rendered"; "bag named but never held"; "phone present but in the wrong shot or floating in frame" |
| **29. Object build source resolvable** | Every `make` in inventory/objects resolves: `puppet:<kind>` ∈ `PROP_KINDS` (`puppet.py --list-props`) **and resolves to a 3D sprite in `assets/props/3d/`** (flat SVG only as fallback); `plate:<primitive>` ∈ box/cylinder/sphere/cone/quad/room/floor **and** present in that location's scene spec; `set:<id>` present in the spec | `python3 scripts/puppet.py --list-props`; grep `geometry` in `build/scenes/<location>.json`; `elaborate.py --check --anim build/anim.json` (hand props must be parented to a character in every shot that declares them) | all three families resolve; no prose-only object; no hand prop missing from `anim.json` | "inventory with no build source"; "props in the contract but not in the render"; "bag named but never held" |
| **30. Shot-size and action variety** | `framing` and `action` values across consecutive shots | `shotlist.py --check`; `elaborate.py --check`; inspect `expanded_script[].action` | no two identical framings in a row; ≥4 distinct actions; no three consecutive shots with the same action | insert subject crosses the caption band; ten shots of the same gesture |
| **31. Location and theme variety** | Distinct `scene`/`env` values, shot counts, and `theme.signature` (time + key/fill + dominant material + palette) | `shotlist.py --check`; `elaborate.py --check`; group shots by `scene` | ≥3 locations over ~20 s; none >60% of shots; **every used location has a distinct theme signature**; every change is a `hard_cut` | "one location for 13 shots"; three addresses that look identical |
| **32. Expanded script atom coverage** | `expanded_script[]` has one entry per shot with `detail`, `framing`, `scene`, `on_screen`; all eight atom questions answered at `--detail 3` | `elaborate.py --check`; inspect `expanded_script` in `story_bible.json` | one entry per shot; `on_screen` ⊆ declared objects; no empty `detail` | thin, location-less detail script; atoms missing from the render |
| **33. Cast and props coherent with the story** | `cast[]` roles, `props`, `location` vs `characters.json` and the shot's `characters`/`objects` | `python3 scripts/consistency_check.py analysis/frames/ --chars assets/characters/characters.json`; compare `cast` to cards | role in a sensible location; any VO-named prop in a character's hands is on that character's card; prop IoU ≥0.80 | "bag named but not held"; card lists a prop the story never uses |
| **34. Renderer / quality report present** | `build/plates.json` records `gl_renderer / gl_vendor / gpu / quality` per plate and a quality tier was chosen | `python3 scripts/plate3d.py --scene build/scenes/<loc>.json --quality <tier> --record build/plates.json`; inspect the record | each plate has the four fields filled and a `quality` tier; GPU claim matches the recorded renderer | llvmpipe recorded while `cinema` was claimed; missing quality report |
| **35. Every location used by a shot has a plate** | Set of `shotlist[].scene` vs keys of `build/plates.json` | `shotlist.py --check`; compare `scene` ids to `plates.json` keys | every shot's location has one plate entry with a measured `feet.y` and `sha256` | shot renders against a missing or guessed plate |
