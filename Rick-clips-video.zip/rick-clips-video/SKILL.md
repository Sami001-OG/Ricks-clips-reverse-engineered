---
name: rick-clips-video
description: Builds a 1080x1920 Shorts video from a voiceover by first elaborating the script into an atom-level production plan (locations, props, set dressing, shot sizes), then combining 2D outlined cutouts with 3D plates, rigged motion and word-timed captions. Use when the user supplies a voiceover or transcript.
---

# Rick Clips Video

Builds a finished **1080×1920 / 30 fps / ~60 s** video from **a voiceover alone**. Two visual languages lock together:

- **Actors** are flat 2D vector cutouts — solid identity colour, one heavy black outline, white disc eyes on a pure-white face, no shading, no nose.
- **The world** is semi-realistic 3D — textured surfaces, directional light, depth haze, grain. The contrast between the two is the whole look. A cartoon background or a shaded character breaks it.

The cast is invented per story. What is fixed: the 3D world grammar, the rig, the timing tables, and the caption system.

## When to use

Use when the user supplies **only** audio or a transcript and wants a finished vertical video: "here's my voiceover, make the video", "turn this into a short".

Do **not** use for: live-action, talking-head, screen recordings, 16:9 landscape, or a request to analyse an existing video without producing a new one.

## Inputs

| Input | Required | What to do with it |
|---|---|---|
| Voiceover (mp3/wav/m4a) | yes | The master clock. Nothing else sets timing. |
| Transcript (txt/srt) | no | Use it if present; otherwise transcribe or have the user paste it. |
| Reference clips | no | Style is already embedded in `references/`. Do not ask for footage. |

If the user has no transcript and no ASR is available, ask for **either** a transcript **or** permission to place captions on estimated word boundaries — never ship a caption track you invented silently.

## Environment

The skill needs a code-execution sandbox with bash and Python 3.8+; `ffmpeg`; and one of `cairosvg`/`resvg`/a browser for rasterising SVG. Run the probe before anything else — it reports which render tier is available and never guesses:

```bash
bash scripts/bootstrap.sh          # installs what is missing, safe to re-run
python3 scripts/probe.py           # prints capabilities + the tier to use
```

- **Tier 1** — Remotion (Node + Chromium). **Tier 2** — HTML/CSS in headless Chromium. **Tier 3** — SVG → cairosvg → PIL → ffmpeg, no browser.
- Tier 3 is a complete path, not a fallback stub. No GPU is required anywhere.
- The probe also reports `voice.mode`: `asr` if a local recognition model imports, otherwise `align` — which still yields word-synced captions from the transcript (`references/voice.md`).
- If there is no shell at all: say so, and hand the user the scripts plus a one-command run line. Do not pretend to render.

## Hard rules

These seventeen are what make the output recognisable. They are not style preferences; each one has a failure signature in `references/failures.md`.

1. **Two languages, never blended.** Flat outlined actor, photographic 3D world **and 3D hand props**. Props are rendered as lit 3D objects (`scripts/prop3d.py`) and composited at the hand socket; never let an image model re-render a character head; never let a plate drift toward flat illustration.
2. **Proportions never change:** head **0.33**, body **0.38**, legs **0.29** of character height; body width **0.92 × head width**; head **1.02× wider than tall**, no neck.
3. **Outline is screen-space:** **0.95% of character height**, minimum 2 px, drawn **per part** so it survives rotation. Limbs are solid black strokes **2.2–2.6%** of height.
4. **Plant the feet every frame** (`root.y += ground_y − lowest_foot.y`) and do it **before** any contact solve. Unplanted rigs float 6–16 px on every walk.
5. **Contacts are solved by IK, never by sliding the actor.** Both actors aim at one shared grip point; keep the reach ratio **≤ 0.92** — move the pair closer instead of lengthening the arm.
6. **Scale actors about the feet line**, never the frame centre, or the feet lift and the shadow detaches.
7. **Parallax is layered:** plate **0.55×** of the camera move, actors **1.00×**, foreground plane **1.75×**. Equal movement reads as a zoom lens, not a dolly.
8. **The foreground plane sits between the actors and the lens** — coverage **8–45%**, top edge **y ≥ 860**, blurred 3–6 px, darkened. It must overlap the ankles.
9. **Layer order is fixed:** plate → contact shadow → actor → foreground → caption.
10. **Captions never move and never overlap acting:** Montserrat ExtraBold **70 px**, black stroke **11 px**, baseline **y = 1376**, centre **x = 540**, 1–4 words, hard swap, no animation. Keep action above **y 1250**.
11. **One camera move per shot, hard cuts only.** 1.5–3.0 s shots, ~26–30 shots for 60 s (`scripts/shotlist.py` enforces the frame arithmetic).
12. **Measured or it didn't happen.** Every check in the gate runs on the **encoded video**, not on a preview.
13. **Captions are timed from the audio, never from the script's shape.** `scripts/vo_timing.py` always produces a track — SRT → ASR → forced alignment — and records the mode it used. No ASR model is **not** a blocker: a transcript plus the audio's own pauses is enough for word-accurate captions (`references/voice.md`).
14. **The voiceover is a seed, not a script.** Before anything is drawn, expand it into an atom-level production plan: location, inventory, hand props, surfaces, walls, floor, light, human trace, change (`scripts/elaborate.py`). Detail density is 3 by default; never ship the draft.
15. **What the script names must be on screen when it is named.** `objects.json` declares every physical thing the VO mentions and the shots that show it. `shotlist.py --check` verifies both directions: a declared object in no shot, or a word spoken while its object is off screen, is a failure.
16. **Multiple places, multiple sizes.** A film over ~20 s uses ≥3 locations (roughly one every 9 s) and ≥4 shot sizes with at least one insert; no location holds >60 % of shots, and no three consecutive shots share a place *and* a size. This is checked, not advised.
17. **The renderer reports what it actually used.** Every plate record carries `quality`, `gl_renderer`, `gl_vendor` and a `gpu` flag. On a GPU machine use `high`/`cinema`; `standard` is the validated CPU fallback. Never claim GPU-rendered plates without the record.

## Workflow

Nine stages. Each writes **one artifact**, has **one measurable exit**, and may ask **one question**. Do not start a stage before the previous exit passes.

```
Progress:
- [ ] 0  Preflight      probe + rig verify
- [ ] 1  Script         script.txt
- [ ] 2  Voice timing   captions.json + audio.json
- [ ] 2b Elaborate      story_bible.json, expanded_script.md, objects.json, beats.tsv
- [ ] 3  Shotlist       shotlist.json, frame-exact, objects contracted
- [ ] 4  World          one plate per location
- [ ] 5  Cast           characters.json + cards + generated sheets
- [ ] 6  Blocking       anim.json, placed and planted
- [ ] 7  Still check    one frame per shot, looked at
- [ ] 8  Render, burn, gate, deliver
```

### Read on demand, never ahead

Opening files you have not reached is the largest cost in a first run. Load one reference at the stage that needs it, and only when that stage asks:

| Stage | Read here | Not yet |
|---|---|---|
| 0–1 | `scripts/selftest.py` if you want to prove the gates before a real run | everything |
| 2 | `references/voice.md` if the mode is `align`, `estimate` or `segments` | gate, cast, world |
| 2b | `references/elaboration.md`, `references/objects.md`, `references/library/domains.json` | gate, motion |
| 3 | `references/format.md`, `build-contracts.md` §3.1/§3.2c; `story.md` only if the transcript has no legible beats | characters, motion |
| 4 | `references/world.md` (incl. C.6b dressing/prop geometry), then `references/styling.md` (L.1–L.5) | characters |
| 5 | `references/characters.md`; `styling.md` L.3 for the palette | motion |
| 6 | `references/build-contracts.md` §3.4 for the anim schema; `motion.md` only for actions outside the 14 in `puppet.py` | gate |
| 7 | — | gate |
| 8 | `references/render.md`, then `references/gate.md` (35 checks); `text-and-audio.md` only if a caption check fails | — |

`scripts/*` are run, not read — except `puppet.py`, when you must change the rig.

### Draft first

Every stage produces *a* version, then the exit check names what to fix. Rework the failing stage; never restart the pipeline. Defaults are already the answer: never ask for style, tier, cast size, caption size or shot length — they are fixed here.

Ask at most **one** question per stage, and only when no default can be chosen. The legitimate early one is the transcript.

### Step 0 — Preflight

```bash
set -euo pipefail
bash scripts/bootstrap.sh
python3 scripts/probe.py           # record the tier, GL renderer and recommended plate quality; never assume
python3 scripts/puppet.py --verify # rig numerics: PASS with 0 failing
```

If `--verify` fails, stop and fix the rig before rendering a frame. It asserts walk stride (15–70 px), ground spread after plant (≤0.5 px), joint limits, grip residual (≤0.5 px), reach ratios (≤0.92), prop ownership, camera monotonicity and range, foreground coverage, crowd depth and stagger, and all 14 actions.

### Step 1 — Script

This file is the transcript `vo_timing.py` aligns — what the voice says, not narration you invent.

- one sentence per line; no scene headings, no stage directions
- numbers and abbreviations written the way they are spoken
- keep the user's wording

Exit: `wc -w script.txt` ÷ audio seconds lands in **2.0–3.6 words/second**. Outside that, the transcript and the audio are different takes — ask which one is right, once. If the user gave no transcript, write nothing here; stage 2 asks.

### Step 2 — Voice timing

```bash
ffprobe -v error -show_entries format=duration -of csv=p=0 voice.mp3

# best -> worst input, all handled by one tool
python3 scripts/vo_timing.py voice.mp3 --srt voice.srt                 # real cue times
python3 scripts/vo_timing.py voice.mp3 --transcript script.txt         # forced alignment
python3 scripts/vo_timing.py voice.mp3                                 # asks for the transcript
```

`vo_timing.py` writes `build/words.json`, `build/captions.json`, `build/segments.json` and the run record `build/audio.json`. It picks its mode in this order and **never guesses silently**:

| Mode | Needs | Timing source |
|---|---|---|
| `srt` | SRT/VTT | exact cue times; words spread inside each cue |
| `asr` | a local Whisper/Vosk model | model word timestamps |
| `align` | transcript + audio | energy-segmented speech, syllable distribution, boundaries snapped to measured pauses |
| `estimate` | transcript + audio | even spread — **only with permission**, every card flagged `est` |
| `segments` | audio only | none: it writes **no captions** and exits 2 |

Rules:

- **No ASR model is not a blocker.** `align` needs only the transcript and the audio (21 ms mean boundary error measured on ground truth). Do not stop and report "no word timings" before running it.
- **No transcript and no model** → run the bare command, which returns the segment table and exits 2. Then ask **one** question: *"Paste the words you said, or an SRT from your recorder."* Do not present a menu of guesses.
- VO is the master clock. Cut, do not stretch: if a beat is long, add a shot; never speed up the voice.
- Caption groups are **1–4 words**, broken on meaning and on pauses >0.25 s, never on a fixed timer.
- Keep **0.3–0.5 s** of tail after the last word; nothing is added after it.

Exit: `build/audio.json` reports a `mode`, a `duration`, `words`, and `longest_word_s ≤ 1.0`; `build/captions.json` is non-empty. In `segments` mode the exit is the question — stop and wait.

### Step 2b — Elaborate (mandatory)

A voiceover sentence is a seed, not a story. Elaborate it into an atom-level plan **before**
deciding what to draw; this is the stage that turns "postmaster" into a post office with a
counter, a pigeonhole almirah, sorted envelopes, a weighing scale, a clerk and a customer.

```bash
python3 scripts/elaborate.py --voice script.txt \
        --words build/words.json --captions build/captions.json \
        --audio build/audio.json --detail 3
# review build/expanded_script.md — one block per shot, eight atom questions each
# review build/story_bible.json — locations, inventory, cast, objects, framing
python3 scripts/elaborate.py --check build/story_bible.json \
        --words build/words.json --shotlist build/shotlist.json   # after stage 3
```

It detects the domain from the VO (`--domain` overrides), picks three locations with a full
inventory (≥6 items each), assigns every physical noun to a shot at the word time it is
spoken, and chooses a shot-size ladder with inserts. It writes four downstream contracts:
`build/objects.json`, `build/placements.json` (per-shot slot / screen anchor / hand socket /
arrival time — the "needed spot" contract), `build/beats.tsv` (8 columns),
`build/scene_manifest.json` and the human readable `build/expanded_script.md`. **The voice,
`words.json` and `captions.json` are never edited** — every added atom is bound to an existing
word time and a shot window.

If the tool's domain guess is wrong, fix `--domain` and re-run; do not hand-author a thin
bible. Resolve every unclassified word into `objects[]` (physical) or `abstract` (not physical)
— see `references/elaboration.md`. If there is no existing shotlist yet, the tool derives
provisional windows with the same `shotlist.build()` arithmetic; after stage 3 re-run with the
real `shotlist.json` so the atom bindings are exact.

Exit: `elaborate.py --check` prints **PASS** — ≥3 locations with full inventories, zero
unclassified content words, every object in a shot, every spoken object on screen at its word
time, four or more framings, inserts present, and all eight atoms answered for every shot.

### Step 3 — Shotlist

Arithmetic first, story second.

```bash
python3 scripts/shotlist.py build/captions.json --audio build/audio.json

# build/beats.tsv comes from stage 2b — eight tab-separated columns:
#   id   beat   scene   characters   action   camera   framing   objects
python3 scripts/shotlist.py build/captions.json --fill build/beats.tsv
python3 scripts/shotlist.py build/captions.json --check \
        --objects build/objects.json --words build/words.json
python3 scripts/elaborate.py --check build/story_bible.json \
        --words build/words.json --shotlist build/shotlist.json
```

The story table is drafted by stage 2b; edit `story_bible.json` and re-run `elaborate.py` to change it — not thirty JSON edits. It groups caption cards into 1.5–3.0 s shots (target 2.2 s), splits each silent gap down the middle, and makes the frames sum exactly to the voice duration — the arithmetic that otherwise lands 8 frames long. A long trailing silence becomes end-card shots, never one 7 s hold.

Then write `build/plan.md` (one screen): duration, frame count, shot count, mean shot length, the beat under each shot.

Exit: `--check` prints **PASS**. It refuses on frames that do not sum to the voice, non-contiguous frames, a shot over 3.1 s, a missing beat/scene/characters/action/camera, or caption words that disagree with `captions.json`.

### Step 4 — World

One plate per location and lighting state: 1080×1920, no characters, no captions. **It is a rendered 3D scene** — geometry, PBR surfaces, one motivated light rig — not a drawn background.

```bash
python3 scripts/fetch_textures.py            # once: CC0 surface scans, cached; offline still works
python3 scripts/plate3d.py --demo            # proves the engine before you author anything
python3 scripts/plate3d.py --scene build/scenes/<location>.json
```

`--demo` writes `build/scenes/demo.json`; copy it and change the set. Two fully dressed example specs ship in `assets/scenes/` — `post_office_front.json` (169 geometry items: counter, pigeonhole almirah, stacked envelopes, balance scale, stamp, rails, trace coat) and `cabin_aisle_detail.json` (seat rows, tray tables, overhead bins, floor strips, bags). Copy one and change the set. Spec: camera, rooms/boxes/quads/cylinders/spheres/cones, material ids, lights, post. On a GPU machine pass
`--quality high` or `--quality cinema` (supersampling, larger shadow maps, denser SSAO, higher
texture resolution); `standard` is the validated CPU fallback and `low` is for quick drafts.
The plate record stores the quality tier and the actual GL renderer, so a GPU claim is checkable.
Rules that keep a plate from reading as CG:

- **1 unit = 1 metre.** Never scale a room to taste; doorways are 2.1 m, ceilings 2.4–4.4 m.
- **Texture tile 0.5–1.6 m per repeat.** Larger reads as wallpaper, smaller as noise.
- **One key direction for every shadow**, cool fill, warm key, haze colour from the same palette row. Two shadow directions is the tell that kills it.
- **Match the material to the maker.** Factory surfaces (panels, seats, carpet, paint) use `{"solid": true, "color": [...]}` — a rock scan on a cabin wall is the fastest way to look wrong. Photo scans are for stone, timber, rust. `"sky": true` gives an exterior a gradient horizon.
- **≥3 material families in frame**, and every prop touches something — a floating crate is a bug, not art.
- **A human trace:** the thing someone put down (thermos on the rail, coat over the beam). Cheapest realism in the shot.
- **Light and lens come from `references/styling.md` L.1–L.2** — key:fill ratio, colour temperature, lens → `yfov_deg`. Pick the row; never re-derive from taste.
- Frame the set for the actor's standing space; the plate's job is depth behind a person, not a beauty shot.

Exit, recorded per plate in `build/plates.json`:

- 1080×1920, one location, born clean
- `flat_lit` < 0.35 (the lit area is not one wash) · `contrast` 0.42–0.92 · `hue_clusters` ≥ 3 — printed and stored by the tool. `flat_coverage` is also recorded; a night interior is legitimately half black, so it is not the gate.
- `feet.y` in px — the y where actors stand; blocking reads this number, never taste
- engine, GL renderer/vendor + `gpu` flag, quality tier, per-material source (`photo:` / `procedural` / `solid` / `sky`), seed, sha256, render seconds
- two runs are **byte-identical** (same sha256)

**If there is no 3D engine** (`probe.py` reports `world.plate: vector`), build the plate from `references/world.md` C.0 and hold it to the same measurable exit. `plate3d.py` exits 3 rather than drawing a blank.

Do not run `world_check.py` on a bare plate: its depth measure needs the foreground plane, so it belongs to stage 7.

### Step 5 — Cast

Cards are vector and cheap; this stage should take minutes, not tokens.

- Design **3–6 characters** the story needs; no one-off extras.
- One **distinct body archetype** each (`capsule`, `dress`, `coat`, `armour`, `child`, `elder`); no two characters share a body+hat pair.
- 6-colour story palette: 2 warm, 2 cool, 1 neutral, 1 accent; the protagonist gets the accent. Character hues ≥30° from the plate's dominant hue.
- One card per character: role, silhouette cue, headwear, garment, identity hex, prop, expressions.
- One 4096×2048 sheet per character — 4 views, the 3–5 expressions it uses, limb parts flat with pivot dots. The sheet is the only source of truth.
- Write `assets/characters/characters.json` **now**, not later: the rig, the gate and the prompts read it, never a text description.

Exit: `characters.json` parses with 3–6 entries, every body+hat pair is unique, and the pair list is written into `plan.md` so a reader can check it without rendering.

### Step 6 — Blocking

Place, then author motion. Schema: `references/build-contracts.md` §3.4. Read `references/motion.md` only for actions outside the 14 in `puppet.py`.

- `x`, `y`, `scale` per actor per shot; `y` comes from the plate's feet line, not from taste.
- Scale about the feet, never the frame centre.
- Every contact names a frame and a tolerance; a prop handoff uses the same frame as its `parent_switch_at`.
- One camera move per shot, hard cuts.
- Foreground plane: derive it with `puppet.py --fg` or supply a cut-out PNG; 8–45% coverage, top edge y ≥ 860, overlapping the ankles. Props: one **3D sprite** each (`assets/props/3d/<kind>.png`, built with `prop3d.py`), parented to a hand socket; flat SVG is only a fallback (`--no-prop3d`).

Exit: `anim.json` parses; every actor's foot line equals its plate's `feet_y` ±2 px; every contact frame falls inside its shot; `python3 scripts/anim_check.py build/anim.json` reports **0 fail** (it checks the contract before any frame exists); `puppet.py --verify` still PASS.

### Step 7 — Still check

One frame per shot, before the full render. This is the cheapest check in the pipeline and the one that catches a bad plate, a missing foreground, or a caption over the hands.

```bash
python3 scripts/puppet.py --demo out/stills/s07.mp4 --frames 2 \
        --bg plates/<scene>.png --height-px 700 --feet-y <plate feet_y> \
        --action <action> --cards build/cards/card_0007.png
ffmpeg -v error -y -i out/stills/s07.mp4 -frames:v 1 analysis/stills/s07/00001.png
python3 scripts/world_check.py analysis/stills --all
```

Exit: one still per shot exists, `world_check.py --all` reports depth separation and no flat-region failure, and you can describe each shot in one line — what is in frame, where the feet land, whether the caption is legible. A still you skipped is a shot you have not seen.

### Step 8 — Render, burn, gate, deliver

Render each shot for exactly the frames in `shotlist.json`, then encode the master. Full commands per tier: `references/render.md`. **Default: one pass with `scripts/finish.py`** (concat + grade + grain + captions + mix in a single encode):

```bash
python3 scripts/finish.py --concat build/concat.txt --voice voice.mp3 \
        --captions build/captions.json --out out/final.mp4
```

The legacy three-pass recipe below is the debug fallback when you need to inspect an intermediate grade or a single shot:

1. **Concat + grain.** Join the shot renders with one re-encode and `noise=alls=5:allf=t+u` over the whole film. One grain field makes a flat puppet sit inside a detailed plate; per-shot grain resets at every cut.
2. **Mux the voice** at −14 LUFS / ≤ −1 dBTP (AAC 192k, 48 kHz). Gain first, then a limiter: a plain `loudnorm` pass settles ~1 LU low on speech because it hits the true-peak ceiling — measured chain and verification in `references/render.md`.
3. **Burn captions** last, so text stays clean above the grain:

```bash
python3 scripts/caption_cards.py build/captions.json \
        --base build/base.mp4 --out out/final.mp4 --run   # burn captions, mux audio
```

   **Default to the fast path.** `caption_cards.py` probes for a working hardware
   encoder and falls back to `libx264 -preset veryfast` at the same CRF 19 — measured
   3–4× faster than `-preset slow` with no change to the quality target. It overlays
   one band-sized caption stream instead of 26 full-frame chains, and `-c:a copy`
   avoids a second AAC generation. If no ffmpeg exists at all, it stops with one clear
   message. `--profile safe` restores the slow path; `fastencode.py --check` reports
   the chosen profile. Once the shot clips, voice and captions are final,
   `scripts/finish.py` folds grade + grain + captions + mix into **one** encode and
   bounds it with `-frames:v` so the last frame cannot be lost. See `references/render.md`.

- Encode master: H.264 High, yuv420p, CRF 18–20, AAC 128–192k, `+faststart`.
- Determinism is a requirement: rendering frames 0 and 60 twice must produce byte-identical PNGs.
- Identical composited states inside a shot reuse the previous encoded PNG (blink and caption swaps are part of the key); a separate process still re-renders that shot. Keep the shot manifests stable.

Run these on the encoded video (or extracted frames of it), then walk the 35 checks in `references/gate.md`:

```bash
python3 scripts/measure_captions.py out/final.mp4
python3 scripts/make_sheet.py                         # reference silhouettes (once)
python3 scripts/consistency_check.py analysis/frames/ --chars assets/characters/characters.json \
        --sheet-dir assets/characters/
python3 scripts/anim_check.py build/anim.json --frames analysis/frames/
python3 scripts/world_check.py analysis/frames/ --all
python3 scripts/elaborate.py --check build/story_bible.json \
        --words build/words.json --shotlist build/shotlist.json \
        --anim build/anim.json                                     # checks 26-33
cat build/audio.json        # caption timing mode + counts (gate check 2)
```

**Do not ship while any check fails.** If a check cannot be measured, say which one and why — a silent pass is worse than a named gap.

Deliver the video plus the contracts and the QA output. Report measured numbers, not adjectives, and list anything still unmeasured.

## Reference index

One level deep. Load each at the stage that needs it (see **Read on demand** above) — not at the start.

| File | Section | Contents |
|---|---|---|
| `references/format.md` | refs + A | Locked references, canvas/codec/rhythm, narrative grammar |
| `references/elaboration.md` | — | **VO → atom-level script**: domain, locations, inventory, framing, eight atom questions, timing contract |
| `references/objects.md` | — | **Object contract**: objects.json / story_bible schema, bidirectional check, build sources, domain inventory table |
| `references/voice.md` | — | **Voice → word timings → captions**: the five modes, forced alignment, refusal rules, sanity numbers |
| `references/characters.md` | B | Rig proportions, face metrics, 6 body archetypes, casting, consistency system |
| `references/world.md` | C | Materials, weather, light, depth, grade, environments, world QA |
| `references/motion.md` | D.1–D.6 | Camera, rig, IK, timing, locomotion, action library, face/idle |
| `references/failures.md` | D.7–D.13 | Continuity, implementation, storytelling, 30-row failure table, determinism, crowds |
| `references/text-and-audio.md` | E–F | Caption metrics and font, audio treatment |
| `references/story.md` | G–H | Story patterns, shot maps, replication kit, layer stack |
| `references/gate.md` | I | The 25 acceptance checks, grouped by what they protect |
| `references/tooling.md` | — | What to install, render tiers, sandbox constraints |
| `references/build-contracts.md` | — | JSON schemas for shotlist, captions, anim, scenes/plates + plan template |
| `references/styling.md` | L | Light ratios, colour temperature, lens → yfov, palette, set density, material ranges, scale table |
| `references/render.md` | — | Tier 1/2/3 render commands, encode line, stage 6–8 detail |

## Scripts

Run these; do not read them into context (except `puppet.py`, which is worth reading if you need to change the rig).

| Script | Purpose | Invocation |
|---|---|---|
| `scripts/probe.py` | Detect capabilities, render tier and the available voice mode | `python3 scripts/probe.py` |
| `scripts/bootstrap.sh` | Install missing dependencies (`WITH_ASR=1` also tries an ASR lib) | `bash scripts/bootstrap.sh` |
| `scripts/vo_timing.py` | Voiceover → word timings → `captions.json` (srt/asr/align/estimate, never guesses) | `python3 scripts/vo_timing.py voice.mp3 --transcript script.txt` |
| `scripts/elaborate.py` | VO → atom-level story bible: domain detection, 3 location inventories, cast, object contract, expanded script, 8-column beat table; `--check` validates it | `python3 scripts/elaborate.py --voice script.txt --words build/words.json --captions build/captions.json` |
| `scripts/shotlist.py` | Captions → frame-exact shot skeleton; `--fill` takes the 8-column beat table, `--check` validates sums, gaps, framing variety, locations and the object contract | `python3 scripts/shotlist.py build/captions.json --audio build/audio.json --check --objects build/objects.json --words build/words.json` |
| `scripts/plate3d.py` | Scene spec → 1080×1920 3D plate (box/quad/room/floor + cylinder/sphere/cone), PBR with roughness/normal break-up, shadows, SSAO, film post; `--quality low|standard|high|cinema`; records feet line, GL renderer, GPU flag and quality numbers | `python3 scripts/plate3d.py --scene build/scenes/mine.json --quality high` |
| `scripts/prop3d.py` | Builds lit 3D hand-prop sprites (22 canonical props / 40 aliases) with alpha; `--build`, `--kind`, `--list`, `--probe` | `python3 scripts/prop3d.py --build` |
| `scripts/selftest.py` | Runs a synthetic postmaster VO through elaborate → shotlist → both `--check` gates, then corrupts the plan to prove the location/size gate **fails**; no rendering | `python3 scripts/selftest.py` |
| `scripts/fetch_textures.py` | Caches 4 CC0 surface sets; the skill ships 512 px copies, this upgrades to 1K | `python3 scripts/fetch_textures.py` |
| `scripts/puppet.py` | Rig: build, solve, plant, IK, 14 actions, 6 archetypes, camera, foreground, crowd, 40 prop kinds; `--list-props`, `--verify` | `python3 scripts/puppet.py --list-props` |
| `scripts/caption_cards.py` | Exact-metric caption PNGs + `overlay.sh`; one band-sized overlay, adaptive encoder probe, burns with `--run` | `python3 scripts/caption_cards.py build/captions.json --base out/base.mp4 --out out/final.mp4 --run` |
| `scripts/fastencode.py` | Prove and pick the fastest working H.264 encoder (NVENC/QSV/AMF/VideoToolbox → libx264 veryfast) | `python3 scripts/fastencode.py --check` |
| `scripts/finish.py` | One-pass concat + grade + grain + captions + audio mix + ducked SFX, with a legacy fallback | `python3 scripts/finish.py --concat build/concat.txt --voice voice.mp3 --captions build/captions.json --out out/final.mp4` |
| `scripts/make_sheet.py` | Generate per-pose alpha silhouettes + 4096×2048 sheet per character for the consistency gate | `python3 scripts/make_sheet.py` |
| `scripts/make_sfx.py` | Deterministic cut clicks, whooshes, impacts and prop pings from the contracts | `python3 scripts/make_sfx.py` |
| `scripts/measure_captions.py` | Caption bbox, baseline, centre, stroke — from video | `python3 scripts/measure_captions.py out/final.mp4` |
| `scripts/consistency_check.py` | Silhouette IoU, garment ΔE, outline coverage, head/body ratio | `--chars assets/characters/characters.json` |
| `scripts/anim_check.py` | Contact resolution, easing, idle/blink, frozen runs, pops | `--frames analysis/frames/` |
| `scripts/world_check.py` | Flat-region coverage, material variety, contrast, depth | `--palette build/plan.md` |

## Output layout

```
build/        plates.json, scenes/*.json, shotlist.json, beats.tsv, anim.json, plan.md,
              segments.json, words.json, audio.json,   <- stage 2
              captions.json  <- generated, never typed
              story_bible.json, expanded_script.md, objects.json, placements.json,
              scene_manifest.json          <- stage 2b, the story's atom-level truth
              frames/<shot>/, cards/
assets/       bg/ characters/<id>/ rigs/ props/3d/<kind>.png + manifest.json  <- 3D hand props
              fonts/ audio/ textures/
              scenes/post_office_front.json, cabin_aisle_detail.json  <- dressed 3D examples
analysis/     frames/ (for QA), stills/<shot>/, SHOTLIST.md, vo_report.json, qa.txt
out/          base.mp4, final.mp4, stills/<shot>.mp4, plates/<location>.png
```

Paths are always forward-slash. Never write `tools\…`.

## Symptom → where to look

| Symptom | Read |
|---|---|
| "I can't get word timings" / captions drifting or lagging the voice | `references/voice.md` — run `vo_timing.py`; no ASR model is not a blocker |
| Shot frames don't add up / you are doing frame arithmetic by hand | `scripts/shotlist.py` — build then `--check`; never hand-sum |
| "The story says X but the film never shows X" | `references/elaboration.md` + `objects.md` — run `elaborate.py`, then both `--check`s |
| One location for the whole film / every shot the same size | `references/elaboration.md` (location + framing rules); `elaborate.py --check` fails it |
| A named prop is missing from a character's hands | `scripts/puppet.py --list-props`; `objects.json` `make: puppet:<kind>`; `--check` checks 28–29 |
| Plates don't look photographic enough / is the GPU being used? | `references/world.md` C.6b + `plate3d.py --quality`; verify `gl_renderer`/`gpu` in `build/plates.json` |
| Character floats, sinks, slides, scissors its legs | `references/failures.md` (plant, stride, front-on swing) |
| Hands don't meet, arm looks limp, prop detaches | `references/failures.md` + `references/motion.md` (IK) |
| Looks like a sticker on the plate | `references/world.md` (depth/staging) + `references/failures.md` |
| Push-in reads as a zoom, foreground does nothing | `references/motion.md` (camera) + hard rule 8 |
| Caption sits on the hands or looks thin | `references/text-and-audio.md` |
| Crowd looks like clones | `references/characters.md` (archetypes) |
| Whole thing reads as generated, not directed | `references/story.md` + `references/gate.md` |

## Notes on "exact"

- The numbers here are measured, not chosen. Do not "round them to taste"; if you change one, re-run the gate.
- "Same style" means the same **construction**: flat vector actors, photograph-grade plates, one heavy outline, hard swaps, one move per shot. It does not mean reusing the reference cast or props.
- When two rules collide (for example a tall hat pushing head ratio to 0.41), the gate band wins over the ideal value — the band already allows headwear and flared garments.
- Anything stated as measured but not measured in your run is a claim, and it belongs in the report as a gap.
