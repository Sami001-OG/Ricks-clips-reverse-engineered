#!/usr/bin/env python3
"""
anim_check.py — validate the motion contract (build/anim.json) and, optionally,
the rendered frames, against Section D's animation rules.

Static checks (always):
  * every actor has idle + blinkAt + eased keys
  * no "slide" root motion, no linear pose snaps
  * every contact references real actors, falls inside the shot, and has a
    matching key/prop transfer on the same frame (+-tol)
  * speakers have a mouth mode
  * required fields present (rig_version, camera, parallax)

Frame checks (--frames DIR of numbered PNGs):
  * frozen shots   : consecutive frames identical for > 2.5s (75 frames)
  * pops           : single-frame difference spike > 4x the local median
  * foot slide     : (best effort) silhouette bottom-centre drift while planted

Exit code 1 on any hard failure.
"""
import argparse, glob, json, os, re, sys
import numpy as np
from PIL import Image

EASE_OK = {"linear", "easeIn", "easeOut", "easeInOut", "bezier",
           "spring", None}
POSES = {"stand", "idle", "reach", "grip", "push", "pull", "lift", "strike",
         "dig", "throw", "catch", "light_fuse", "point", "shrug", "nod", "fall",
         "hit", "row", "pour", "count", "walk", "run", "turn", "sit", "kneel",
         "release", "carry"}


def load_shots(path):
    with open(path) as f:
        d = json.load(f)
    return d if isinstance(d, list) else [d]


def check_static(shot, fps=30):
    errs, warns = [], []
    if not shot.get("rig_version"):
        warns.append("no rig_version (drift is untraceable)")
    cam = shot.get("camera") or {}
    if not cam.get("move"):
        errs.append("camera.move missing")
    if cam.get("ease") not in EASE_OK:
        errs.append(f"camera.ease {cam.get('ease')!r} invalid")
    actors = shot.get("actors") or []
    if not actors:
        errs.append("no actors")
    ids = {a.get("id") for a in actors}
    dur = shot.get("duration_frames") or shot.get("frames")
    for a in actors:
        aid = a.get("id")
        if not a.get("idle"):
            errs.append(f"{aid}: missing idle")
        if not a.get("blinkAt"):
            errs.append(f"{aid}: missing blinkAt")
        rm = (a.get("root_motion") or {}).get("type")
        if rm == "slide":
            errs.append(f"{aid}: root_motion=slide (characters never slide)")
        if rm in ("walk", "run") and not (a.get("root_motion") or {}).get("stride_px"):
            warns.append(f"{aid}: {rm} without stride_px")
        if a.get("mouth") is None:
            warns.append(f"{aid}: no mouth mode")
        for k in a.get("keys", []):
            if k.get("ease") not in EASE_OK:
                errs.append(f"{aid}: key f={k.get('f')} bad ease {k.get('ease')!r}")
            if k.get("pose") and k["pose"] not in POSES:
                warns.append(f"{aid}: pose {k['pose']!r} not in the D.5 library")
        for joint, keys in (a.get("joints") or {}).items():
            for k in keys:
                if k.get("ease") not in EASE_OK:
                    errs.append(f"{aid}.{joint}: bad ease {k.get('ease')!r}")
    for c in shot.get("contacts") or []:
        for side in ("a", "b"):
            ref = c.get(side, "")
            who = ref.split(".")[0]
            if who not in ids and who not in ("scene", "prop"):
                errs.append(f"contact f={c.get('f')}: unknown actor {who!r}")
        if c.get("f") is None:
            errs.append("contact without frame")
    return errs, warns


def frame_diff_checks(frames_dir, fps=30):
    files = sorted(glob.glob(os.path.join(frames_dir, "*.png")))
    if len(files) < 3:
        return ["fewer than 3 frames in " + frames_dir], []
    diffs = []
    prev = None
    for p in files:
        im = np.asarray(Image.open(p).convert("L").resize((270, 480)), dtype=np.float32)
        if prev is not None:
            diffs.append(float(np.abs(im - prev).mean()))
        prev = im
    diffs = np.array(diffs)
    errs, warns = [], []
    med = np.median(diffs[diffs > 0]) if (diffs > 0).any() else 0.0
    # frozen run length
    tiny = diffs < max(0.02, med * 0.02)
    run = best = 0
    for t in tiny:
        run = run + 1 if t else 0
        best = max(best, run)
    if best >= int(2.5 * fps):
        errs.append(f"frozen for {best / fps:.2f}s (>2.5s) — idle/blink missing")
    # pops
    for i, d in enumerate(diffs):
        lo = max(0, i - 5)
        local = np.median(diffs[lo:i + 3]) or med or 1e-6
        if d > 4 * local and d > 1.0:
            warns.append(f"possible pop at frame {i + 1} (diff {d:.2f} vs {local:.2f})")
    return errs, warns


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("anim", nargs="?", default="build/anim.json")
    ap.add_argument("--frames", default=None)
    ap.add_argument("--fps", type=int, default=30)
    args = ap.parse_args()

    shots = load_shots(args.anim)
    total_e = total_w = 0
    for s in shots:
        errs, warns = check_static(s, args.fps)
        tag = s.get("shot", "?")
        for e in errs:
            print(f"[{tag}] FAIL  {e}")
        for w in warns:
            print(f"[{tag}] warn  {w}")
        total_e += len(errs)
        total_w += len(warns)
        if not errs and not warns:
            print(f"[{tag}] ok")
        # optional per-shot frames
        if args.frames:
            d = os.path.join(args.frames, tag)
            if os.path.isdir(d):
                fe, fw = frame_diff_checks(d, args.fps)
                for e in fe:
                    print(f"[{tag}] FAIL  {e}")
                for w in fw:
                    print(f"[{tag}] warn  {w}")
                total_e += len(fe)
                total_w += len(fw)

    print(f"\n{len(shots)} shots · {total_e} fail · {total_w} warn")
    return 1 if total_e else 0


if __name__ == "__main__":
    sys.exit(main())
