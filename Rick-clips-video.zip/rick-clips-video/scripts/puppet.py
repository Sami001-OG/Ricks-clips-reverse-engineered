#!/usr/bin/env python3
"""
puppet.py — reference implementation of the Section D rig (v2).

A character is a skeleton of pivots, not an image. This module:

  1. solves the skeleton for a pose  -> world-space joint positions
  2. draws those joints as outlined SVG parts (black stroke per part)
  3. supports props in hand sockets and hand-off transfers
  4. supports multiple actors with depth sorting and a contact solver
  5. six body archetypes, camera moves with parallax, a derived foreground
     plane, and crowds of cast rigs with per-actor phase
  6. rasterises per frame (cairosvg) and encodes (ffmpeg) — no browser
  7. verifies itself: planted-foot drift, contact residuals, camera range,
     foreground coverage, crowd stagger

    python3 scripts/puppet.py --demo out/walk.mp4 --bg plate.png --camera push_in
    python3 scripts/puppet.py --demo out/handshake.mp4 --duo handshake --bg plate.png
    python3 scripts/puppet.py --demo out/crowd.mp4 --crowd 5 --bg plate.png
    python3 scripts/puppet.py --verify

Library:
    rig   = build_rig(card)
    pose  = walk_pose(phase, rig)            # or action_pose("push", f, rig)
    sk    = solve_skeleton(rig, pose, root=(540, 1240), scale=0.62)
    svg   = scene_svg([{"rig": rig, "pose": pose, "root": (540, 1240), "scale": 0.62}])
"""
import argparse, json, math, os, subprocess, sys, tempfile

W, H = 1080, 1920
TAU = 2 * math.pi


# ------------------------------------------------------------------ easing
def ease(t, kind="easeInOut"):
    t = max(0.0, min(1.0, t))
    if kind == "linear":
        return t
    if kind == "easeIn":
        return t * t * t
    if kind == "easeOut":
        return 1 - (1 - t) ** 3
    if kind == "easeInOut":
        return 4 * t * t * t if t < 0.5 else 1 - ((-2 * t + 2) ** 3) / 2
    return t * t * (3 - 2 * t)


def sample_keys(keys, frame):
    """Piecewise eased sampling of [{"f": int, "a": deg, "ease": str}]."""
    if not keys:
        return 0.0
    ks = sorted(keys, key=lambda k: k["f"])
    if frame <= ks[0]["f"]:
        return float(ks[0].get("a", 0))
    if frame >= ks[-1]["f"]:
        return float(ks[-1].get("a", 0))
    for a, b in zip(ks, ks[1:]):
        if a["f"] <= frame <= b["f"]:
            span = max(1, b["f"] - a["f"])
            t = ease((frame - a["f"]) / span, b.get("ease", "easeInOut"))
            return float(a.get("a", 0)) + t * (float(b.get("a", 0)) - float(a.get("a", 0)))
    return float(ks[-1].get("a", 0))


# ------------------------------------------------------------------ geometry
# Silhouette is the body, not the hat. Six archetypes cover the reference cast;
# every one keeps the same rig maths so all the animation code still applies.
BODY_SPECS = {
    #            head  torso  legs   width  hem   extras
    "capsule": {"head": 0.33, "torso": 0.38, "legs": 0.29, "w": 0.92, "hem": 1.00},
    "dress":   {"head": 0.33, "torso": 0.44, "legs": 0.23, "w": 0.90, "hem": 1.26},
    "coat":    {"head": 0.33, "torso": 0.40, "legs": 0.27, "w": 0.94, "hem": 1.14},
    "armour":  {"head": 0.33, "torso": 0.38, "legs": 0.29, "w": 0.88, "hem": 1.08,
                "pauldrons": True},
    "child":   {"head": 0.37, "torso": 0.35, "legs": 0.28, "w": 0.88, "hem": 1.02},
    "elder":   {"head": 0.34, "torso": 0.37, "legs": 0.29, "w": 0.90, "hem": 1.04,
                "hunch": 7.0},
}


def build_rig(card, height=None):
    """Reference proportions: head 36%, torso 34%, legs 30%, no neck.

    Sizes are in px at the rig's own height; the shot scale multiplies them.
    Reference characters range from ~330px (wide shot) to ~1400px (close-up),
    so every one of these numbers is proportional, never absolute.
    """
    pr = card.get("proportions") or {}
    height = float(height or card.get("height_px") or 330)
    body = card.get("body", "capsule")
    spec = BODY_SPECS.get(body, BODY_SPECS["capsule"])
    # measured off the references: head 33%, body 38%, legs 29%, no neck
    head_h = height * spec["head"]
    head_w = head_h * float(pr.get("head_w_ratio", 1.02))
    torso_h = height * spec["torso"]
    torso_w = head_w * float(pr.get("torso_w_ratio", spec["w"]))
    leg_h = height * spec["legs"]
    hexes = card.get("hex", {})
    return {
        "id": card.get("id", "char"),
        "height": height,
        "body": body,
        "hem": spec["hem"],
        "pauldrons": spec.get("pauldrons", False),
        "head_w": head_w, "head_h": head_h,
        "torso_h": torso_h, "torso_w": torso_w, "leg_h": leg_h,
        "shoulder_y": -torso_h * 0.66,
        # limbs are solid black lines in the reference — the outline IS the limb
        "limb_w": max(3.6, height * 0.024),
        "outline": max(2.0, height * 0.0095),
        "eye_r": head_w * 0.105,
        "eye_gap": head_w * 0.205,
        "brow_w": head_w * 0.175,
        "brow_h": head_w * 0.058,
        "mouth_w": head_w * 0.235,
        "upper_arm": height * 0.160,
        "fore_arm": height * 0.140,
        "thigh": leg_h * 0.52,
        "shin": leg_h * 0.48,
        "hex": {
            "garment": hexes.get("garment", "#C0202C"),
            "garment_alt": hexes.get("garment_alt", "#1A1A1A"),
            "face": hexes.get("face", "#FFFFFF"),
            "hair": hexes.get("hair", "#17130F"),
            "trim": hexes.get("trim", "#111111"),
            "accent": hexes.get("accent", "#E0B020"),
            "hat": hexes.get("hat", hexes.get("accent", "#E0B020")),
            "shoe": hexes.get("shoe", "#141414"),
        },
        "hat": (card.get("silhouette_cue") or ""),
        "hunch": float(card.get("hunch", spec.get("hunch", 0.0))),
        "beard": bool(card.get("beard", False)),
        "hat_kind": card.get("hat_kind") or _hat_kind(card.get("silhouette_cue") or ""),
        "hair_kind": card.get("hair_kind", "short"),
        "prop": card.get("prop"),
    }


def _hat_kind(cue):
    c = (cue or "").lower()
    if "top hat" in c or "stovepipe" in c:
        return "top_hat"
    if "helmet" in c or "plume" in c:
        return "helmet"
    if "campaign" in c or "slouch" in c or "cowboy" in c:
        return "campaign"
    if "bowler" in c or "derby" in c:
        return "bowler"
    if "cap" in c or "flat" in c:
        return "cap"
    if "cone" in c or "straw" in c or "rice" in c:
        return "cone"
    return "none" if not c else "cap"


def _rot(v, deg):
    """Match SVG rotate(-deg): (x, y) -> (x cos + y sin, -x sin + y cos)."""
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    return (v[0] * c + v[1] * s, -v[0] * s + v[1] * c)


def _add(p, v, scale=1.0, facing=1):
    return (p[0] + v[0] * scale * facing, p[1] + v[1] * scale)


def solve_skeleton(rig, pose, root=(540, 1240), scale=1.0, facing=1):
    """World-space joints for one pose. Everything downstream reads this."""
    # `hunch` is a body trait, not a pose: it survives every action, so an elder
    # stays hunched while walking, talking and gesturing.
    lean = pose.get("torso", 0.0) - float(rig.get("hunch", 0.0))
    head_tilt = pose.get("head", 0.0)
    tw, th, hh, hw = rig["torso_w"], rig["torso_h"], rig["head_h"], rig["head_w"]

    hip = root
    chest = _add(hip, _rot((0, -th), lean), scale, facing)
    sh_y = rig["shoulder_y"]
    shoulders = {
        "l": _add(hip, _rot((-tw * 0.46, sh_y), lean), scale, facing),
        "r": _add(hip, _rot((tw * 0.46, sh_y), lean), scale, facing),
    }
    head_c = _add(hip, _rot((0, -th - hh * 0.47), lean), scale, facing)

    joints = {"hip": hip, "chest": chest, "head": head_c, "lean": lean,
              "head_tilt": head_tilt, "scale": scale, "facing": facing}
    for side in ("l", "r"):
        a1 = pose.get(f"sh_{side}", 8.0)
        a2 = a1 + pose.get(f"el_{side}", 6.0)
        L1 = rig["upper_arm"] * scale
        L2 = rig["fore_arm"] * scale
        s = shoulders[side]
        elbow = (s[0] + math.sin(math.radians(a1)) * L1 * facing,
                 s[1] + math.cos(math.radians(a1)) * L1)
        hand = (elbow[0] + math.sin(math.radians(a2)) * L2 * facing,
                elbow[1] + math.cos(math.radians(a2)) * L2)
        joints[f"shoulder_{side}"] = s
        joints[f"elbow_{side}"] = elbow
        joints[f"hand_{side}"] = hand

        ah = pose.get(f"hip_{side}", 0.0)
        ak = ah + pose.get(f"kn_{side}", 0.0)
        L3 = rig["thigh"] * scale
        L4 = rig["shin"] * scale
        h = _add(hip, _rot((-tw * 0.21 if side == "l" else tw * 0.21, 0), lean), scale, facing)
        knee = (h[0] + math.sin(math.radians(ah)) * L3 * facing,
                h[1] + math.cos(math.radians(ah)) * L3)
        foot = (knee[0] + math.sin(math.radians(ak)) * L4 * facing,
                knee[1] + math.cos(math.radians(ak)) * L4)
        joints[f"hip_{side}_p"] = h
        joints[f"knee_{side}"] = knee
        joints[f"foot_{side}"] = foot
    return joints


# ------------------------------------------------------------------ drawing
BLACK = "#121212"


def _stroke(pts, width, colour=BLACK, extra=0.0):
    d = " ".join(f"{x:.2f},{y:.2f}" for x, y in pts)
    return (f'<polyline points="{d}" fill="none" stroke="{colour}" '
            f'stroke-width="{width + extra:.2f}" stroke-linecap="round" '
            f'stroke-linejoin="round"/>')


def _poly(pts, width, colour, outline, o):
    """A limb segment: black casing + coloured core (used for sleeves/trousers)."""
    return (_stroke(pts, width, BLACK, o * 2) if colour == BLACK
            else _stroke(pts, width, BLACK, o * 2) + _stroke(pts, width, colour))


def face_svg(rig, cx, cy, scale, expr="neutral", mouth_open=0.0, blink=False,
             facing=1):
    """Reference face: big white eye discs with pupils, thick brows, thick mouth."""
    hw = rig["head_w"] * scale
    hh = rig["head_h"] * scale
    o = rig["outline"] * max(0.75, min(scale, 1.5))
    er = rig["eye_r"] * scale
    gap = rig["eye_gap"] * scale
    bw = rig["brow_w"] * scale
    bh = rig["brow_h"] * scale
    mw = rig["mouth_w"] * scale
    eye_y = cy - hh * 0.02
    brow_y = eye_y - er * 1.65
    mouth_y = cy + hh * 0.235
    s = []

    closed = blink or expr in ("happy", "sly")
    if closed:
        for dx in (-gap, gap):
            s.append(f'<path d="M {cx + dx - er * 0.95:.2f} {eye_y:.2f} '
                     f'q {er * 0.95:.2f} {er * 0.85:.2f} {er * 1.9:.2f} 0" '
                     f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.15:.2f}" '
                     f'stroke-linecap="round"/>')
    else:
        pr = er * (0.42 if expr == "shocked" else 0.55)
        for dx in (-gap, gap):
            s.append(f'<ellipse cx="{cx + dx:.2f}" cy="{eye_y:.2f}" rx="{er:.2f}" '
                     f'ry="{er * (1.06 if expr == "shocked" else 1.0):.2f}" '
                     f'fill="#fff" stroke="{BLACK}" stroke-width="{o * 0.9:.2f}"/>')
            px = cx + dx + er * 0.12 * facing
            s.append(f'<circle cx="{px:.2f}" cy="{eye_y:.2f}" r="{pr:.2f}" fill="{BLACK}"/>')

    tilt = {"angry": 15, "worried": -13, "sly": 8, "shocked": -5}.get(expr, 0)
    for i, dx in enumerate((-gap, gap)):
        a = tilt if i == 0 else -tilt
        s.append(f'<g transform="translate({cx + dx:.2f} {brow_y:.2f}) rotate({a})">'
                 f'<rect x="{-bw / 2:.2f}" y="{-bh / 2:.2f}" width="{bw:.2f}" '
                 f'height="{bh:.2f}" rx="{bh * 0.45:.2f}" fill="{BLACK}"/></g>')

    lw = o * 1.35
    if expr == "shocked":
        s.append(f'<ellipse cx="{cx:.2f}" cy="{mouth_y:.2f}" rx="{mw * 0.30:.2f}" '
                 f'ry="{mw * 0.42:.2f}" fill="#7A1F24" stroke="{BLACK}" '
                 f'stroke-width="{o * 0.9:.2f}"/>')
    elif expr == "happy" and mouth_open < 0.05:
        s.append(f'<path d="M {cx - mw * 0.55:.2f} {mouth_y - mw * 0.05:.2f} '
                 f'q {mw * 0.55:.2f} {mw * 0.55:.2f} {mw * 1.1:.2f} 0" fill="none" '
                 f'stroke="{BLACK}" stroke-width="{lw:.2f}" stroke-linecap="round"/>')
    elif expr == "angry":
        s.append(f'<path d="M {cx - mw * 0.5:.2f} {mouth_y + mw * 0.08:.2f} '
                 f'q {mw * 0.5:.2f} {-mw * 0.28:.2f} {mw:.2f} 0" fill="none" '
                 f'stroke="{BLACK}" stroke-width="{lw:.2f}" stroke-linecap="round"/>')
    elif mouth_open > 0.08:
        ry = mw * (0.18 + 0.40 * mouth_open)
        s.append(f'<ellipse cx="{cx:.2f}" cy="{mouth_y:.2f}" rx="{mw * 0.36:.2f}" '
                 f'ry="{ry:.2f}" fill="#7A1F24" stroke="{BLACK}" '
                 f'stroke-width="{o * 0.9:.2f}"/>')
    else:
        s.append(f'<path d="M {cx - mw * 0.42:.2f} {mouth_y:.2f} '
                 f'q {mw * 0.42:.2f} {mw * 0.10:.2f} {mw * 0.84:.2f} 0" fill="none" '
                 f'stroke="{BLACK}" stroke-width="{lw:.2f}" stroke-linecap="round"/>')
    return "".join(s)


def hair_svg(rig, hw, hh, kind="short", colour="#17130F"):
    """Hair sits behind the face; only the fringe and side locks are visible."""
    s = []
    if kind in ("bob", "long"):
        drop = hh * (0.52 if kind == "bob" else 0.72)
        s.append(f'<path d="M {-hw * 0.52:.2f} {-hh * 0.08:.2f} '
                 f'Q {-hw * 0.56:.2f} {drop:.2f} {-hw * 0.30:.2f} {drop:.2f} '
                 f'L {hw * 0.30:.2f} {drop:.2f} '
                 f'Q {hw * 0.56:.2f} {drop:.2f} {hw * 0.52:.2f} {-hh * 0.08:.2f} Z" '
                 f'fill="{colour}" stroke="{BLACK}" stroke-width="{rig["outline"] * 0.8:.2f}"/>')
    if kind != "bald":
        # fringe: a flat-ish cap across the top third of the head
        s.append(f'<path d="M {-hw * 0.50:.2f} {-hh * 0.22:.2f} '
                 f'Q {-hw * 0.46:.2f} {-hh * 0.54:.2f} 0 {-hh * 0.54:.2f} '
                 f'Q {hw * 0.46:.2f} {-hh * 0.54:.2f} {hw * 0.50:.2f} {-hh * 0.22:.2f} '
                 f'Q {hw * 0.30:.2f} {-hh * 0.34:.2f} {hw * 0.12:.2f} {-hh * 0.26:.2f} '
                 f'Q {0:.2f} {-hh * 0.36:.2f} {-hw * 0.14:.2f} {-hh * 0.24:.2f} '
                 f'Q {-hw * 0.32:.2f} {-hh * 0.34:.2f} {-hw * 0.50:.2f} {-hh * 0.22:.2f} Z" '
                 f'fill="{colour}" stroke="{BLACK}" stroke-width="{rig["outline"] * 0.8:.2f}"/>')
    return "".join(s)


def hat_svg(rig, hw, hh, kind, colour, accent, o):
    """Hats are the silhouette cue, so they are drawn large and readable."""
    s = []
    if kind == "none":
        return ""
    if kind == "top_hat":
        brim_y = -hh * 0.36
        s.append(f'<ellipse cx="0" cy="{brim_y:.2f}" rx="{hw * 0.64:.2f}" '
                 f'ry="{hh * 0.055:.2f}" fill="{colour}" stroke="{BLACK}" '
                 f'stroke-width="{o:.2f}"/>')
        s.append(f'<path d="M {-hw * 0.30:.2f} {brim_y:.2f} L {-hw * 0.33:.2f} {brim_y - hh * 0.60:.2f} '
                 f'L {hw * 0.33:.2f} {brim_y - hh * 0.60:.2f} L {hw * 0.30:.2f} {brim_y:.2f} Z" '
                 f'fill="{colour}" stroke="{BLACK}" stroke-width="{o:.2f}" stroke-linejoin="round"/>')
        s.append(f'<rect x="{-hw * 0.32:.2f}" y="{brim_y - hh * 0.11:.2f}" '
                 f'width="{hw * 0.64:.2f}" height="{hh * 0.08:.2f}" fill="{accent}" '
                 f'stroke="{BLACK}" stroke-width="{o * 0.7:.2f}"/>')
    elif kind == "campaign":
        brim_y = -hh * 0.30
        s.append(f'<path d="M {-hw * 0.78:.2f} {brim_y:.2f} Q 0 {brim_y - hh * 0.08:.2f} '
                 f'{hw * 0.78:.2f} {brim_y:.2f} Q 0 {brim_y + hh * 0.10:.2f} '
                 f'{-hw * 0.78:.2f} {brim_y:.2f} Z" fill="{colour}" stroke="{BLACK}" '
                 f'stroke-width="{o:.2f}"/>')
        s.append(f'<path d="M {-hw * 0.36:.2f} {brim_y + hh * 0.01:.2f} '
                 f'Q {-hw * 0.38:.2f} {brim_y - hh * 0.26:.2f} 0 {brim_y - hh * 0.26:.2f} '
                 f'Q {hw * 0.38:.2f} {brim_y - hh * 0.26:.2f} {hw * 0.36:.2f} {brim_y + hh * 0.01:.2f} Z" '
                 f'fill="{colour}" stroke="{BLACK}" stroke-width="{o:.2f}" stroke-linejoin="round"/>')
        s.append(f'<rect x="{-hw * 0.37:.2f}" y="{brim_y - hh * 0.075:.2f}" '
                 f'width="{hw * 0.74:.2f}" height="{hh * 0.058:.2f}" fill="{accent}" '
                 f'stroke="{BLACK}" stroke-width="{o * 0.7:.2f}"/>')
    elif kind == "bowler":
        brim_y = -hh * 0.34
        s.append(f'<ellipse cx="0" cy="{brim_y:.2f}" rx="{hw * 0.60:.2f}" '
                 f'ry="{hh * 0.07:.2f}" fill="{colour}" stroke="{BLACK}" stroke-width="{o:.2f}"/>')
        s.append(f'<path d="M {-hw * 0.40:.2f} {brim_y:.2f} A {hw * 0.40:.2f} {hh * 0.30:.2f} 0 0 1 '
                 f'{hw * 0.40:.2f} {brim_y:.2f} Z" fill="{colour}" stroke="{BLACK}" '
                 f'stroke-width="{o:.2f}"/>')
        s.append(f'<rect x="{-hw * 0.40:.2f}" y="{brim_y - hh * 0.10:.2f}" '
                 f'width="{hw * 0.80:.2f}" height="{hh * 0.055:.2f}" fill="{accent}" '
                 f'stroke="{BLACK}" stroke-width="{o * 0.7:.2f}"/>')
    elif kind == "cone":
        brim_y = -hh * 0.26
        s.append(f'<path d="M {-hw * 0.74:.2f} {brim_y:.2f} Q 0 {brim_y - hh * 0.05:.2f} '
                 f'{hw * 0.74:.2f} {brim_y:.2f} Q 0 {brim_y + hh * 0.09:.2f} '
                 f'{-hw * 0.74:.2f} {brim_y:.2f} Z" fill="{colour}" stroke="{BLACK}" '
                 f'stroke-width="{o:.2f}"/>')
        s.append(f'<path d="M {-hw * 0.38:.2f} {brim_y:.2f} L 0 {brim_y - hh * 0.46:.2f} '
                 f'L {hw * 0.38:.2f} {brim_y:.2f} Z" fill="{colour}" stroke="{BLACK}" '
                 f'stroke-width="{o:.2f}" stroke-linejoin="round"/>')
    elif kind == "helmet":
        s.append(f'<path d="M {-hw * 0.52:.2f} {-hh * 0.10:.2f} '
                 f'A {hw * 0.52:.2f} {hh * 0.44:.2f} 0 0 1 {hw * 0.52:.2f} {-hh * 0.10:.2f} Z" '
                 f'fill="{accent}" stroke="{BLACK}" stroke-width="{o:.2f}"/>')
        s.append(f'<rect x="{-hw * 0.56:.2f}" y="{-hh * 0.155:.2f}" width="{hw * 1.12:.2f}" '
                 f'height="{hh * 0.075:.2f}" rx="{hh * 0.03:.2f}" fill="{colour}" '
                 f'stroke="{BLACK}" stroke-width="{o:.2f}"/>')
        s.append(f'<path d="M 0 {-hh * 0.52:.2f} q {hw * 0.16:.2f} {-hh * 0.10:.2f} '
                 f'{hw * 0.03:.2f} {-hh * 0.24:.2f}" fill="none" stroke="{accent}" '
                 f'stroke-width="{o * 2.6:.2f}" stroke-linecap="round"/>')
    else:  # cap
        brim_y = -hh * 0.30
        s.append(f'<path d="M {-hw * 0.52:.2f} {brim_y:.2f} '
                 f'A {hw * 0.52:.2f} {hh * 0.26:.2f} 0 0 1 {hw * 0.52:.2f} {brim_y:.2f} Z" '
                 f'fill="{colour}" stroke="{BLACK}" stroke-width="{o:.2f}"/>')
        s.append(f'<path d="M {-hw * 0.52:.2f} {brim_y:.2f} q {hw * 0.34:.2f} {hh * 0.11:.2f} '
                 f'{hw * 0.72:.2f} {-hh * 0.01:.2f}" fill="{colour}" stroke="{BLACK}" '
                 f'stroke-width="{o:.2f}" stroke-linejoin="round"/>')
    return "".join(s)


def beard_svg(rig, hw, hh, colour):
    """Horseshoe beard: jaw masses + chin patch + moustache.

    The mouth is deliberately left clear — a solid beard over the face kills
    lip-sync, and the reference beards are drawn around the mouth, not over it.
    """
    o = rig["outline"] * 0.75
    s = []
    for sg in (-1, 1):
        s.append(
            f'<path d="M {sg * hw * 0.46:.2f} {hh * 0.02:.2f} '
            f'Q {sg * hw * 0.48:.2f} {hh * 0.40:.2f} {sg * hw * 0.20:.2f} {hh * 0.52:.2f} '
            f'L {sg * hw * 0.10:.2f} {hh * 0.36:.2f} '
            f'Q {sg * hw * 0.32:.2f} {hh * 0.26:.2f} {sg * hw * 0.30:.2f} {hh * 0.02:.2f} Z" '
            f'fill="{colour}" stroke="{BLACK}" stroke-width="{o:.2f}" stroke-linejoin="round"/>')
    s.append(f'<ellipse cx="0" cy="{hh * 0.47:.2f}" rx="{hw * 0.19:.2f}" ry="{hh * 0.15:.2f}" '
             f'fill="{colour}" stroke="{BLACK}" stroke-width="{o:.2f}"/>')
    s.append(f'<path d="M {-hw * 0.20:.2f} {hh * 0.16:.2f} '
             f'q {hw * 0.20:.2f} {-hh * 0.05:.2f} {hw * 0.40:.2f} 0" fill="none" '
             f'stroke="{colour}" stroke-width="{hh * 0.06:.2f}" stroke-linecap="round"/>')
    return "".join(s)


def torso_svg(rig, sk, scale, facing):
    """Body silhouettes: the body, not the hat, is what makes a cast readable.

    Six archetypes share the skeleton maths; only the outline changes, so every
    pose, action and contact solve still applies to every character. Measured
    reference cast shapes: triangle skirt, long coat, armoured trapezoid,
    round elder, small child, plain capsule.
    """
    g = rig["hex"]
    o = rig["outline"] * max(0.75, min(scale, 1.5))
    tw = rig["torso_w"] * scale
    th = rig["torso_h"] * scale
    hip = sk["hip"]
    kind = rig.get("body", "capsule")
    hem = float(rig.get("hem", 1.0))
    cx, cy = hip[0], hip[1] - th * 0.5
    r = tw * 0.5
    top = -th * 0.5
    # skirts and coat tails hang past the hip and hide the top of the legs
    ext = {"dress": 0.34, "coat": 0.16}.get(kind, 0.0)
    bot = th * 0.5 + th * ext
    rb = r * (hem if kind in ("dress", "coat", "armour") else 1.0)
    rt = r
    cr = tw * (0.26 if kind == "child" else
               (0.17 if kind in ("capsule", "elder") else 0.09))
    br = tw * (0.10 if kind == "child" else (0.07 if kind != "dress" else 0.02))
    if kind in ("dress", "coat", "armour"):
        # flared silhouette: narrow at the shoulders, wide at the hem
        body = (f'<path d="M {-rb + br:.2f} {bot:.2f} Q {-rb:.2f} {bot:.2f} {-rb:.2f} {bot - br:.2f} '
                f'L {-rt:.2f} {top + cr:.2f} Q {-rt:.2f} {top:.2f} {-rt + cr:.2f} {top:.2f} '
                f'L {rt - cr:.2f} {top:.2f} Q {rt:.2f} {top:.2f} {rt:.2f} {top + cr:.2f} '
                f'L {rb:.2f} {bot - br:.2f} Q {rb:.2f} {bot:.2f} {rb - br:.2f} {bot:.2f} Z" '
                f'fill="{g["garment"]}" stroke="{BLACK}" stroke-width="{o:.2f}" '
                f'stroke-linejoin="round"/>')
    else:
        body = (f'<path d="M {-r + br:.2f} {bot:.2f} Q {-r:.2f} {bot:.2f} {-r:.2f} {bot - br:.2f} '
                f'L {-r:.2f} {top + cr:.2f} Q {-r:.2f} {top:.2f} {-r + cr:.2f} {top:.2f} '
                f'L {r - cr:.2f} {top:.2f} Q {r:.2f} {top:.2f} {r:.2f} {top + cr:.2f} '
                f'L {r:.2f} {bot - br:.2f} Q {r:.2f} {bot:.2f} {r - br:.2f} {bot:.2f} Z" '
                f'fill="{g["garment"]}" stroke="{BLACK}" stroke-width="{o:.2f}" '
                f'stroke-linejoin="round"/>')

    det = []
    sw = max(1.6, o * 0.8)
    if kind == "coat":
        # open front: two dark lapels meeting at the chest, seam to the hem
        for sgn in (-1, 1):
            det.append(
                f'<path d="M {sgn * rt * 0.26:.2f} {top + th * 0.04:.2f} '
                f'L {sgn * rt * 0.84:.2f} {top + th * 0.20:.2f} '
                f'L {sgn * rt * 0.14:.2f} {top + th * 0.50:.2f} Z" '
                f'fill="{g["garment_alt"]}" stroke="{BLACK}" stroke-width="{o * 0.55:.2f}" '
                f'stroke-linejoin="round"/>')
        det.append(f'<path d="M 0 {top + th * 0.50:.2f} L 0 {bot:.2f}" fill="none" '
                   f'stroke="{BLACK}" stroke-width="{o * 0.55:.2f}"/>')
        det.append(f'<rect x="{-rt * 0.96:.2f}" y="{th * 0.44:.2f}" width="{rt * 1.92:.2f}" '
                   f'height="{max(2.2, th * 0.055):.2f}" fill="{g["trim"]}"/>')
    elif kind == "dress":
        # V neckline, waistband, hem band — three horizontal beats sell the flare
        det.append(f'<path d="M {-rt * 0.42:.2f} {top + th * 0.05:.2f} L 0 {top + th * 0.24:.2f} '
                   f'L {rt * 0.42:.2f} {top + th * 0.05:.2f}" fill="none" stroke="{g["trim"]}" '
                   f'stroke-width="{sw:.2f}" stroke-linejoin="round"/>')
        det.append(f'<rect x="{-rt * 0.94:.2f}" y="{th * 0.40:.2f}" width="{rt * 1.88:.2f}" '
                   f'height="{max(2.2, th * 0.06):.2f}" fill="{g["trim"]}"/>')
        det.append(f'<rect x="{-rb * 0.98:.2f}" y="{bot - th * 0.09:.2f}" width="{rb * 1.96:.2f}" '
                   f'height="{max(2.0, th * 0.045):.2f}" fill="{g["trim"]}"/>')
    elif kind == "armour":
        # chest plate ridge, rivet line, and pauldrons at the shoulders
        det.append(f'<rect x="{-rt * 0.78:.2f}" y="{top + th * 0.30:.2f}" width="{rt * 1.56:.2f}" '
                   f'height="{max(2.4, th * 0.07):.2f}" rx="{th * 0.035:.2f}" '
                   f'fill="{g["garment_alt"]}" stroke="{BLACK}" stroke-width="{o * 0.55:.2f}"/>')
        for i in (-1, 0, 1):
            det.append(f'<circle cx="{i * rt * 0.46:.2f}" cy="{top + th * 0.56:.2f}" '
                       f'r="{max(1.8, th * 0.022):.2f}" fill="{g["accent"]}"/>')
        sy = rig["shoulder_y"] * scale + th * 0.5
        for sgn in (-1, 1):
            det.append(f'<circle cx="{sgn * tw * 0.40:.2f}" cy="{sy:.2f}" '
                       f'r="{tw * 0.15:.2f}" fill="{g["accent"]}" stroke="{BLACK}" '
                       f'stroke-width="{o * 0.85:.2f}"/>')
            det.append(f'<circle cx="{sgn * tw * 0.40:.2f}" cy="{sy:.2f}" '
                       f'r="{tw * 0.07:.2f}" fill="{g["garment_alt"]}"/>')
    else:
        # capsule / child / elder: collar, belt, buttons
        col_w = 0.34 if kind == "child" else 0.22
        det.append(f'<path d="M {-r * col_w:.2f} {top + th * 0.05:.2f} L 0 {top + th * 0.10:.2f} '
                   f'L {r * col_w:.2f} {top + th * 0.05:.2f}" fill="none" stroke="{g["trim"]}" '
                   f'stroke-width="{max(1.4, o * 0.6):.2f}" stroke-linejoin="round"/>')
        if kind == "elder":
            # shawl: two thick diagonal bands instead of a belt
            for sgn in (-1, 1):
                det.append(f'<path d="M {sgn * r * 0.30:.2f} {top + th * 0.10:.2f} '
                           f'L {sgn * r * 0.18:.2f} {bot - th * 0.04:.2f}" fill="none" '
                           f'stroke="{g["trim"]}" stroke-width="{max(2.0, o * 1.1):.2f}" '
                           f'stroke-linecap="round"/>')
        else:
            det.append(f'<rect x="{-r + 0.5:.2f}" y="{bot - th * 0.075:.2f}" width="{tw - 1:.2f}" '
                       f'height="{max(2.2, th * 0.05):.2f}" fill="{g["trim"]}"/>')
            det.append("".join(
                f'<circle cx="0" cy="{top + th * (0.34 + 0.17 * i):.2f}" '
                f'r="{max(1.6, o * 0.34):.2f}" fill="{g["trim"]}"/>' for i in range(2)))
    return (f'<g transform="translate({cx:.2f} {cy:.2f}) rotate({-sk["lean"]:.2f}) '
            f'scale({facing} 1)">{body}{"".join(det)}</g>')


# Every kind `prop_svg` actually draws. The gate/elaborator reads this tuple to
# decide whether a named object can be put on screen; keep it in sync below.
PROP_KINDS = tuple(sorted((
    "pan", "hammer", "pickaxe", "fuse", "letter", "note", "envelope", "mail",
    "flag", "lantern",
    "bag", "handbag", "tote", "backpack", "rucksack",
    "phone", "mobile", "smartphone",
    "tray", "plate", "cup", "mug", "coffee",
    "clipboard", "board", "parcel", "package", "box", "key",
    "book", "notebook", "stamp", "scale", "weighing_scale",
    "stamp_book", "booklet", "ticket", "bottle", "water_bottle", "umbrella",
)))


def prop_svg(kind, at, angle, scale, outline, size=1.0):
    """Props ride a hand socket: position from the hand, rotation from the arm.

    `size` is the rig-relative unit (0.20 * character height), so a hammer is
    never a giant club on a wide shot or a toy in a close-up.
    """
    x, y = at
    u = size * scale
    o = outline / max(scale, 0.25) * 0.5
    g = (f'<g transform="translate({x:.2f} {y:.2f}) rotate({-angle:.2f}) '
         f'scale(1 -1)">')
    if kind == "pan":
        return (g + f'<path d="M {-u * 0.62:.1f} {u * 0.10:.1f} '
                    f'A {u * 0.62:.1f} {u * 0.55:.1f} 0 0 0 {u * 0.62:.1f} {u * 0.10:.1f} Z" '
                    f'fill="#B08040" stroke="{BLACK}" stroke-width="{o:.1f}"/>'
                    f'<rect x="{-u * 0.74:.1f}" y="{-u * 0.02:.1f}" width="{u * 1.48:.1f}" '
                    f'height="{u * 0.18:.1f}" rx="{u * 0.09:.1f}" fill="#8A6030" '
                    f'stroke="{BLACK}" stroke-width="{o:.1f}"/></g>')
    if kind in ("hammer", "pickaxe"):
        head = (f'<rect x="{-u * 0.52:.1f}" y="{-u * 1.10:.1f}" width="{u * 1.04:.1f}" '
                f'height="{u * 0.36:.1f}" rx="{u * 0.06:.1f}" fill="#6E6E76" '
                f'stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        return (g + f'<rect x="{-u * 0.09:.1f}" y="{-u * 1.02:.1f}" width="{u * 0.18:.1f}" '
                    f'height="{u * 1.55:.1f}" rx="{u * 0.07:.1f}" fill="#A07040" '
                    f'stroke="{BLACK}" stroke-width="{o:.1f}"/>' + head + "</g>")
    if kind == "fuse":
        return (g + f'<rect x="{-u * 0.07:.1f}" y="{-u * 0.60:.1f}" width="{u * 0.14:.1f}" '
                    f'height="{u * 0.60:.1f}" rx="{u * 0.05:.1f}" fill="#C8B890" '
                    f'stroke="{BLACK}" stroke-width="{o:.1f}"/>'
                    f'<circle cx="0" cy="{-u * 0.70:.1f}" r="{u * 0.11:.1f}" '
                    f'fill="#FFC040" stroke="{BLACK}" stroke-width="{o * 0.6:.1f}"/></g>')
    if kind in ("letter", "note", "envelope", "mail"):
        seal = ""
        if kind in ("envelope", "mail"):
            # red wax seal at the fold vertex + a stamp in the top corner
            seal = (f'<circle cx="0" cy="{-u * 0.30:.1f}" r="{u * 0.10:.1f}" '
                    f'fill="#B02028" stroke="{BLACK}" stroke-width="{o * 0.6:.1f}"/>'
                    f'<rect x="{u * 0.21:.1f}" y="{-u * 0.54:.1f}" '
                    f'width="{u * 0.16:.1f}" height="{u * 0.12:.1f}" '
                    f'fill="#C04040" stroke="{BLACK}" stroke-width="{o * 0.4:.1f}"/>')
        return (g + f'<rect x="{-u * 0.42:.1f}" y="{-u * 0.58:.1f}" width="{u * 0.84:.1f}" '
                    f'height="{u * 0.58:.1f}" rx="{u * 0.04:.1f}" fill="#EFE6CE" '
                    f'stroke="{BLACK}" stroke-width="{o:.1f}"/>'
                    f'<path d="M {-u * 0.42:.1f} {-u * 0.58:.1f} L 0 {-u * 0.30:.1f} '
                    f'L {u * 0.42:.1f} {-u * 0.58:.1f}" fill="none" stroke="{BLACK}" '
                    f'stroke-width="{o * 0.7:.1f}"/>' + seal + '</g>')
    if kind == "flag":
        return (g + f'<rect x="{-u * 0.05:.1f}" y="{-u * 1.60:.1f}" width="{u * 0.10:.1f}" '
                    f'height="{u * 1.60:.1f}" rx="{u * 0.04:.1f}" fill="#5A3A22" '
                    f'stroke="{BLACK}" stroke-width="{o:.1f}"/>'
                    f'<path d="M {u * 0.05:.1f} {-u * 1.56:.1f} L {u * 1.05:.1f} {-u * 1.30:.1f} '
                    f'L {u * 0.05:.1f} {-u * 1.04:.1f} Z" fill="#E0C040" stroke="{BLACK}" '
                    f'stroke-width="{o:.1f}"/></g>')
    if kind == "lantern":
        return (g + f'<rect x="{-u * 0.26:.1f}" y="{-u * 0.62:.1f}" width="{u * 0.52:.1f}" '
                    f'height="{u * 0.66:.1f}" rx="{u * 0.10:.1f}" fill="#E8A030" '
                    f'stroke="{BLACK}" stroke-width="{o:.1f}"/>'
                    f'<path d="M {-u * 0.26:.1f} {-u * 0.62:.1f} Q 0 {-u * 0.95:.1f} '
                    f'{u * 0.26:.1f} {-u * 0.62:.1f}" fill="none" stroke="{BLACK}" '
                    f'stroke-width="{o:.7f}"/></g>')
    # --- named everyday cutout props -------------------------------------
    # Flat fills + black outlines in the same u/o language as the props above,
    # so any of these reads at hand-socket size.
    parts = []
    if kind in ("bag", "handbag", "tote"):
        parts.append(
            f'<path d="M {-u * 0.40:.1f} {-u * 0.10:.1f} '
            f'L {u * 0.40:.1f} {-u * 0.10:.1f} '
            f'L {u * 0.52:.1f} {u * 0.62:.1f} '
            f'L {-u * 0.52:.1f} {u * 0.62:.1f} Z" '
            f'fill="#7B4A2C" stroke="{BLACK}" stroke-width="{o:.1f}" '
            f'stroke-linejoin="round"/>')
        parts.append(
            f'<path d="M {-u * 0.26:.1f} {-u * 0.12:.1f} '
            f'Q {-u * 0.30:.1f} {-u * 0.60:.1f} {0:.1f} {-u * 0.60:.1f} '
            f'Q {u * 0.30:.1f} {-u * 0.60:.1f} {u * 0.26:.1f} {-u * 0.12:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.16:.1f} {-u * 0.12:.1f} '
            f'Q {-u * 0.18:.1f} {-u * 0.46:.1f} {0:.1f} {-u * 0.46:.1f} '
            f'Q {u * 0.18:.1f} {-u * 0.46:.1f} {u * 0.16:.1f} {-u * 0.12:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.7:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.40:.1f} {-u * 0.10:.1f} '
            f'L {u * 0.40:.1f} {-u * 0.10:.1f} '
            f'L {u * 0.44:.1f} {u * 0.18:.1f} '
            f'Q {0:.1f} {u * 0.30:.1f} {-u * 0.44:.1f} {u * 0.18:.1f} Z" '
            f'fill="#9C6640" stroke="{BLACK}" stroke-width="{o * 0.7:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.07:.1f}" y="{u * 0.18:.1f}" '
            f'width="{u * 0.14:.1f}" height="{u * 0.12:.1f}" rx="{u * 0.02:.1f}" '
            f'fill="#E0B020" stroke="{BLACK}" stroke-width="{o * 0.6:.1f}"/>')
    if kind in ("backpack", "rucksack"):
        parts.append(
            f'<path d="M {-u * 0.30:.1f} {-u * 0.26:.1f} '
            f'Q {-u * 0.34:.1f} {-u * 0.64:.1f} {-u * 0.10:.1f} {-u * 0.58:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.2:.1f}"/>')
        parts.append(
            f'<path d="M {u * 0.30:.1f} {-u * 0.26:.1f} '
            f'Q {u * 0.34:.1f} {-u * 0.64:.1f} {u * 0.10:.1f} {-u * 0.58:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.2:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.46:.1f}" y="{-u * 0.30:.1f}" '
            f'width="{u * 0.92:.1f}" height="{u * 0.84:.1f}" rx="{u * 0.20:.1f}" '
            f'fill="#3A5A78" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.28:.1f}" y="{u * 0.14:.1f}" '
            f'width="{u * 0.56:.1f}" height="{u * 0.28:.1f}" rx="{u * 0.07:.1f}" '
            f'fill="#2C445C" stroke="{BLACK}" stroke-width="{o * 0.7:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.26:.1f} {u * 0.26:.1f} '
            f'L {u * 0.26:.1f} {u * 0.26:.1f}" fill="none" stroke="{BLACK}" '
            f'stroke-width="{o * 0.5:.1f}"/>')
    if kind in ("phone", "mobile", "smartphone"):
        parts.append(
            f'<rect x="{-u * 0.28:.1f}" y="{-u * 0.52:.1f}" '
            f'width="{u * 0.56:.1f}" height="{u * 1.04:.1f}" rx="{u * 0.08:.1f}" '
            f'fill="#1C1C1E" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.23:.1f}" y="{-u * 0.41:.1f}" '
            f'width="{u * 0.46:.1f}" height="{u * 0.82:.1f}" rx="{u * 0.03:.1f}" '
            f'fill="#CFE6F2" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.09:.1f}" y="{-u * 0.49:.1f}" '
            f'width="{u * 0.18:.1f}" height="{u * 0.025:.1f}" rx="{u * 0.01:.1f}" '
            f'fill="#9A9A9E"/>')
        parts.append(
            f'<circle cx="0" cy="{u * 0.43:.1f}" r="{u * 0.045:.1f}" '
            f'fill="#3A3A3C" stroke="{BLACK}" stroke-width="{o * 0.4:.1f}"/>')
    if kind in ("tray", "plate"):
        parts.append(
            f'<ellipse cx="0" cy="0" rx="{u * 0.62:.1f}" ry="{u * 0.26:.1f}" '
            f'fill="#D8D8D4" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<ellipse cx="0" cy="{-u * 0.02:.1f}" rx="{u * 0.50:.1f}" '
            f'ry="{u * 0.18:.1f}" fill="#F2F2EC" stroke="{BLACK}" '
            f'stroke-width="{o * 0.6:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.38:.1f} {-u * 0.06:.1f} '
            f'Q 0 {-u * 0.18:.1f} {u * 0.38:.1f} {-u * 0.06:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.4:.1f}"/>')
    if kind in ("cup", "mug", "coffee"):
        parts.append(
            f'<path d="M {u * 0.30:.1f} {-u * 0.20:.1f} '
            f'Q {u * 0.52:.1f} {-u * 0.16:.1f} {u * 0.48:.1f} {u * 0.08:.1f} '
            f'Q {u * 0.44:.1f} {u * 0.26:.1f} {u * 0.24:.1f} {u * 0.24:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.2:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.30:.1f} {-u * 0.34:.1f} '
            f'L {u * 0.30:.1f} {-u * 0.34:.1f} '
            f'L {u * 0.22:.1f} {u * 0.44:.1f} '
            f'Q 0 {u * 0.54:.1f} {-u * 0.22:.1f} {u * 0.44:.1f} Z" '
            f'fill="#F2F2EC" stroke="{BLACK}" stroke-width="{o:.1f}" '
            f'stroke-linejoin="round"/>')
        parts.append(
            f'<ellipse cx="0" cy="{-u * 0.34:.1f}" rx="{u * 0.30:.1f}" '
            f'ry="{u * 0.08:.1f}" fill="#6E4426" stroke="{BLACK}" '
            f'stroke-width="{o * 0.7:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.10:.1f} {-u * 0.48:.1f} '
            f'Q {-u * 0.22:.1f} {-u * 0.64:.1f} {-u * 0.06:.1f} {-u * 0.78:.1f} '
            f'Q {u * 0.06:.1f} {-u * 0.88:.1f} {-u * 0.04:.1f} {-u * 1.00:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.6:.1f}" '
            f'stroke-linecap="round"/>')
        parts.append(
            f'<path d="M {u * 0.12:.1f} {-u * 0.50:.1f} '
            f'Q {u * 0.02:.1f} {-u * 0.64:.1f} {u * 0.14:.1f} {-u * 0.74:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}" '
            f'stroke-linecap="round"/>')
    if kind in ("clipboard", "board"):
        parts.append(
            f'<rect x="{-u * 0.34:.1f}" y="{-u * 0.56:.1f}" '
            f'width="{u * 0.68:.1f}" height="{u * 1.12:.1f}" rx="{u * 0.05:.1f}" '
            f'fill="#8A6A44" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.27:.1f}" y="{-u * 0.45:.1f}" '
            f'width="{u * 0.54:.1f}" height="{u * 0.86:.1f}" '
            f'fill="#FBF8EF" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
        for i in range(3):
            yy = -u * 0.28 + i * u * 0.22
            parts.append(
                f'<path d="M {-u * 0.20:.1f} {yy:.1f} '
                f'L {u * 0.20:.1f} {yy:.1f}" fill="none" stroke="{BLACK}" '
                f'stroke-width="{o * 0.4:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.16:.1f}" y="{-u * 0.63:.1f}" '
            f'width="{u * 0.32:.1f}" height="{u * 0.15:.1f}" rx="{u * 0.03:.1f}" '
            f'fill="#6E6E76" stroke="{BLACK}" stroke-width="{o * 0.8:.1f}"/>')
    if kind in ("parcel", "package", "box"):
        parts.append(
            f'<rect x="{-u * 0.48:.1f}" y="{-u * 0.36:.1f}" '
            f'width="{u * 0.96:.1f}" height="{u * 0.80:.1f}" '
            f'fill="#C69A62" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.07:.1f}" y="{-u * 0.36:.1f}" '
            f'width="{u * 0.14:.1f}" height="{u * 0.80:.1f}" '
            f'fill="#DCC79C" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.48:.1f}" y="{-u * 0.05:.1f}" '
            f'width="{u * 0.96:.1f}" height="{u * 0.14:.1f}" '
            f'fill="#DCC79C" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
        parts.append(
            f'<rect x="{u * 0.16:.1f}" y="{u * 0.18:.1f}" '
            f'width="{u * 0.26:.1f}" height="{u * 0.16:.1f}" '
            f'fill="#FBF8EF" stroke="{BLACK}" stroke-width="{o * 0.4:.1f}"/>')
        parts.append(
            f'<path d="M {u * 0.20:.1f} {u * 0.24:.1f} '
            f'L {u * 0.38:.1f} {u * 0.24:.1f}" fill="none" stroke="{BLACK}" '
            f'stroke-width="{o * 0.35:.1f}"/>')
    if kind == "key":
        parts.append(
            f'<circle cx="{-u * 0.30:.1f}" cy="0" r="{u * 0.26:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.5:.1f}"/>')
        parts.append(
            f'<circle cx="{-u * 0.30:.1f}" cy="0" r="{u * 0.11:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.4:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.06:.1f}" y="{-u * 0.06:.1f}" '
            f'width="{u * 0.62:.1f}" height="{u * 0.12:.1f}" '
            f'fill="#C9A227" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        for xx, hh in ((0.26, 0.12), (0.44, 0.16)):
            parts.append(
                f'<rect x="{u * xx:.1f}" y="{u * 0.06:.1f}" '
                f'width="{u * 0.10:.1f}" height="{u * hh:.1f}" '
                f'fill="#C9A227" stroke="{BLACK}" stroke-width="{o * 0.7:.1f}"/>')
    if kind in ("book", "notebook"):
        parts.append(
            f'<path d="M {-u * 0.52:.1f} {-u * 0.44:.1f} '
            f'Q {-u * 0.26:.1f} {-u * 0.52:.1f} {0:.1f} {-u * 0.40:.1f} '
            f'L 0 {u * 0.44:.1f} '
            f'Q {-u * 0.26:.1f} {u * 0.52:.1f} {-u * 0.52:.1f} {u * 0.44:.1f} Z" '
            f'fill="#7A3030" stroke="{BLACK}" stroke-width="{o:.1f}" '
            f'stroke-linejoin="round"/>')
        parts.append(
            f'<path d="M {u * 0.52:.1f} {-u * 0.44:.1f} '
            f'Q {u * 0.26:.1f} {-u * 0.52:.1f} {0:.1f} {-u * 0.40:.1f} '
            f'L 0 {u * 0.44:.1f} '
            f'Q {u * 0.26:.1f} {u * 0.52:.1f} {u * 0.52:.1f} {u * 0.44:.1f} Z" '
            f'fill="#8C3A3A" stroke="{BLACK}" stroke-width="{o:.1f}" '
            f'stroke-linejoin="round"/>')
        parts.append(
            f'<path d="M {-u * 0.46:.1f} {-u * 0.38:.1f} '
            f'Q {-u * 0.24:.1f} {-u * 0.44:.1f} {-u * 0.04:.1f} {-u * 0.34:.1f} '
            f'L {-u * 0.04:.1f} {u * 0.38:.1f} '
            f'Q {-u * 0.24:.1f} {u * 0.44:.1f} {-u * 0.46:.1f} {u * 0.38:.1f} Z" '
            f'fill="#F6F1E2" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
        parts.append(
            f'<path d="M {u * 0.46:.1f} {-u * 0.38:.1f} '
            f'Q {u * 0.24:.1f} {-u * 0.44:.1f} {u * 0.04:.1f} {-u * 0.34:.1f} '
            f'L {u * 0.04:.1f} {u * 0.38:.1f} '
            f'Q {u * 0.24:.1f} {u * 0.44:.1f} {u * 0.46:.1f} {u * 0.38:.1f} Z" '
            f'fill="#F6F1E2" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
        parts.append(
            f'<path d="M 0 {-u * 0.40:.1f} L 0 {u * 0.44:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.2:.1f}"/>')
    if kind == "stamp":
        parts.append(
            f'<ellipse cx="0" cy="{-u * 0.46:.1f}" rx="{u * 0.18:.1f}" '
            f'ry="{u * 0.14:.1f}" fill="#A07040" stroke="{BLACK}" '
            f'stroke-width="{o:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.09:.1f} {-u * 0.36:.1f} '
            f'L {-u * 0.14:.1f} {u * 0.16:.1f} '
            f'L {u * 0.14:.1f} {u * 0.16:.1f} '
            f'L {u * 0.09:.1f} {-u * 0.36:.1f} Z" '
            f'fill="#8A5A30" stroke="{BLACK}" stroke-width="{o:.1f}" '
            f'stroke-linejoin="round"/>')
        parts.append(
            f'<rect x="{-u * 0.30:.1f}" y="{u * 0.16:.1f}" '
            f'width="{u * 0.60:.1f}" height="{u * 0.20:.1f}" rx="{u * 0.03:.1f}" '
            f'fill="#6E4426" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
    if kind in ("scale", "weighing_scale"):
        parts.append(
            f'<rect x="{-u * 0.05:.1f}" y="{-u * 0.10:.1f}" '
            f'width="{u * 0.10:.1f}" height="{u * 0.70:.1f}" '
            f'fill="#6E6E76" stroke="{BLACK}" stroke-width="{o * 0.8:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.36:.1f}" y="{u * 0.58:.1f}" '
            f'width="{u * 0.72:.1f}" height="{u * 0.14:.1f}" rx="{u * 0.04:.1f}" '
            f'fill="#5A5A62" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.54:.1f} {-u * 0.10:.1f} '
            f'L {u * 0.54:.1f} {-u * 0.10:.1f}" fill="none" stroke="{BLACK}" '
            f'stroke-width="{o * 1.2:.1f}"/>')
        parts.append(
            f'<circle cx="0" cy="{-u * 0.10:.1f}" r="{u * 0.07:.1f}" '
            f'fill="#C9A227" stroke="{BLACK}" stroke-width="{o * 0.6:.1f}"/>')
        for sg in (-1, 1):
            bx = sg * u * 0.54
            parts.append(
                f'<path d="M {bx:.1f} {-u * 0.10:.1f} '
                f'L {bx + sg * u * 0.10:.1f} {u * 0.24:.1f} '
                f'M {bx:.1f} {-u * 0.10:.1f} '
                f'L {bx - sg * u * 0.10:.1f} {u * 0.24:.1f}" fill="none" '
                f'stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
            x1, x2 = bx - u * 0.18, bx + u * 0.18
            parts.append(
                f'<path d="M {x1:.1f} {u * 0.24:.1f} '
                f'Q {bx:.1f} {u * 0.42:.1f} {x2:.1f} {u * 0.24:.1f} Z" '
                f'fill="#C9A227" stroke="{BLACK}" stroke-width="{o * 0.7:.1f}"/>')
    if kind in ("stamp_book", "booklet"):
        parts.append(
            f'<rect x="{-u * 0.36:.1f}" y="{-u * 0.48:.1f}" '
            f'width="{u * 0.72:.1f}" height="{u * 0.96:.1f}" rx="{u * 0.03:.1f}" '
            f'fill="#3A6E8C" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.29:.1f}" y="{-u * 0.41:.1f}" '
            f'width="{u * 0.58:.1f}" height="{u * 0.82:.1f}" '
            f'fill="#F6F1E2" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
        for row in range(2):
            for col in range(3):
                sx = -u * 0.25 + col * u * 0.17
                sy = -u * 0.35 + row * u * 0.30
                parts.append(
                    f'<rect x="{sx:.1f}" y="{sy:.1f}" '
                    f'width="{u * 0.14:.1f}" height="{u * 0.22:.1f}" '
                    f'fill="#E8DCC0" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}" '
                    f'stroke-dasharray="{u * 0.03:.1f} {u * 0.02:.1f}"/>')
    if kind == "ticket":
        parts.append(
            f'<rect x="{-u * 0.54:.1f}" y="{-u * 0.22:.1f}" '
            f'width="{u * 1.08:.1f}" height="{u * 0.44:.1f}" rx="{u * 0.02:.1f}" '
            f'fill="#F0DEA8" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<path d="M {u * 0.34:.1f} {-u * 0.22:.1f} '
            f'L {u * 0.34:.1f} {u * 0.22:.1f}" fill="none" stroke="{BLACK}" '
            f'stroke-width="{o * 0.7:.1f}" '
            f'stroke-dasharray="{u * 0.05:.1f} {u * 0.04:.1f}"/>')
        parts.append(
            f'<path d="M {-u * 0.44:.1f} {-u * 0.10:.1f} '
            f'L {u * 0.22:.1f} {-u * 0.10:.1f} '
            f'M {-u * 0.44:.1f} {u * 0.06:.1f} '
            f'L {u * 0.14:.1f} {u * 0.06:.1f}" fill="none" stroke="{BLACK}" '
            f'stroke-width="{o * 0.4:.1f}"/>')
        parts.append(
            f'<circle cx="{u * 0.45:.1f}" cy="0" r="{u * 0.07:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
    if kind in ("bottle", "water_bottle"):
        parts.append(
            f'<path d="M {-u * 0.12:.1f} {-u * 0.34:.1f} '
            f'L {-u * 0.12:.1f} {-u * 0.20:.1f} '
            f'Q {-u * 0.30:.1f} {-u * 0.12:.1f} {-u * 0.28:.1f} {u * 0.06:.1f} '
            f'L {-u * 0.26:.1f} {u * 0.44:.1f} '
            f'Q 0 {u * 0.54:.1f} {u * 0.26:.1f} {u * 0.44:.1f} '
            f'L {u * 0.28:.1f} {u * 0.06:.1f} '
            f'Q {u * 0.30:.1f} {-u * 0.12:.1f} {u * 0.12:.1f} {-u * 0.20:.1f} '
            f'L {u * 0.12:.1f} {-u * 0.34:.1f} Z" '
            f'fill="#7FC4D8" stroke="{BLACK}" stroke-width="{o:.1f}" '
            f'stroke-linejoin="round"/>')
        parts.append(
            f'<rect x="{-u * 0.15:.1f}" y="{-u * 0.52:.1f}" '
            f'width="{u * 0.30:.1f}" height="{u * 0.18:.1f}" rx="{u * 0.03:.1f}" '
            f'fill="#3A8CA8" stroke="{BLACK}" stroke-width="{o:.1f}"/>')
        parts.append(
            f'<rect x="{-u * 0.24:.1f}" y="{u * 0.10:.1f}" '
            f'width="{u * 0.48:.1f}" height="{u * 0.22:.1f}" rx="{u * 0.02:.1f}" '
            f'fill="#F2EEE0" stroke="{BLACK}" stroke-width="{o * 0.5:.1f}"/>')
    if kind == "umbrella":
        parts.append(
            f'<path d="M {-u * 0.56:.1f} {-u * 0.16:.1f} '
            f'Q {-u * 0.42:.1f} {-u * 0.76:.1f} {0:.1f} {-u * 0.80:.1f} '
            f'Q {u * 0.42:.1f} {-u * 0.76:.1f} {u * 0.56:.1f} {-u * 0.16:.1f} '
            f'Q {u * 0.28:.1f} {-u * 0.30:.1f} {0:.1f} {-u * 0.16:.1f} '
            f'Q {-u * 0.28:.1f} {-u * 0.30:.1f} {-u * 0.56:.1f} {-u * 0.16:.1f} Z" '
            f'fill="#C0202C" stroke="{BLACK}" stroke-width="{o:.1f}" '
            f'stroke-linejoin="round"/>')
        parts.append(
            f'<path d="M 0 {-u * 0.80:.1f} L 0 {u * 0.52:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.2:.1f}"/>')
        parts.append(
            f'<path d="M 0 {-u * 0.78:.1f} L {-u * 0.28:.1f} {-u * 0.20:.1f} '
            f'M 0 {-u * 0.78:.1f} L {u * 0.28:.1f} {-u * 0.20:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.4:.1f}"/>')
        parts.append(
            f'<path d="M 0 {u * 0.52:.1f} '
            f'Q 0 {u * 0.76:.1f} {-u * 0.20:.1f} {u * 0.72:.1f} '
            f'Q {-u * 0.32:.1f} {u * 0.68:.1f} {-u * 0.28:.1f} {u * 0.54:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 1.4:.1f}" '
            f'stroke-linecap="round"/>')
        parts.append(
            f'<path d="M 0 {-u * 0.80:.1f} L 0 {-u * 0.90:.1f}" '
            f'fill="none" stroke="{BLACK}" stroke-width="{o * 0.8:.1f}"/>')
    if parts:
        return g + "".join(parts) + "</g>"
    return g + "</g>"


def actor_svg(rig, pose, root, scale=1.0, facing=1, blink=False, props=None,
              overlay_arm=None):
    """Draw one actor from solved joints. Returns (skeleton, svg)."""
    o = rig["outline"] * max(0.75, min(scale, 1.5))
    g = rig["hex"]
    sk = solve_skeleton(rig, pose, root, scale, facing)
    lw = max(2.6, rig["limb_w"] * scale)
    hw = rig["head_w"] * scale
    hh = rig["head_h"] * scale
    body = []

    def leg(side, alpha):
        pts = [sk[f"hip_{side}_p"], sk[f"knee_{side}"], sk[f"foot_{side}"]]
        out = [_stroke(pts, lw * alpha)]
        fx, fy = sk[f"foot_{side}"]
        out.append(f'<ellipse cx="{fx + lw * 0.80 * facing:.2f}" cy="{fy - lw * 0.04:.2f}" '
                   f'rx="{lw * 1.55:.2f}" ry="{lw * 0.72:.2f}" fill="{g["shoe"]}"/>')
        return "".join(out)

    def arm(side, alpha):
        pts = [sk[f"shoulder_{side}"], sk[f"elbow_{side}"], sk[f"hand_{side}"]]
        out = [_stroke(pts, lw * alpha)]
        hx, hy = sk[f"hand_{side}"]
        out.append(f'<circle cx="{hx:.2f}" cy="{hy:.2f}" r="{lw * 1.02 * alpha:.2f}" '
                   f'fill="{BLACK}"/>')
        return "".join(out)

    # depth order: a backward-swinging arm belongs BEHIND the torso, a forward
    # one in front. Fixing the order paints a black stripe across the chest.
    # flared garments reach past the hanging arm, so a "behind the torso" arm
    # would lose its forearm inside the skirt. Arms stay in front on dress/coat.
    flared = rig.get("body") in ("dress", "coat")
    back_l = pose.get("sh_l", 0) < 0 and not flared
    back_r = pose.get("sh_r", 0) < 0 and not flared
    overlay = ""
    body.append(leg("l", 0.94))
    if back_l and overlay_arm != "l":
        body.append(arm("l", 0.94))
    elif overlay_arm == "l":
        overlay = arm("l", 0.94)
    body.append(torso_svg(rig, sk, scale, facing))
    if not back_l and overlay_arm != "l":
        body.append(arm("l", 0.94))
    body.append(leg("r", 1.0))

    for p in (props or []):
        hand = p.get("hand", "r")
        at = p.get("at") or sk[f"hand_{hand}"]
        ang = pose.get(f"sh_{hand}", 0) + pose.get(f"el_{hand}", 0)
        if p.get("upright"):        # flags/lanterns hang from world vertical
            ang = 0.0
        psize = rig["height"] * 0.20 * float(p.get("scale", 1.0))
        ps = prop_svg(p.get("kind", "pan"), at, ang, scale, o, psize)
        if "opacity" in p:
            op = max(0.0, min(1.0, float(p["opacity"])))
            ps = f'<g opacity="{op:.2f}">' + ps + "</g>"
        body.append(ps)

    if not back_r and overlay_arm != "r":
        body.append(arm("r", 1.0))
    elif overlay_arm == "r":
        overlay = arm("r", 1.0)

    # head last so no limb ever crosses the face
    hx, hy = sk["head"]
    body.append(f'<g transform="translate({hx:.2f} {hy:.2f}) '
                f'rotate({-(sk["head_tilt"] + sk["lean"]):.2f}) scale({facing} 1)">')
    body.append(hair_svg(rig, hw, hh, rig.get("hair_kind", "short"), g["hair"]))
    body.append(f'<ellipse cx="0" cy="0" rx="{hw * 0.5:.2f}" ry="{hh * 0.5:.2f}" '
                f'fill="{g["face"]}" stroke="{BLACK}" stroke-width="{o:.2f}"/>')
    body.append(face_svg(rig, 0, 0, scale, pose.get("expr", "neutral"),
                         pose.get("mouth", 0.0), blink, facing=1))
    if rig.get("beard"):
        body.append(beard_svg(rig, hw, hh, g["hair"]))
    body.append(hat_svg(rig, hw, hh, rig.get("hat_kind", "none"), g["hat"],
                        g["accent"], o))
    body.append("</g>")
    if back_r and overlay_arm != "r":
        body.append(arm("r", 1.0))

    return sk, "".join(body), overlay


def scene_svg(actors, extra_svg="", camera=None):
    """actors: [{rig, pose, root, scale, facing, props, blink}] sorted by depth.

    `camera` = (zoom, dx, dy, anchor_x, anchor_y) applies one transform to the
    whole actor layer. Anchoring on the feet line means a push-in grows the
    character without lifting it off the ground.
    """
    parts, overlays = [], []
    for a in actors:
        _, svg, ov = actor_svg(a["rig"], a["pose"], a["root"], a.get("scale", 1.0),
                               a.get("facing", 1), a.get("blink", False),
                               a.get("props"), a.get("overlay_arm"))
        parts.append((a.get("z", a["root"][1]), svg))
        if ov:
            overlays.append(ov)
    parts.sort(key=lambda t: t[0])
    # a contacting arm is drawn after every body, so it lands ON the actor it touches
    inner = extra_svg + "".join(s for _, s in parts) + "".join(overlays)
    if camera:
        z, dx, dy, ax, ay = camera
        if abs(z - 1.0) > 1e-6 or abs(dx) > 0.01 or abs(dy) > 0.01:
            inner = (f'<g transform="translate({dx:.2f} {dy:.2f}) '
                     f'translate({ax:.2f} {ay:.2f}) scale({z:.5f}) '
                     f'translate({-ax:.2f} {-ay:.2f})">' + inner + "</g>")
    return (f'<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" '
            f'viewBox="0 0 {W} {H}">' + inner + "</svg>")


# ------------------------------------------------------------------ contact
def _arm_ik(rig, pose, root, side, target, scale=1.0, facing=1, elbow_back=True):
    """Two-bone IK. Returns (shoulder_deg, elbow_deg, reach_ratio).

    Angles use the rig convention: 0 = hanging down, +90 = forward, knees/elbows
    bend with negative values. reach_ratio > 0.95 means the arm is locked
    straight, which reads as a mannequin — keep it <= 0.92.
    """
    sk = solve_skeleton(rig, pose, root, scale, facing)
    sh = sk[f"shoulder_{side}"]
    L1 = rig["upper_arm"] * scale
    L2 = rig["fore_arm"] * scale
    u = (target[0] - sh[0]) * facing          # forward +
    v = target[1] - sh[1]                     # down +
    d = math.hypot(u, v)
    dmax = L1 + L2
    dcl = max(abs(L1 - L2) + 0.5, min(d, dmax - 0.5))
    theta = math.degrees(math.atan2(u, v))
    ca = (dcl * dcl + L1 * L1 - L2 * L2) / (2 * dcl * L1)
    alpha = math.degrees(math.acos(max(-1.0, min(1.0, ca))))
    a1 = theta - alpha if elbow_back else theta + alpha
    ex = sh[0] + math.sin(math.radians(a1)) * L1 * facing
    ey = sh[1] + math.cos(math.radians(a1)) * L1
    a2 = math.degrees(math.atan2((target[0] - ex) * facing, target[1] - ey))
    return a1, a2 - a1, d / dmax


def reach(rig, pose, root, side, target, scale=1.0, facing=1, weight=1.0):
    """Blend the arm into an IK reach. weight 0 = untouched, 1 = hand on target."""
    a1, el, ratio = _arm_ik(rig, pose, root, side, target, scale, facing)
    w = max(0.0, min(1.0, weight))
    pose[f"sh_{side}"] = pose.get(f"sh_{side}", 8.0) * (1 - w) + a1 * w
    pose[f"el_{side}"] = pose.get(f"el_{side}", 6.0) * (1 - w) + el * w
    return ratio


def hand_of(actor, side="r"):
    return solve_skeleton(actor["rig"], actor["pose"], actor["root"],
                          actor.get("scale", 1), actor.get("facing", 1))[f"hand_{side}"]


def contact_residual(a, b, hand_a="r", hand_b="r"):
    """Distance between the two hands, in px (Section D.5: contact on one frame)."""
    pa, pb = hand_of(a, hand_a), hand_of(b, hand_b)
    return math.hypot(pa[0] - pb[0], pa[1] - pb[1])


def solve_contact(a, b, hand_a="r", hand_b="r", tol=0.5, iters=4):
    """IK actor b onto actor a's hand. Feet never move; only b's arm does.

    Returns (residual_px, reach_ratio). A ratio above 0.92 means the actors are
    too far apart for the pose to read — move b closer instead of stretching.
    """
    ratio = 1.0
    for _ in range(iters):
        target = hand_of(a, hand_a)
        ratio = reach(b["rig"], b["pose"], b["root"], hand_b, target,
                      b.get("scale", 1), b.get("facing", 1), 1.0)
        if contact_residual(a, b, hand_a, hand_b) <= tol:
            break
    return contact_residual(a, b, hand_a, hand_b), ratio


def plant(rig, pose, root, scale=1.0, facing=1, ground_y=None):
    """Slide the root vertically so the lowest foot sits exactly on the ground.

    Authoring legs by angle always leaves the hips at the wrong height: a walk
    cycle rises and falls ~16px on its own. Planting removes that error instead
    of hand-tuning `bob`, which is why nothing in this rig floats or sinks.
    """
    if ground_y is None:
        return root
    sk = solve_skeleton(rig, pose, root, scale, facing)
    low = max(sk["foot_l"][1], sk["foot_r"][1])
    return (root[0], root[1] + (ground_y - low))


# ------------------------------------------------------------------ poses
def idle_pose(t, rig):
    b = math.sin(t * TAU / 2.6)
    return {"torso": 1.2 * b, "head": -0.8 * b, "sh_l": 7, "el_l": 6,
            "sh_r": 7, "el_r": 6, "hip_l": 1, "kn_l": 1, "hip_r": -1, "kn_r": 1,
            "expr": "neutral", "mouth": 0.0, "bob": 1.5 * b}


def walk_pose(phase, rig, speed=1.0):
    """Front-on walk: a 10-degree hip swing and a real knee lift.

    A front-facing rig has no depth axis, so a 24-degree swing reads as legs
    scissoring through each other. Keep the swing small and let the knee lift
    and the body bob carry the step; use big swings only in profile views.
    """
    a = TAU * (phase % 1.0)
    hip_r = math.sin(a) * 10 * speed
    hip_l = -hip_r
    kn_r = -22 * max(0.0, -math.sin(a - 0.6)) * speed
    kn_l = -22 * max(0.0, -math.sin(a + math.pi - 0.6)) * speed
    return {"torso": 2.0 * speed, "head": -1.5 * speed,
            "sh_l": -7 * math.sin(a) * speed, "el_l": 8,
            "sh_r": 7 * math.sin(a) * speed, "el_r": 8,
            "hip_l": hip_l, "kn_l": kn_l, "hip_r": hip_r, "kn_r": kn_r,
            "expr": "neutral", "mouth": 0.0,
            "bob": -abs(math.sin(a * 2)) * 3 * speed}


def wave_pose(t, rig):
    w = math.sin(t * TAU / 0.9)
    p = idle_pose(t, rig)
    p.update({"sh_r": 132 + 8 * w, "el_r": -22 + 12 * w,
              "sh_l": 6, "el_l": 8, "expr": "happy", "head": 2 * w})
    return p


# ------------------------------------------------------------------ actions
# Section D.5. Angles: 0 = hanging down, +90 = horizontal to the character's
# right, >90 = raised. Knees bend with negative values.
ACTION_TABLE = {
    "handshake": {"frames": 26, "contact": 14, "expr": "happy", "hand": "r", "keys": [
        (0,  {"sh_r": 6,   "el_r": 6,  "torso": 0,   "head": 0}),
        (8,  {"sh_r": 58,  "el_r": 22, "torso": -2,  "head": -1}),
        (14, {"sh_r": 70,  "el_r": 10, "torso": -3,  "head": -2}),
        (19, {"sh_r": 74,  "el_r": 8,  "torso": -3,  "head": -1}),
        (22, {"sh_r": 68,  "el_r": 12, "torso": -2,  "head": 0}),
        (26, {"sh_r": 6,   "el_r": 6,  "torso": 0,   "head": 0}),
    ]},
    "handoff": {"frames": 20, "contact": 10, "expr": "neutral", "hand": "r", "keys": [
        (0,  {"sh_r": 6,  "el_r": 6,  "torso": 0}),
        (6,  {"sh_r": 55, "el_r": 26, "torso": -2}),
        (10, {"sh_r": 66, "el_r": 14, "torso": -3}),
        (14, {"sh_r": 52, "el_r": 18, "torso": -1}),
        (20, {"sh_r": 6,  "el_r": 6,  "torso": 0}),
    ]},
    "push": {"frames": 22, "contact": 10, "expr": "angry", "hand": "r", "keys": [
        (0,  {"sh_r": 8,  "el_r": 8,  "torso": 0,  "hip_r": 0,   "kn_r": 0}),
        (4,  {"sh_r": 30, "el_r": 24, "torso": 4,  "hip_r": -10, "kn_r": -8}),
        (10, {"sh_r": 66, "el_r": 12, "torso": 12, "hip_r": -16, "kn_r": -12}),
        (16, {"sh_r": 62, "el_r": 14, "torso": 14, "hip_r": -14, "kn_r": -10}),
        (22, {"sh_r": 10, "el_r": 8,  "torso": 2,  "hip_r": 0,   "kn_r": 0}),
    ]},
    "pull": {"frames": 22, "contact": 8, "expr": "angry", "hand": "r", "keys": [
        (0,  {"sh_r": 10, "el_r": 10, "torso": 0}),
        (8,  {"sh_r": 62, "el_r": 18, "torso": -8}),
        (14, {"sh_r": 48, "el_r": 34, "torso": -14}),
        (18, {"sh_r": 54, "el_r": 26, "torso": -6}),
        (22, {"sh_r": 10, "el_r": 10, "torso": 0}),
    ]},
    "lift": {"frames": 26, "contact": 8, "expr": "angry", "hand": "r", "keys": [
        (0,  {"sh_r": 20, "el_r": 20, "torso": 0,  "hip_r": 0,   "kn_r": 0,   "hip_l": 0,   "kn_l": 0}),
        (8,  {"sh_r": 46, "el_r": 30, "torso": 16, "hip_r": -14, "kn_r": -30, "hip_l": -14, "kn_l": -30}),
        (16, {"sh_r": 60, "el_r": 10, "torso": 8,  "hip_r": -6,  "kn_r": -10, "hip_l": -6,  "kn_l": -10}),
        (20, {"sh_r": 62, "el_r": 6,  "torso": 2,  "hip_r": 0,   "kn_r": 0,   "hip_l": 0,   "kn_l": 0}),
        (26, {"sh_r": 58, "el_r": 8,  "torso": 0,  "hip_r": 0,   "kn_r": 0,   "hip_l": 0,   "kn_l": 0}),
    ]},
    "strike": {"frames": 18, "contact": 10, "expr": "angry", "hand": "r", "keys": [
        (0,  {"sh_r": 20,  "el_r": 10,  "torso": 0}),
        (5,  {"sh_r": 150, "el_r": -30, "torso": -10}),
        (7,  {"sh_r": 146, "el_r": -26, "torso": -8}),
        (10, {"sh_r": 40,  "el_r": 6,   "torso": 16}),
        (13, {"sh_r": 46,  "el_r": 12,  "torso": 8}),
        (18, {"sh_r": 20,  "el_r": 10,  "torso": 0}),
    ]},
    "throw": {"frames": 22, "contact": 12, "expr": "angry", "hand": "r", "keys": [
        (0,  {"sh_r": 10,  "el_r": 10,  "torso": 0}),
        (8,  {"sh_r": -34, "el_r": -24, "torso": -12}),
        (12, {"sh_r": 96,  "el_r": 8,   "torso": 12}),
        (16, {"sh_r": 74,  "el_r": 18,  "torso": 6}),
        (22, {"sh_r": 12,  "el_r": 10,  "torso": 0}),
    ]},
    "catch": {"frames": 12, "contact": 5, "expr": "shocked", "hand": "r", "keys": [
        (0,  {"sh_r": 30, "el_r": 20, "torso": 0}),
        (5,  {"sh_r": 72, "el_r": 22, "torso": -4}),
        (8,  {"sh_r": 62, "el_r": 36, "torso": 2}),
        (12, {"sh_r": 30, "el_r": 20, "torso": 0}),
    ]},
    "light_fuse": {"frames": 18, "contact": 8, "expr": "neutral", "hand": "r", "keys": [
        (0,  {"sh_r": 20, "el_r": 16, "torso": 0}),
        (4,  {"sh_r": 52, "el_r": 42, "torso": -2}),
        (8,  {"sh_r": 58, "el_r": 52, "torso": -4}),
        (14, {"sh_r": 46, "el_r": 40, "torso": -1}),
        (18, {"sh_r": 20, "el_r": 16, "torso": 0}),
    ]},
    "point": {"frames": 12, "contact": 6, "expr": "neutral", "hand": "r", "keys": [
        (0,  {"sh_r": 10, "el_r": 8, "torso": 0,  "head": 0}),
        (6,  {"sh_r": 84, "el_r": 0, "torso": -4, "head": -3}),
        (12, {"sh_r": 82, "el_r": 2, "torso": -4, "head": -3}),
    ]},
    "shrug": {"frames": 12, "contact": 5, "expr": "worried", "hand": "r", "keys": [
        (0,  {"sh_r": 10, "el_r": 8,  "sh_l": 10, "el_l": 8,  "head": 0}),
        (5,  {"sh_r": 26, "el_r": 46, "sh_l": 26, "el_l": 46, "head": 3}),
        (9,  {"sh_r": 24, "el_r": 44, "sh_l": 24, "el_l": 44, "head": 2}),
        (12, {"sh_r": 10, "el_r": 8,  "sh_l": 10, "el_l": 8,  "head": 0}),
    ]},
    "nod": {"frames": 10, "contact": 4, "expr": "neutral", "hand": "r", "keys": [
        (0, {"head": 0}), (3, {"head": 6}), (6, {"head": 5}), (10, {"head": 0}),
    ]},
    "fall": {"frames": 18, "contact": 12, "expr": "shocked", "hand": "r", "keys": [
        (0,  {"torso": 0,  "hip_r": 0,   "kn_r": 0,  "hip_l": 0,  "kn_l": 0,  "bob": 0}),
        (4,  {"torso": -6, "hip_r": -10, "kn_r": -14, "hip_l": 6,  "kn_l": 10, "bob": 0}),
        (12, {"torso": 34, "hip_r": -34, "kn_r": 34, "hip_l": 22, "kn_l": 46, "bob": 90}),
        (15, {"torso": 36, "hip_r": -30, "kn_r": 30, "hip_l": 20, "kn_l": 44, "bob": 96}),
        (18, {"torso": 34, "hip_r": -28, "kn_r": 28, "hip_l": 18, "kn_l": 42, "bob": 94}),
    ]},
    "hit": {"frames": 14, "contact": 2, "expr": "shocked", "hand": "r", "keys": [
        (0,  {"torso": 0,   "head": 0,   "sh_r": 10, "sh_l": 10}),
        (2,  {"torso": -14, "head": -10, "sh_r": 34, "sh_l": -28}),
        (8,  {"torso": -6,  "head": -4,  "sh_r": 20, "sh_l": -10}),
        (14, {"torso": 0,   "head": 0,   "sh_r": 10, "sh_l": 10}),
    ]},
}


def action_pose(name, frame, rig, base=None):
    """Sample one frame of a D.5 action. Returns (pose, contact_frame)."""
    spec = ACTION_TABLE[name]
    pose = dict(base if base is not None else idle_pose(frame / 30.0, rig))
    keys = spec["keys"]
    joints = set()
    for _, d in keys:
        joints |= set(d.keys())
    for j in joints:
        if j == "bob":
            continue
        seq = [{"f": f, "a": float(d.get(j, keys[0][1].get(j, 0.0))),
                "ease": "easeInOut"} for f, d in keys]
        pose[j] = sample_keys(seq, frame)
    if any("bob" in d for _, d in keys):
        pose["bob"] = sample_keys(
            [{"f": f, "a": float(d.get("bob", 0.0)), "ease": "easeInOut"} for f, d in keys],
            frame)
    if spec.get("expr"):
        pose["expr"] = spec["expr"]
    return pose, spec["contact"]


# ------------------------------------------------------------------ render
def demo_pose(frame, rig):
    t = frame / 30.0
    if t < 0.9:
        return walk_pose(t * 0.9, rig)
    if t < 1.9:
        return wave_pose(t - 0.9, rig)
    return walk_pose((t - 1.9) * 0.9, rig)


def action_demo(action, hold=15, base=None):
    spec = ACTION_TABLE[action]
    span = spec["frames"] + hold * 2

    def fn(frame, rig):
        k = frame % span
        if k < hold or k >= hold + spec["frames"]:
            pose = idle_pose(frame / 30.0, rig)
            pose["expr"] = spec.get("expr", "neutral")
            return pose
        pose, _ = action_pose(action, k - hold, rig)
        if base:
            pose.update(base)
        return pose

    return fn


DUO_ACTIONS = {
    # name        frames  contact  release  prop
    "handshake": {"frames": 30, "contact": 14, "release": 22, "expr": "happy"},
    "handoff":   {"frames": 26, "contact": 12, "release": 19, "expr": "neutral"},
    "push":      {"frames": 26, "contact": 11, "release": 20, "expr": "angry"},
}


def _lerp(a, b, t):
    return a + (b - a) * max(0.0, min(1.0, t))


def duo_layout(rig_a, rig_b, action, frame, scale=1.0, feet_y=1200,
               spacing=None, props_a=None, props_b=None):
    """Two actors sharing one contact point.

    Both right arms IK onto the same point, so the grip is exact on the contact
    frame and stays exact while they hold. The body work (lean, other arm,
    expression, prop transfer) is authored around that point.
    """
    spec = DUO_ACTIONS[action]
    F, C, R = spec["frames"], spec["contact"], spec["release"]
    height = (rig_a["leg_h"] + rig_a["torso_h"] + rig_a["head_h"]) * scale
    root_y = feet_y - height
    tw = rig_a["torso_w"] * scale
    # spacing is set per action so the reaching arm stays bent (ratio <= 0.90)
    default_sep = {"handshake": tw * 2.15, "handoff": tw * 1.95,
                   "push": tw * 1.75}[action]
    sep = spacing if spacing is not None else default_sep
    ax, bx = 540 - sep / 2, 540 + sep / 2
    chest_y = root_y - rig_a["torso_h"] * 0.50 * scale
    mid = ((ax + bx) / 2, chest_y)

    f = max(0, min(frame, F))
    # approach 0..C, hold C..R, release R..F
    if f <= C:
        w = _lerp(0.0, 1.0, f / max(1, C))
    elif f <= R:
        w = 1.0
    else:
        w = _lerp(1.0, 0.0, (f - R) / max(1, F - R))

    # the grip point travels from each actor's own chest to the shared point
    pulse = 2.5 * math.sin((f - C) * 1.6) if C <= f <= R else 0.0
    grip = (mid[0], mid[1] + pulse)

    pa = dict(idle_pose(frame / 30.0, rig_a))
    pb = dict(idle_pose(frame / 30.0, rig_b))
    pa["expr"] = spec["expr"] if C - 3 <= f <= R + 3 else "neutral"
    pb["expr"] = spec["expr"] if C - 3 <= f <= R + 3 else "neutral"

    # lean in on approach, settle back on release
    pa["torso"] = _lerp(0.0, 3.5, w) + pa["torso"]
    pb["torso"] = -(_lerp(0.0, 3.5, w)) + pb["torso"]

    a = {"rig": rig_a, "pose": pa, "root": (ax, root_y), "scale": scale,
         "facing": 1, "z": root_y - 1}
    b = {"rig": rig_b, "pose": pb, "root": (bx, root_y), "scale": scale,
         "facing": -1, "z": root_y}
    # ground them first: IK must aim at where the hands will actually be
    a["root"] = plant(rig_a, pa, a["root"], scale, 1, feet_y)
    b["root"] = plant(rig_b, pb, b["root"], scale, -1, feet_y)
    chest_y = max(a["root"][1], b["root"][1]) - rig_a["torso_h"] * 0.34 * scale
    mid = ((a["root"][0] + b["root"][0]) / 2, chest_y)
    grip = (mid[0], mid[1] + pulse)

    if action == "push":
        # A drives forward into B's chest; B absorbs with a lean and a flail
        contact = (b["root"][0] - tw * 0.52,
                   b["root"][1] - rig_b["torso_h"] * 0.55 * scale)
        push_w = _lerp(0.0, 1.0, f / max(1, C)) if f <= C else \
            (_lerp(1.0, 0.0, (f - C) / max(1, F - C)) if f > C else 1.0)
        ra = reach(rig_a, pa, a["root"], "r", contact, scale, 1, push_w)
        pa["torso"] = _lerp(pa["torso"], 10.0, push_w)
        pa["hip_r"] = _lerp(pa.get("hip_r", 0), -14, push_w)
        pa["kn_r"] = _lerp(pa.get("kn_r", 0), -10, push_w)
        pa["sh_l"] = _lerp(pa.get("sh_l", 7), 26, push_w)
        hit_pose, _ = action_pose("hit", int(round(_lerp(0, 12, push_w))), rig_b)
        for k in ("torso", "head", "sh_l", "sh_r"):
            pb[k] = _lerp(pb.get(k, 0), hit_pose.get(k, 0), push_w)
        pb["bob"] = _lerp(pb.get("bob", 0), 6, push_w)
        a["overlay_arm"] = "r"     # the hand must sit on top of the chest it pushes
        return a, b, ra, None

    ra = reach(rig_a, pa, a["root"], "r", grip, scale, 1, w)
    rb = reach(rig_b, pb, b["root"], "r", grip, scale, -1, w)
    # off-hand follows the motion: swings out on the reach, settles on release
    pa["sh_l"] = _lerp(pa.get("sh_l", 7), 16, w)
    pb["sh_l"] = _lerp(pb.get("sh_l", 7), 16, w)

    # prop hand-off: parent switches on the contact frame, position follows the
    # hand that owns it, so the object never floats between them
    prop = None
    if props_a:
        prop = {"hand": "r", "kind": "letter"}
        prop.update(props_a[0])
        if action == "handoff" and f >= C:
            prop["hand"] = "r"
            prop["owner"] = "b"
            prop["at"] = hand_of(b, "r")
        elif action == "handoff":
            prop["owner"] = "a"
            prop["at"] = hand_of(a, "r")
    return a, b, ra, (prop, rb)


def duo_scene(rig_a, rig_b, action="handshake", scale=1.0, feet_y=1200,
              props_a=None, props_b=None, spacing=None):
    def build(i, t):
        a, b, ra, extra = duo_layout(rig_a, rig_b, action, i, scale, feet_y,
                                     spacing, props_a, props_b)
        a["z"], b["z"] = a["root"][1] - 1, b["root"][1]
        props = []
        if extra and extra[0]:
            p = extra[0]
            owner = b if p.get("owner") == "b" else a
            # ride the hand socket (not a frozen point) so the auto-plant
            # correction applies to the prop too
            props.append({"kind": p.get("kind", "letter"), "hand": p["hand"],
                          "at": None, "owner_id": owner["rig"]["id"]})
        for act in (a, b):
            act["props"] = [p for p in props if p["owner_id"] == act["rig"]["id"]]
        return ([a, b], "", [a["root"][0], b["root"][0]],
                [rig_a["torso_w"] * scale * 0.52] * 2, feet_y)

    return build


def default_scene(rig, pose_fn, scale=1.0, feet_y=1200, props=None):
    """One actor, centred, auto-planted on every frame."""
    def build(i, t):
        pose = dict(pose_fn(i, rig))
        bob = pose.pop("bob", 0.0)
        airborne = abs(bob) > 40          # fall/jump frames must not be planted
        root = (540, feet_y - (rig["leg_h"] + rig["torso_h"] + rig["head_h"]) * scale + bob)
        if not airborne:
            root = plant(rig, pose, root, scale, 1, feet_y)
        a = {"rig": rig, "pose": pose, "root": root, "scale": scale,
             "facing": 1, "z": root[1], "props": props}
        return [a], "", [540], [rig["torso_w"] * scale * 0.55], feet_y

    return build


def crowd_scene(rig, n=4, scale=1.0, feet_y=1200, seed=11, props=None):
    # a crowd of clones is still a clone: pass a list of story cast rigs when
    # you have them, and they cycle across the slots
    """N actors on a receding ground plane, phase-staggered so nobody marches.

    Depth is sold by three things at once: size, ground line and occlusion. Back
    rows are smaller and their feet sit higher in frame, the front row overlaps
    them, and every actor gets its own idle phase and blink offset so the crowd
    never breathes in unison.
    """
    import random
    rigs = list(rig) if isinstance(rig, (list, tuple)) else [rig]
    n = max(n, len(rigs))
    rng = random.Random(seed)
    order = list(range(n))
    rng.shuffle(order)
    slots = []
    for idx, k in enumerate(order):
        r = rigs[k % len(rigs)]
        d = 0.12 + 0.88 * (idx / max(1, n - 1))       # 0 = back, 1 = front
        sc = scale * (0.74 + 0.30 * d)
        fy = feet_y - (1.0 - d) * 165
        # far rows compress toward the vanishing point, near rows fill the frame
        u = (k + 0.5) / n
        base = W * (0.14 + 0.72 * u)
        x = W * 0.5 + (base - W * 0.5) * (0.72 + 0.28 * d) + rng.uniform(-20, 20)
        slots.append({"x": x, "scale": sc, "feet": fy, "rig": r,
                      "phase": rng.random(), "blink": rng.randrange(0, 75),
                      "facing": 1 if x < W * 0.5 else -1})
    slots.sort(key=lambda t: t["feet"])               # far rows first

    def build(i, t):
        actors = []
        for s in slots:
            r = s["rig"]
            pose = dict(idle_pose(t + s["phase"] * 2.4, r))
            root = (s["x"], s["feet"] - (r["leg_h"] + r["torso_h"] +
                                         r["head_h"]) * s["scale"])
            root = plant(r, pose, root, s["scale"], s["facing"], s["feet"])
            actors.append({"rig": r, "pose": pose, "root": root,
                           "scale": s["scale"], "facing": s["facing"],
                           "z": s["feet"], "blink_offset": s["blink"],
                           "props": props})
        return (actors, "",
                [a["root"][0] for a in actors],
                [a["rig"]["torso_w"] * a["scale"] * 0.55 for a in actors],
                [s["feet"] for s in slots])

    return build


# ------------------------------------------------------------------ camera
CAMERA_MOVES = ("none", "push_in", "truck", "crane", "handheld")


def camera_at(frame, frames, kind="none", amount=0.06):
    """Camera state at a frame: (zoom, dx, dy) in output pixels.

    Dollies run at constant velocity (no ease-in, per the motion contract); the
    last 15% eases out so the move settles instead of stopping dead. `dx`/`dy`
    are the subject's on-screen displacement, so a truck right gives dx < 0.
    """
    if kind in (None, "none") or frames <= 1:
        return 1.0, 0.0, 0.0
    u = min(1.0, max(0.0, frame / float(frames - 1)))
    v = u if u <= 0.85 else 0.85 + 0.15 * (1.0 - (1.0 - (u - 0.85) / 0.15) ** 2)
    if kind == "push_in":
        return 1.0 + amount * v, 0.0, 0.0
    if kind == "truck":
        return 1.0, (0.5 - v) * amount * W * 2.0, 0.0
    if kind == "crane":
        return 1.0, 0.0, (v - 0.5) * amount * H * 1.2
    if kind == "handheld":
        return 1.0, 1.6 * math.sin(TAU * u * 3.0), 1.2 * math.sin(TAU * u * 2.0 + 1.0)
    return 1.0, 0.0, 0.0


def camera_plate(img, z, dx, dy, pzoom=0.55, pshift=0.35):
    """Apply a camera move to a flat plate: zoom + shift, cropped to the frame.

    Backgrounds get a fraction of the actor zoom and shift (parallax), so the
    actor layer separates from the plate during a push-in or truck.
    """
    from PIL import Image
    bz = 1.0 + (z - 1.0) * pzoom
    if abs(bz - 1.0) < 1e-4 and abs(dx * pshift) < 0.5 and abs(dy * pshift) < 0.5:
        return img
    # a lateral move needs overscan, or there is nothing to crop into
    if (abs(dx * pshift) > 0.5 or abs(dy * pshift) > 0.5) and bz < 1.05:
        bz = 1.05
    w, h = img.size
    nw, nh = max(W, int(round(w * bz))), max(H, int(round(h * bz)))
    im = img.resize((nw, nh), Image.LANCZOS)
    cx = w * 0.5 + dx * pshift * bz
    cy = h * 0.5 + dy * pshift * bz
    left = max(0, min(int(round(cx - W * 0.5)), nw - W))
    top = max(0, min(int(round(cy - H * 0.5)), nh - H))
    return im.crop((left, top, left + W, top + H))


FG_TOP_MIN = 860           # the foreground may cross the caption band, never the faces


def foreground_sheet(bg=None, path=None, seed=7, height_px=300):
    """Build an RGBA foreground plane that passes in FRONT of the actors.

    Without a supplied PNG, derive it from the plate's own bottom band: the
    colour is sampled from the ground, the shapes are seeded sine stacks (grass
    tufts / rubble), and the layer is blurred because it is closest to the lens.
    Deterministic for a given plate + seed.
    """
    import numpy as np
    from PIL import Image, ImageFilter
    if path:
        return Image.open(path).convert("RGBA").resize((W, H))
    if bg is None:
        return None
    base = bg.convert("RGB")
    strip = np.asarray(base.crop((0, int(H * 0.74), W, H))).astype(np.float32)
    col = strip.mean(axis=0) * 0.50                     # per-x ground colour
    rng = np.random.default_rng(seed)
    xs = np.arange(W, dtype=np.float32) / W
    hgt = np.zeros(W, dtype=np.float32)
    # high frequencies make blade tufts; one low frequency only breaks the line
    for freq, amp in ((2.9, 0.10), (6.1, 0.15), (11.7, 0.17),
                      (23.3, 0.14), (41.0, 0.08)):
        ph = rng.random() * TAU
        hgt += amp * np.abs(np.sin(xs * math.pi * freq + ph))
    hgt += rng.random(W).astype(np.float32) * 0.20      # ragged tips
    hgt = hgt / max(1e-6, hgt.max()) * height_px
    hgt = np.clip(hgt, height_px * 0.42, H - FG_TOP_MIN)
    yy = np.arange(H, dtype=np.float32)[:, None]
    top = H - hgt[None, :]
    alpha = np.clip((yy - top) / 2.5, 0.0, 1.0) * 232.0
    shade = (0.86 + 0.14 * np.clip(hgt / float(height_px), 0.0, 1.0))[:, None]
    rgb = np.repeat(np.clip(col * shade, 0, 255)[None, :, :], H, axis=0)
    arr = np.dstack([rgb, alpha]).astype(np.uint8)
    fg = Image.fromarray(arr, "RGBA").filter(ImageFilter.GaussianBlur(3.6))
    return fg


def render_frames(frames, bg_path, out_dir, build_scene, caption_cards=None,
                  caption_cuts=None, camera="none", camera_amount=0.06,
                  fg_path=None, fg_on=True, fg_height=None):
    """Composite one frame at a time: plate -> shadows -> actors -> fg -> captions.

    The layer order is the depth order. Shadows sit on the plate; actors sit on
    the shadows; the foreground plane sits on the actors (grass in front of the
    boots is the strongest depth cue in the references); captions are last.
    """
    import cairosvg
    from PIL import Image, ImageDraw, ImageFilter
    os.makedirs(out_dir, exist_ok=True)
    bg = Image.open(bg_path).convert("RGB").resize((W, H)) if bg_path else \
        Image.new("RGB", (W, H), (58, 74, 96))
    cards = [Image.open(p).convert("RGBA") for p in (caption_cards or [])]
    fg = foreground_sheet(bg, fg_path) if fg_path else None
    fg_pending = fg is None and fg_on and bg_path is not None
    for i in range(frames):
        t = i / 30.0
        actors, extra, shadow_x, shadow_w, foot_y = build_scene(i, t)
        fy_list = list(foot_y) if isinstance(foot_y, (list, tuple)) \
            else [foot_y] * len(shadow_x)
        for a in actors:
            a["blink"] = ((i + a.get("blink_offset", 0)) % 75) in (37, 38)
        z, dx, dy = camera_at(i, frames, camera, camera_amount)
        anchor = float(fy_list[0]) if fy_list else 1200.0
        if fg_pending:
            # the plane is nearest the lens, so it reaches up to the boots —
            # but never into the caption band
            top = max(anchor - 45.0, FG_TOP_MIN)
            fg = foreground_sheet(bg, height_px=int(fg_height or (H - top)))
            fg_pending = False
        svg = scene_svg(actors, extra, (z, dx, dy, W * 0.5, anchor))
        png = cairosvg.svg2png(bytestring=svg.encode(), output_width=W, output_height=H)
        with tempfile.NamedTemporaryFile(suffix=".png", delete=False) as tf:
            tf.write(png)
            tmp = tf.name
        im = Image.open(tmp).convert("RGBA")
        os.unlink(tmp)

        # contact shadows live in the actor layer's camera space
        ax = W * 0.5
        sh = Image.new("RGBA", (W, H), (0, 0, 0, 0))
        sd = ImageDraw.Draw(sh)
        for sx, sw, fy in zip(shadow_x, shadow_w, fy_list):
            cx = ax + (sx - ax) * z + dx
            cy = anchor + (fy - anchor) * z + dy
            sd.ellipse([cx - sw * z, cy - 15 * z, cx + sw * z, cy + 15 * z],
                       fill=(0, 0, 0, 105))
        sh = sh.filter(ImageFilter.GaussianBlur(14 * max(1.0, z)))

        frame = camera_plate(bg, z, dx, dy).convert("RGBA")
        frame.alpha_composite(sh)
        frame.alpha_composite(im)
        if fg is not None:
            frame.alpha_composite(camera_plate(fg, z, dx, dy, 1.75, 1.45))
        if cards:
            # hard swaps only, at the timestamps the caption plan declares
            cuts = caption_cuts or [1.5 * (k + 1) for k in range(len(cards) - 1)]
            idx = sum(1 for c in cuts if t >= c)
            frame.alpha_composite(cards[min(idx, len(cards) - 1)])
        frame.convert("RGB").save(os.path.join(out_dir, f"{i:05d}.png"))


# ------------------------------------------------------------------ verify
def verify(loud=True):
    """Prove the hard claims: ground contact, reach, contact, prop transfer."""
    rows = []
    fails = 0

    def add(name, measured, target, ok):
        nonlocal fails
        fails += 0 if ok else 1
        rows.append((name, measured, target))

    rig = build_rig({"id": "v"})

    # 1. locomotion: lowest foot stays on the ground line, knees never invert
    lows, planted, bad_knee, xs = [], [], 0, []
    for f in range(24):
        pose = walk_pose(f / 24.0, rig)
        sk = solve_skeleton(rig, pose, root=(540, 1200), scale=0.62)
        lows.append(max(sk["foot_l"][1], sk["foot_r"][1]))
        xs.append(sk["foot_r"][0])
        r = plant(rig, pose, (540, 1200), 0.62, 1, 1281)
        sk2 = solve_skeleton(rig, pose, r, 0.62, 1)
        planted.append(max(sk2["foot_l"][1], sk2["foot_r"][1]))
        for k in ("kn_l", "kn_r"):
            if pose[k] > 2 or pose[k] < -90:   # knees must not hyperextend
                bad_knee += 1
        for k in ("el_l", "el_r"):
            if pose[k] > 30 or pose[k] < -100:  # elbows may lead slightly
                bad_knee += 1
    stride = max(xs) - min(xs)
    spread = max(planted) - min(planted)
    add("walk stride", f"{stride:.1f}px", "15-70px", 15 <= stride <= 70)
    add("walk ground spread after plant", f"{spread:.1f}px", "<= 0.5px",
        spread <= 0.5)
    add("joint limits", f"{bad_knee} bad", "0", bad_knee == 0)

    # 2. duo contact: exact grip on and after the contact frame, sane reach
    ra = build_rig({"id": "a", "hex": {"garment": "#C8282C"}})
    rb = build_rig({"id": "b", "silhouette_cue": "top hat",
                    "hex": {"garment": "#F2EFE6"}})
    for action, spec in DUO_ACTIONS.items():
        worst_res, worst_reach = 0.0, 0.0
        for f in range(spec["contact"], spec["release"] + 1):
            a, b, reach_ratio, _ = duo_layout(ra, rb, action, f, 0.62, 1560)
            res = contact_residual(a, b) if action != "push" else 0.0
            worst_res = max(worst_res, res)
            worst_reach = max(worst_reach, reach_ratio)
        add(f"{action} grip residual", f"{worst_res:.2f}px", "<= 0.5px",
            worst_res <= 0.5)
        add(f"{action} reach ratio", f"{worst_reach:.2f}", "<= 0.92",
            worst_reach <= 0.92)

    # 3. prop transfer: the letter is always exactly on an owner's hand
    worst_prop = 0.0
    owners = set()
    for f in range(DUO_ACTIONS["handoff"]["frames"] + 1):
        a, b, _, extra = duo_layout(ra, rb, "handoff", f, 0.62, 1560,
                                    props_a=[{"kind": "letter"}])
        prop = extra[0]
        owners.add(prop["owner"])
        owner = a if prop["owner"] == "a" else b
        hand = hand_of(owner, prop["hand"])
        worst_prop = max(worst_prop, math.hypot(prop["at"][0] - hand[0],
                                                prop["at"][1] - hand[1]))
    add("prop/hand distance", f"{worst_prop:.2f}px", "<= 0.5px", worst_prop <= 0.5)
    add("prop ownership", "/".join(sorted(owners)), "a and b",
        owners == {"a", "b"})

    # 3b. every declared prop kind must draw real, stroked SVG
    bad_props = []
    for kind in PROP_KINDS:
        svg = prop_svg(kind, (0, 0), 0, 1.0, 2.0)
        if "<" not in svg or "</g>" not in svg or "stroke" not in svg:
            bad_props.append(kind)
    add("prop_svg kinds", f"{len(PROP_KINDS) - len(bad_props)}/{len(PROP_KINDS)}",
        "all draw", not bad_props)

    # 4. camera: a push-in is monotonic and lands on its declared endpoints
    zs = [camera_at(i, 90, "push_in", 0.06)[0] for i in range(90)]
    mono = all(b >= a - 1e-9 for a, b in zip(zs, zs[1:]))
    add("camera push-in monotonic", "yes" if mono else "no", "monotonic", mono)
    add("camera zoom range", f"{zs[0]:.3f} -> {zs[-1]:.3f}", "1.000 -> 1.060",
        abs(zs[0] - 1.0) < 1e-6 and abs(zs[-1] - 1.06) < 1e-3)
    tdx = [camera_at(i, 90, "truck", 0.06)[1] for i in range(90)]
    add("camera truck travel", f"{tdx[0]:.0f} -> {tdx[-1]:.0f}px", "symmetric",
        abs(tdx[0] + tdx[-1]) < 1.0 and abs(tdx[0]) > 20)

    # 5. foreground: covers enough to occlude, never enters the caption band
    from PIL import Image as _Img
    import numpy as _np
    fg = foreground_sheet(_Img.new("RGB", (W, H), (62, 70, 54)), height_px=470)
    a = _np.asarray(fg)[:, :, 3]
    cov = float((a > 8).mean())
    ys = _np.nonzero((a > 8).any(axis=1))[0]
    top = int(ys.min()) if len(ys) else H
    add("foreground coverage", f"{cov * 100:.1f}%", "8-45%", 0.08 <= cov <= 0.45)
    add("foreground below faces", f"y{top}", ">= 860", top >= 860)

    # 6. crowd: N actors staggered in x, depth and idle phase
    cbuild = crowd_scene(rig, n=5, scale=0.62, feet_y=1200)
    acts, _, cx, cw, cy = cbuild(0, 0.0)
    xs = sorted(a0["root"][0] for a0 in acts)
    span = xs[-1] - xs[0]
    depth_rows = len({round(f) for f in cy})
    phases = {round(a0["pose"].get("bob", 0.0), 3) for a0 in acts}
    add("crowd actors / x span", f"{len(acts)} / {span:.0f}px", "5 / >= 420px",
        len(acts) == 5 and span >= 420)
    add("crowd depth rows", f"{depth_rows} rows", ">= 3", depth_rows >= 3)
    add("crowd phase stagger", f"{len(phases)} states", ">= 2", len(phases) >= 2)

    # 7. every action samples cleanly with a contact inside its span
    for name, spec in ACTION_TABLE.items():
        assert 0 < spec["contact"] < spec["frames"], name
        for f in range(spec["frames"] + 1):
            action_pose(name, f, rig)
    add(f"actions sampled ({len(ACTION_TABLE)})", "all frames", "no error", True)

    if loud:
        print(f"{'check':<28}{'measured':>14}  target")
        for k, v, t in rows:
            print(f"{k:<28}{v:>14}  {t}")
        print(f"prop_svg kinds: {'PASS' if not bad_props else 'FAIL'} "
              f"({len(PROP_KINDS)})")
        print(f"\n{'FAIL' if fails else 'PASS'} - {fails} failing")
    return fails


# ------------------------------------------------------------------ cli
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--demo", default=None)
    ap.add_argument("--bg", default=None)
    ap.add_argument("--cards", nargs="*", default=None)
    ap.add_argument("--frames", type=int, default=None)
    ap.add_argument("--card", default=None, help="JSON character card")
    ap.add_argument("--card-b", default=None)
    ap.add_argument("--scale", type=float, default=1.0)
    ap.add_argument("--feet-y", type=int, default=1200,
                    help="ground contact line measured off the plate")
    ap.add_argument("--height-px", type=int, default=None,
                    help="character height: 330 wide / 700 medium / 1400 close")
    ap.add_argument("--action", default=None, choices=sorted(ACTION_TABLE))
    ap.add_argument("--prop", default=None,
                    choices=["pan", "hammer", "pickaxe", "fuse", "letter", "note",
                             "flag", "lantern"],
                    help="prop carried in the right hand")
    ap.add_argument("--duo", default=None, choices=sorted(DUO_ACTIONS))
    ap.add_argument("--crowd", type=int, default=0,
                    help="N actors on a receding ground plane (4-6 reads as a crowd)")
    ap.add_argument("--cast", nargs="*", default=None,
                    help="JSON character cards for the crowd (cycles if fewer than N)")
    ap.add_argument("--body", default="capsule", choices=sorted(BODY_SPECS),
                    help="body archetype: silhouette, not just a hat")
    ap.add_argument("--beard", action="store_true")
    ap.add_argument("--camera", default="none", choices=CAMERA_MOVES)
    ap.add_argument("--camera-amount", type=float, default=0.06)
    ap.add_argument("--fg", default=None, help="foreground PNG with alpha")
    ap.add_argument("--no-fg", action="store_true")
    ap.add_argument("--fg-height", type=int, default=None,
                    help="override derived foreground height in px")
    ap.add_argument("--verify", action="store_true")
    ap.add_argument("--list-props", action="store_true")
    args = ap.parse_args()

    if args.list_props:
        print(json.dumps({"prop_kinds": list(PROP_KINDS), "count": len(PROP_KINDS)}))
        return 0

    if args.verify:
        return 1 if verify() else 0

    card = {"id": "prospector", "height_px": 330, "silhouette_cue": "campaign hat",
            "hex": {"garment": "#C8282C", "accent": "#E0B020",
                    "hat": "#7A5A2E"}, "hair_kind": "short"}
    if args.card:
        card = json.load(open(args.card))
    card.setdefault("body", args.body)
    if args.beard:
        card["beard"] = True
    if args.height_px:
        card["height_px"] = args.height_px
    rig = build_rig(card)

    if not args.demo:
        print(scene_svg([{"rig": rig, "pose": idle_pose(0, rig), "root": (540, 1200),
                          "scale": 0.6}])[:400])
        return 0

    tmpdir = tempfile.mkdtemp(prefix="puppet_")
    if args.crowd:
        frames = args.frames or 90
        props = [{"kind": args.prop}] if args.prop else None
        if args.cast:
            crowd_rigs = [build_rig(json.load(open(f))) for f in args.cast]
        elif args.card:
            crowd_rigs = [rig]
        else:
            # demo cast: six different silhouettes, never six clones in hats
            demo = [("dress", "#2E8C8A", None, False),
                    ("coat", "#3A4E8C", "top hat", False),
                    ("armour", "#6B6B74", "helmet", False),
                    ("elder", "#7A5A2E", None, True),
                    ("child", "#E0B020", "cap", False),
                    ("capsule", "#8C3A5E", "bowler", False)]
            crowd_rigs = []
            for k in range(args.crowd):
                body, col, hat, beard = demo[k % len(demo)]
                h = card.get("height_px", 330)
                crowd_rigs.append(build_rig({
                    "id": f"crowd{k}",
                    "height_px": int(h * (0.76 if body == "child" else 1.0)),
                    "body": body, "silhouette_cue": hat or "", "beard": beard,
                    "hair_kind": "bald" if body == "elder" else "short",
                    "hex": {"garment": col, "accent": "#E0B020", "hat": "#141414"},
                }))
        build = crowd_scene(crowd_rigs, n=args.crowd, scale=args.scale,
                            feet_y=args.feet_y, props=props)
    elif args.duo:
        card_b = json.load(open(args.card_b)) if args.card_b else \
            {"id": "investor", "silhouette_cue": "top hat", "hair_kind": "short",
             "hex": {"garment": "#F2EFE6", "accent": "#1A1A1A",
                     "hat": "#141414"}}
        # the second actor is the same species: inherit the first one's height
        card_b.setdefault("height_px", card.get("height_px", 330))
        rig_b = build_rig(card_b)
        frames = args.frames or (DUO_ACTIONS[args.duo]["frames"] + 30) * 2
        props_a = [{"kind": "letter"}] if args.duo == "handoff" else None
        build = duo_scene(rig, rig_b, args.duo, scale=args.scale,
                          feet_y=args.feet_y, props_a=props_a)
    else:
        pose_fn = action_demo(args.action) if args.action else demo_pose
        frames = args.frames or ((ACTION_TABLE[args.action]["frames"] + 30) * 2
                                 if args.action else 90)
        props = [{"kind": args.prop}] if args.prop else None
        build = default_scene(rig, pose_fn, scale=args.scale, feet_y=args.feet_y,
                              props=props)

    render_frames(frames, args.bg, tmpdir, build, caption_cards=args.cards,
                  camera=args.camera, camera_amount=args.camera_amount,
                  fg_path=args.fg, fg_on=not args.no_fg,
                  fg_height=args.fg_height)
    ff = os.environ.get("FFMPEG") or "ffmpeg"
    os.makedirs(os.path.dirname(args.demo) or ".", exist_ok=True)
    subprocess.run([ff, "-y", "-v", "error", "-framerate", "30",
                    "-i", os.path.join(tmpdir, "%05d.png"),
                    "-c:v", "libx264", "-preset", "medium", "-crf", "19",
                    "-pix_fmt", "yuv420p", "-r", "30", "-s", f"{W}x{H}", args.demo],
                   check=True)
    print(f"wrote {args.demo} ({frames} frames)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
