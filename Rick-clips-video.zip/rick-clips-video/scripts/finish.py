#!/usr/bin/env python3
"""finish.py — one-pass final encode: concat + grade + grain + captions + mix.

The legacy stage 8 encodes the film three times (base_silent, then the mux is
copy-only, then the caption burn re-encodes). This folds all of it into ONE
1080x1920 encode. The caption cards are the exact same PNGs produced by
`caption_cards.py`, so the text is unchanged; only the number of times the
picture is decoded/encoded changes.

    python3 scripts/finish.py --concat build/concat.txt --voice voice.mp3 \\
            --captions build/captions.json --out out/final.mp4

It probes for a working hardware encoder (NVENC/QSV/AMF/VideoToolbox) and
falls back to libx264 veryfast; `--profile safe` keeps the old slow preset.
If the single pass fails for any reason it exits non-zero with the legacy
command printed — it never silently ships a partial file.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

from caption_cards import prepare_cards, caption_pipeline, BAND_Y  # noqa: E402
from fastencode import choose as choose_encoder, describe as describe_encoder, require as require_ffmpeg  # noqa: E402

GRADE = ("curves=all='0/0.022 0.35/0.36 1/1',"
         "colorbalance=rh=0.045:gh=0.012:bh=-0.038:rs=0.0:gs=0.0:bs=0.022,"
         "noise=alls=5:allf=t+u,format=yuv420p")
AUDIO = "volume=10.6dB,alimiter=limit=0.851:attack=3:release=60:level=0,aresample=48000"


def bound_duration(concat, audio_path, shotlist):
    """Return (frames, seconds). Frames are exact when the shotlist exists —
    `-frames:v` never drops the last frame the way a rounded `-t` can."""
    if os.path.exists(shotlist):
        try:
            s = json.load(open(shotlist, encoding="utf-8"))
            frames = max(int(x["frames"][1]) for x in s)
            return frames, round(frames / 30.0, 3)
        except Exception:
            pass
    try:
        out = subprocess.run(["ffprobe", "-v", "error", "-show_entries",
                              "format=duration", "-of", "csv=p=0", audio_path],
                             capture_output=True, text=True, check=True).stdout.strip()
        return None, round(float(out), 3)
    except Exception:
        return None, None


def main(argv=None):
    ap = argparse.ArgumentParser(description="one-pass grade+grain+captions+mux")
    ap.add_argument("--concat", default="build/concat.txt")
    ap.add_argument("--voice", default="voice.mp3")
    ap.add_argument("--captions", default="build/captions.json")
    ap.add_argument("--audio", default="build/audio.json")
    ap.add_argument("--shotlist", default="build/shotlist.json")
    ap.add_argument("--out", default="out/final.mp4")
    ap.add_argument("--profile", default="auto")
    ap.add_argument("--sfx", default="build/sfx.wav",
                    help="optional deterministic SFX bed; ducked under the voice")
    ap.add_argument("--no-grade", action="store_true",
                    help="skip curves/colorbalance/grain (debug only)")
    ap.add_argument("--dry-run", action="store_true", help="print the ffmpeg command")
    args = ap.parse_args(argv)

    for p in (args.concat, args.voice, args.captions):
        if not os.path.exists(p):
            raise SystemExit("missing input: %s" % p)

    files = prepare_cards(args.captions)
    cap_inputs, cap_filter = caption_pipeline(files, base_label="base",
                                              out_label="vout", first_input=2)
    require_ffmpeg()
    cfg = choose_encoder(args.profile)
    frames, dur = bound_duration(args.concat, args.voice, args.shotlist)

    fc = []
    fc.append(("[0:v]" + ("null,format=yuv420p" if args.no_grade else GRADE) + "[base]"))
    fc.append(cap_filter)
    sfx_idx = 2 + len(files)
    if os.path.exists(args.sfx):
        fc.append("[1:a]" + AUDIO + "[vo]")
        fc.append("[%d:a]volume=0.9,aresample=48000[sfx]" % sfx_idx)
        fc.append("[vo][sfx]sidechaincompress=threshold=0.02:ratio=4:"
                  "attack=20:release=180,"
                  "volume=1.0dB,alimiter=limit=0.851:level=0[a]")
    else:
        fc.append("[1:a]" + AUDIO + "[a]")

    cmd = ["ffmpeg", "-y", "-f", "concat", "-safe", "0", "-i", args.concat,
           "-i", args.voice] + cap_inputs + (
          ["-i", args.sfx] if os.path.exists(args.sfx) else []) + [
        "-filter_complex", ";".join(fc),
        "-map", "[vout]", "-map", "[a]",
    ] + cfg["args"] + ["-c:a", "aac", "-b:a", "192k"]
    if frames:
        cmd += ["-frames:v", str(frames)]
    elif dur:
        cmd += ["-t", "%.3f" % (dur + 0.05)]
    cmd += ["-movflags", "+faststart", args.out]

    print("encoder:", describe_encoder(cfg), "| cards:", len(files),
          "| duration:", dur or "from audio")
    if args.dry_run:
        print(" ".join(cmd))
        return 0

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    p = subprocess.run(cmd)
    if p.returncode:
        print("one-pass encode failed; run the legacy three-pass stage 8 instead",
              file=sys.stderr)
        return p.returncode
    print("wrote", args.out, "in one pass")
    return 0


if __name__ == "__main__":
    sys.exit(main())
