#!/usr/bin/env python3
"""Turn caption groups into a frame-exact shot skeleton, then check it.

Mapping 30 caption cards onto 1.5-3.0 s shots whose frames sum exactly to the
voice duration is arithmetic. Doing it by hand is where a first run burns tokens
and lands 8 frames long. This tool does the arithmetic; you fill the story
fields; `--check` refuses to pass until they are filled.

Build (stage 3):
  python3 scripts/shotlist.py build/captions.json --audio build/audio.json

Fill the story fields in one table, then validate:
  python3 scripts/shotlist.py build/captions.json --audio build/audio.json
  python3 scripts/shotlist.py build/captions.json --fill beats.tsv
  python3 scripts/shotlist.py build/captions.json --check

`beats.tsv`, one row per shot, tab-separated:
  id  beat  scene  characters  action  camera
  s01 hook: the mine is empty  mine_tunnel_night  protagonist  stands, lifts the lantern  slow push-in

Regenerate after re-timing the voice (destroys authored fields):
  python3 scripts/shotlist.py build/captions.json --audio build/audio.json --force

Outputs
  build/shotlist.json   one row per shot: id, start, end, frames, caption,
                        captions, beat, scene, env, characters, action, camera,
                        depth, fx, transition_out
  analysis/SHOTLIST.md  the same table, readable

Exit codes: 0 pass, 1 check failed, 2 cannot build (bad input)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

FPS = 30
TARGET = 2.2      # s per shot, mean (hard rule 11: 1.5-3.0 s)
LO, HI = 1.5, 3.0
CREATIVE = ("beat", "scene", "characters", "action", "camera", "framing")
# Shot sizes, coarse to tight. A film that uses one of these thirteen times is a
# slideshow with narration: variety is checked, not hoped for.
FRAMINGS = ("wide", "medium", "close", "insert", "ots", "low", "high")


def load_cards(path):
    cards = json.load(open(path, encoding="utf-8-sig"))
    if not isinstance(cards, list) or not cards:
        raise SystemExit("captions file must be a non-empty list")
    for c in cards:
        if not all(k in c for k in ("text", "start", "end")):
            raise SystemExit("caption missing text/start/end: %r" % (c,))
        if float(c["end"]) <= float(c["start"]):
            raise SystemExit("caption ends before it starts: %r" % (c,))
    return sorted(cards, key=lambda c: float(c["start"]))


def duration_of(args, cards):
    if args.duration:
        return float(args.duration)
    if args.audio and os.path.exists(args.audio):
        d = json.load(open(args.audio))
        if "duration" in d:
            return float(d["duration"])
    return float(cards[-1]["end"]) + 0.30


def boundaries(cards, total):
    """Shot boundaries: mid-point of each silent gap, so silence is shared
    instead of all of it landing inside one shot. The video starts at frame 0,
    so the first shot does too, even when the first word lands later."""
    b = [0.0]
    for a, nxt in zip(cards, cards[1:]):
        gap_end = min(float(nxt["start"]), total)
        b.append((float(a["end"]) + gap_end) / 2.0)
    b.append(total)
    return b


def group(cards, b):
    """Greedy: add a caption while the shot stays inside HI, stop at TARGET."""
    n, i, out = len(cards), 0, []
    while i < n:
        j = i
        while j + 1 < n and b[j + 2] - b[i] <= HI:
            j += 1
            if b[j + 1] - b[i] >= TARGET:
                break
        out.append((i, j))
        i = j + 1
    return out


def build(cards, total, fps):
    if total <= 0:
        raise SystemExit("audio has no duration")
    total_frames = int(round(total * fps))
    over = [c for c in cards if float(c["end"]) > total + 0.01]
    b = boundaries(cards, total)
    b[-1] = total
    groups = group(cards, b)
    shots, prev = [], 0
    for k, (i, j) in enumerate(groups):
        f0 = prev
        if k == len(groups) - 1:
            f1 = min(total_frames, int(round((float(cards[-1]["end"]) + 0.60) * fps)))
        else:
            f1 = int(round(b[j + 1] * fps))
        f1 = max(f1, f0 + 1)
        if f1 > total_frames:
            f1 = total_frames
        prev = f1
        rows = cards[i:j + 1]
        words = [w for c in rows for w in str(c["text"]).split()]
        shots.append({
            "id": "s%02d" % (k + 1),
            "start": round(f0 / float(fps), 3),
            "end": round(f1 / float(fps), 3),
            "frames": [f0, f1],
            "caption": words,
            "captions": [{"text": c["text"], "start": c["start"], "end": c["end"]}
                         for c in rows],
            "beat": "",
            "scene": "",
            "env": "",
            "characters": [],
            "action": "",
            "camera": "",
            "framing": "",
            "objects": [],
            "props": [],
            "depth": "",
            "fx": [],
            "asset_prompt": "",
            "transition_out": "hard_cut",
        })

    # trailing silence: never a 7 s static last shot. Hold the last caption for
    # at most 0.6 s, then cover the rest with end-card shots inside the limit.
    left = total_frames - prev
    cap = int(HI * fps)
    n_tail = 0
    while left > 0:
        n = min(left, cap)
        f0, f1 = prev, prev + n
        shots.append({
            "id": "s%02d" % (len(shots) + 1),
            "start": round(f0 / float(fps), 3),
            "end": round(f1 / float(fps), 3),
            "frames": [f0, f1],
            "caption": [],
            "captions": [],
            "tail": True,
            "beat": "",
            "scene": "",
            "env": "",
            "characters": [],
            "action": "",
            "camera": "",
            "framing": "",
            "objects": [],
            "props": [],
            "depth": "",
            "fx": [],
            "asset_prompt": "",
            "transition_out": "hard_cut",
        })
        prev = f1
        left = total_frames - prev
        n_tail += 1
    return shots, total_frames, over


def write_md(shots, fps, path):
    lines = ["# Shotlist", "",
             "%d shots · %.2f s · %d frames @ %d fps" %
             (len(shots), sum(s["end"] - s["start"] for s in shots),
              shots[-1]["frames"][1], fps), "",
             "| id | in | out | frames | caption | beat | scene | camera |",
             "|---|---|---|---|---|---|---|---|"]
    for s in shots:
        lines.append("| %s | %.2f | %.2f | %d | %s | %s | %s | %s |" % (
            s["id"], s["start"], s["end"], s["frames"][1] - s["frames"][0],
            " ".join(s["caption"])[:48], s["beat"] or "—", s["scene"] or "—",
            s["camera"] or "—"))
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")


def apply_fill(path, tsv, md, fps):
    """Fill the creative fields from a six-column table, one row per shot:
    id <tab> beat <tab> scene <tab> characters <tab> action <tab> camera.
    One file beats thirty JSON edits, and the check still validates the result."""
    shots = json.load(open(path, encoding="utf-8-sig"))
    by_id = {s["id"]: s for s in shots}
    n = 0
    for line in open(tsv, encoding="utf-8-sig"):
        line = line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        parts = [p.strip() for p in line.split("\t")]
        if len(parts) < 6:
            parts = [p.strip() for p in re.split(r"\s{2,}", line)]
        if len(parts) < 6:
            raise SystemExit("row needs 6 tab-separated fields: %r" % line)
        parts = parts + [""] * (8 - len(parts))
        sid, beat, scene, chars, action, camera = parts[:6]
        framing, objs = parts[6], parts[7]
        if sid.lower() == "id":            # header row
            continue
        s = by_id.get(sid)
        if not s:
            raise SystemExit("no shot %r in %s" % (sid, path))
        s["beat"], s["scene"] = beat, scene
        s["characters"] = [c.strip() for c in re.split(r"[,;]", chars) if c.strip()]
        s["action"], s["camera"] = action, camera
        s["framing"] = framing
        s["objects"] = [o.strip() for o in re.split(r"[,;]", objs) if o.strip()]
        n += 1
    json.dump(shots, open(path, "w", encoding="utf-8"), indent=1)
    write_md(shots, fps, md)
    print("filled %d/%d shots from %s" % (n, len(shots), tsv))


def check(path, cards, total, fps):
    shots = json.load(open(path, encoding="utf-8-sig"))
    total_frames = int(round(total * fps))
    bad, warn = [], []

    if not shots:
        return ["shotlist is empty"], warn

    frames = 0
    prev = 0
    for s in shots:
        f0, f1 = s["frames"]
        frames += f1 - f0
        if f0 != prev:
            bad.append("%s: frames start at %d, previous shot ended at %d" % (s["id"], f0, prev))
        if f1 <= f0:
            bad.append("%s: zero-length shot" % s["id"])
        prev = f1
        dur = (f1 - f0) / float(fps)
        if abs(float(s.get("start", -1)) - f0 / float(fps)) > 0.01:
            bad.append("%s: start %.2f does not match frame %d" % (s["id"], s.get("start", -1), f0))
        if abs(float(s.get("end", -1)) - f1 / float(fps)) > 0.01:
            bad.append("%s: end %.2f does not match frame %d" % (s["id"], s.get("end", -1), f1))
        if dur > HI + 0.10:
            bad.append("%s: %.2f s is over the %.1f s limit" % (s["id"], dur, HI))
        if dur < LO - 0.10:
            warn.append("%s: %.2f s is under %.1f s (fast captions)" % (s["id"], dur, LO))
        for k in CREATIVE:
            v = s.get(k)
            if not v:
                bad.append("%s: %s is empty" % (s["id"], k))
        if s.get("transition_out") not in (None, "", "hard_cut"):
            bad.append("%s: transition_out must be hard_cut" % s["id"])
        if not s.get("tail") and not s.get("caption"):
            bad.append("%s: no caption words" % s["id"])

    if abs(frames - total_frames) > 1:
        bad.append("frames sum to %d, voice duration is %d (%.2f s @ %d fps)" %
                   (frames, total_frames, total, fps))
    if prev > total_frames + 1:
        bad.append("last shot ends at frame %d, past the voice at %d" % (prev, total_frames))

    want = sum(len(str(c["text"]).split()) for c in cards)
    got = sum(len(s.get("caption", [])) for s in shots)
    if want != got:
        bad.append("caption words: %d in the shotlist, %d in captions.json" % (got, want))

    ids = [s["id"] for s in shots]
    if len(set(ids)) != len(ids):
        bad.append("duplicate shot ids")

    variety(shots, total, bad, warn)
    return bad, warn


def variety(shots, total, bad, warn):
    """A film needs places and shot sizes, not one place and one size.

    The rule that catches the failure this check was written for: thirteen shots
    of the same actor, in the same aisle, at the same height. Nothing in the
    per-shot checks notices that; the film still looks like a slideshow.
    """
    scenes = [str(s.get("scene") or "") for s in shots]
    framings = [str(s.get("framing") or "") for s in shots]

    bad_f = sorted({f for f in framings if f not in FRAMINGS})
    if bad_f:
        bad.append("unknown framing %s (allowed: %s)" % (bad_f, ", ".join(FRAMINGS)))

    need_scenes = max(3, int(round(total / 9.0)))
    if len(set(scenes)) < need_scenes:
        bad.append("only %d location(s) in %.0f s — needs %d (a new place every ~9 s)"
                   % (len(set(scenes)), total, need_scenes))

    need_framings = min(4, len(shots))
    if len(set(framings)) < need_framings:
        bad.append("only %d shot size(s) — needs %d of %s"
                   % (len(set(framings)), need_framings, "/".join(FRAMINGS[:4])))

    inserts = sum(1 for f in framings if f == "insert")
    need_inserts = max(1, int(total / 20.0))
    if inserts < need_inserts:
        bad.append("%d insert(s) — a film over 15 s needs %d (the object, the hand, the detail)"
                   % (inserts, need_inserts))

    run = 1
    for i in range(1, len(shots)):
        same = (scenes[i], framings[i]) == (scenes[i - 1], framings[i - 1])
        run = run + 1 if same else 1
        if run >= 3:
            bad.append("%s: %d shots in a row in the same place at the same size"
                       % (shots[i]["id"], run))
    if len(set(scenes)) < len(shots) and scenes.count(max(set(scenes), key=scenes.count)) > len(shots) * 0.6:
        warn.append("one location holds %d of %d shots — a cutaway or an insert would break it up"
                    % (max(scenes.count(v) for v in set(scenes)), len(shots)))


STOPWORDS = set("""
a an the and or but if then than that this these those it its it's is are was were be been
being am do does did done have has had will would can could should may might must not no
nor so as at by for from in into of off on onto out over to up with without within about
above after again against all any because before below between both during each few more
most other same some such only own very just too also there here when where while who whom
why how what which i you he she we they me him her us them my your his their our
never ever still yet even than
""".split())


def check_objects(shots, words_path, objects_path, bad, warn):
    """Every thing the script names must be visible when it is named.

    `objects.json` declares the physical things the narration refers to. The check
    is bidirectional: a declared object that never appears is a defect, and a word
    spoken while its object is off screen is the same defect seen from the audio.
    """
    if not os.path.exists(objects_path):
        warn.append("no %s — the script's objects are not contracted to the film" % objects_path)
        return
    try:
        spec = json.load(open(objects_path, encoding="utf-8-sig"))
    except Exception as exc:
        bad.append("objects.json is not valid JSON: %s" % exc)
        return
    objs = spec.get("objects") or []
    if not objs:
        warn.append("objects.json declares no objects")
        return

    on_screen = {}
    for s in shots:
        for oid in (s.get("objects") or []):
            on_screen.setdefault(oid, []).append(s)

    for o in objs:
        oid = o.get("id")
        if not oid:
            bad.append("objects.json entry without an id")
            continue
        if oid not in on_screen:
            bad.append("object %r is declared but never appears in the film" % oid)

    words = []
    if os.path.exists(words_path):
        words = json.load(open(words_path, encoding="utf-8-sig"))
    else:
        warn.append("no %s — object timing not checked" % words_path)

    declared = {}
    for o in objs:
        for w in o.get("words", [o.get("id")]):
            declared.setdefault(w.lower(), []).append(o["id"])

    for w in words:
        tok = re.sub(r"[^a-z']", "", str(w.get("w", "")).lower())
        if tok in declared:
            t0, t1 = float(w["start"]), float(w["end"])
            hit = [s for oid in declared[tok] for s in on_screen.get(oid, [])
                   if s["start"] <= t0 + 1.0 and s["end"] >= t1 - 1.0]
            if not hit:
                bad.append("%r is spoken at %.2f s while %s is not on screen"
                           % (w.get("w"), t0, "/".join(declared[tok])))
        elif tok and tok not in STOPWORDS and tok not in (spec.get("abstract") or []) \
                and tok not in ("", "s"):
            warn.append("unclassified word %r — decide: an object (add it to objects.json) "
                        "or abstract (add it to abstract)" % w.get("w"))


def apply_objects(path, objects_path):
    """Copy each declared object onto the shots that show it, by id list in the file."""
    spec = json.load(open(objects_path, encoding="utf-8-sig"))
    shots = json.load(open(path, encoding="utf-8-sig"))
    by_id = {s["id"]: s for s in shots}
    for o in spec.get("objects") or []:
        for sid in o.get("appears", []):
            s = by_id.get(sid)
            if not s:
                raise SystemExit("objects.json: %r lists a shot %r that does not exist" % (o["id"], sid))
            if o["id"] not in s.setdefault("objects", []):
                s["objects"].append(o["id"])
    # Persist: --check reads the file again for its own report and for the gate.
    json.dump(shots, open(path, "w", encoding="utf-8"), indent=1)


def main(argv=None):
    ap = argparse.ArgumentParser(description="captions -> frame-exact shot skeleton")
    ap.add_argument("captions", nargs="?", default="build/captions.json")
    ap.add_argument("--audio", default="build/audio.json", help="vo_timing run record (duration)")
    ap.add_argument("--duration", type=float, help="override the duration in seconds")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--out", default="build/shotlist.json")
    ap.add_argument("--md", default="analysis/SHOTLIST.md")
    ap.add_argument("--check", action="store_true", help="validate an existing shotlist")
    ap.add_argument("--fill", help="TSV: id, beat, scene, characters, action, camera[, framing, objects]")
    ap.add_argument("--force", action="store_true", help="overwrite authored fields")
    ap.add_argument("--objects", default="build/objects.json",
                    help="the script's physical objects and which shots show them")
    ap.add_argument("--words", default="build/words.json", help="word timings for the object check")
    args = ap.parse_args(argv)

    cards = load_cards(args.captions)
    total = duration_of(args, cards)

    if args.check:
        if not os.path.exists(args.out):
            print("no %s — build it first" % args.out)
            return 2
        if args.objects and os.path.exists(args.objects):
            apply_objects(args.out, args.objects)
        bad, warn = check(args.out, cards, total, args.fps)
        check_objects(json.load(open(args.out)), args.words, args.objects, bad, warn)
        for w in warn:
            print("warn:", w)
        for b in bad:
            print("FAIL:", b)
        shots = json.load(open(args.out))
        frames = sum(s["frames"][1] - s["frames"][0] for s in shots)
        print("\n%d shots · %d frames (voice %d) · %.2f s" %
              (len(shots), frames, int(round(total * args.fps)), total))
        print("PASS" if not bad else "%d failing" % len(bad))
        return 0 if not bad else 1

    if not os.path.exists(args.out) or args.force:
        shots, total_frames, over = build(cards, total, args.fps)
        os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
        json.dump(shots, open(args.out, "w", encoding="utf-8"), indent=1)
        write_md(shots, args.fps, args.md)
        if over:
            print("warn: %d caption(s) end past the audio (%.2f s); clamped to the last frame" %
                  (len(over), total))
        print("%d shots · %d frames · %.2f s @ %d fps" %
              (len(shots), total_frames, total, args.fps))
        print("%-4s %7s %7s %6s  %s" % ("id", "in", "out", "sec", "caption"))
        for s in shots:
            print("%-4s %7.2f %7.2f %6.2f  %s" %
                  (s["id"], s["start"], s["end"], s["end"] - s["start"],
                   " ".join(s["caption"])[:44]))
        print("\nwrote %s and %s" % (args.out, args.md))
        if not args.fill:
            print("next: fill beat, scene, characters, action, camera — then --check")
            return 0
    if os.path.exists(args.out) and args.fill:
        apply_fill(args.out, args.fill, args.md, args.fps)
        return 0
    if os.path.exists(args.out):
        cur = json.load(open(args.out))
        filled = [s["id"] for s in cur if s.get("beat")]
        print("%s already exists (%d shots, %d with a beat).\n"
              "  --check   validate it\n"
              "  --fill    add story fields from a table\n"
              "  --force   regenerate timings (discards authored fields)" %
              (args.out, len(cur), len(filled)))
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
