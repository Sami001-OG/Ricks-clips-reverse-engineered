#!/usr/bin/env python3
"""Turn caption groups into a frame-exact shot skeleton, then check it.

Mapping 30 caption cards onto 1.5-3.0 s shots whose frames sum exactly to the
voice duration is arithmetic. Doing it by hand is where a first run burns tokens
and lands 8 frames long. This tool does the arithmetic; you fill the story
fields; `--check` refuses to pass until they are filled.

Build (stage 3):
  python3 scripts/shotlist.py build/captions.json --audio build/audio.json

Fill the story fields in one table, then validate:
  python3 scripts/shotlist.py build/captions.json --audio build/audio.json
  python3 scripts/shotlist.py build/captions.json --fill beats.tsv
  python3 scripts/shotlist.py build/captions.json --check

`beats.tsv`, one row per shot, tab-separated:
  id  beat  scene  characters  action  camera
  s01 hook: the mine is empty  mine_tunnel_night  protagonist  stands, lifts the lantern  slow push-in

Regenerate after re-timing the voice (destroys authored fields):
  python3 scripts/shotlist.py build/captions.json --audio build/audio.json --force

Outputs
  build/shotlist.json   one row per shot: id, start, end, frames, caption,
                        captions, beat, scene, env, characters, action, camera,
                        depth, fx, transition_out
  analysis/SHOTLIST.md  the same table, readable

Exit codes: 0 pass, 1 check failed, 2 cannot build (bad input)
"""
from __future__ import annotations

import argparse
import json
import os
import re
import sys

FPS = 30
TARGET = 2.2      # s per shot, mean (hard rule 11: 1.5-3.0 s)
LO, HI = 1.5, 3.0
CREATIVE = ("beat", "scene", "characters", "action", "camera")


def load_cards(path):
    cards = json.load(open(path, encoding="utf-8-sig"))
    if not isinstance(cards, list) or not cards:
        raise SystemExit("captions file must be a non-empty list")
    for c in cards:
        if not all(k in c for k in ("text", "start", "end")):
            raise SystemExit("caption missing text/start/end: %r" % (c,))
        if float(c["end"]) <= float(c["start"]):
            raise SystemExit("caption ends before it starts: %r" % (c,))
    return sorted(cards, key=lambda c: float(c["start"]))


def duration_of(args, cards):
    if args.duration:
        return float(args.duration)
    if args.audio and os.path.exists(args.audio):
        d = json.load(open(args.audio))
        if "duration" in d:
            return float(d["duration"])
    return float(cards[-1]["end"]) + 0.30


def boundaries(cards, total):
    """Shot boundaries: mid-point of each silent gap, so silence is shared
    instead of all of it landing inside one shot. The video starts at frame 0,
    so the first shot does too, even when the first word lands later."""
    b = [0.0]
    for a, nxt in zip(cards, cards[1:]):
        gap_end = min(float(nxt["start"]), total)
        b.append((float(a["end"]) + gap_end) / 2.0)
    b.append(total)
    return b


def group(cards, b):
    """Greedy: add a caption while the shot stays inside HI, stop at TARGET."""
    n, i, out = len(cards), 0, []
    while i < n:
        j = i
        while j + 1 < n and b[j + 2] - b[i] <= HI:
            j += 1
            if b[j + 1] - b[i] >= TARGET:
                break
        out.append((i, j))
        i = j + 1
    return out


def build(cards, total, fps):
    if total <= 0:
        raise SystemExit("audio has no duration")
    total_frames = int(round(total * fps))
    over = [c for c in cards if float(c["end"]) > total + 0.01]
    b = boundaries(cards, total)
    b[-1] = total
    groups = group(cards, b)
    shots, prev = [], 0
    for k, (i, j) in enumerate(groups):
        f0 = prev
        if k == len(groups) - 1:
            f1 = min(total_frames, int(round((float(cards[-1]["end"]) + 0.60) * fps)))
        else:
            f1 = int(round(b[j + 1] * fps))
        f1 = max(f1, f0 + 1)
        if f1 > total_frames:
            f1 = total_frames
        prev = f1
        rows = cards[i:j + 1]
        words = [w for c in rows for w in str(c["text"]).split()]
        shots.append({
            "id": "s%02d" % (k + 1),
            "start": round(f0 / float(fps), 3),
            "end": round(f1 / float(fps), 3),
            "frames": [f0, f1],
            "caption": words,
            "captions": [{"text": c["text"], "start": c["start"], "end": c["end"]}
                         for c in rows],
            "beat": "",
            "scene": "",
            "env": "",
            "characters": [],
            "action": "",
            "camera": "",
            "depth": "",
            "fx": [],
            "asset_prompt": "",
            "transition_out": "hard_cut",
        })

    # trailing silence: never a 7 s static last shot. Hold the last caption for
    # at most 0.6 s, then cover the rest with end-card shots inside the limit.
    left = total_frames - prev
    cap = int(HI * fps)
    n_tail = 0
    while left > 0:
        n = min(left, cap)
        f0, f1 = prev, prev + n
        shots.append({
            "id": "s%02d" % (len(shots) + 1),
            "start": round(f0 / float(fps), 3),
            "end": round(f1 / float(fps), 3),
            "frames": [f0, f1],
            "caption": [],
            "captions": [],
            "tail": True,
            "beat": "",
            "scene": "",
            "env": "",
            "characters": [],
            "action": "",
            "camera": "",
            "depth": "",
            "fx": [],
            "asset_prompt": "",
            "transition_out": "hard_cut",
        })
        prev = f1
        left = total_frames - prev
        n_tail += 1
    return shots, total_frames, over


def write_md(shots, fps, path):
    lines = ["# Shotlist", "",
             "%d shots · %.2f s · %d frames @ %d fps" %
             (len(shots), sum(s["end"] - s["start"] for s in shots),
              shots[-1]["frames"][1], fps), "",
             "| id | in | out | frames | caption | beat | scene | camera |",
             "|---|---|---|---|---|---|---|---|"]
    for s in shots:
        lines.append("| %s | %.2f | %.2f | %d | %s | %s | %s | %s |" % (
            s["id"], s["start"], s["end"], s["frames"][1] - s["frames"][0],
            " ".join(s["caption"])[:48], s["beat"] or "—", s["scene"] or "—",
            s["camera"] or "—"))
    os.makedirs(os.path.dirname(path) or ".", exist_ok=True)
    open(path, "w", encoding="utf-8").write("\n".join(lines) + "\n")


def apply_fill(path, tsv, md, fps):
    """Fill the creative fields from a six-column table, one row per shot:
    id <tab> beat <tab> scene <tab> characters <tab> action <tab> camera.
    One file beats thirty JSON edits, and the check still validates the result."""
    shots = json.load(open(path, encoding="utf-8-sig"))
    by_id = {s["id"]: s for s in shots}
    n = 0
    for line in open(tsv, encoding="utf-8-sig"):
        line = line.rstrip("\n")
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        parts = [p.strip() for p in line.split("\t")]
        if len(parts) < 6:
            parts = [p.strip() for p in re.split(r"\s{2,}", line)]
        if len(parts) < 6:
            raise SystemExit("row needs 6 tab-separated fields: %r" % line)
        sid, beat, scene, chars, action, camera = parts[:6]
        if sid.lower() == "id":            # header row
            continue
        s = by_id.get(sid)
        if not s:
            raise SystemExit("no shot %r in %s" % (sid, path))
        s["beat"], s["scene"] = beat, scene
        s["characters"] = [c.strip() for c in re.split(r"[,;]", chars) if c.strip()]
        s["action"], s["camera"] = action, camera
        n += 1
    json.dump(shots, open(path, "w", encoding="utf-8"), indent=1)
    write_md(shots, fps, md)
    print("filled %d/%d shots from %s" % (n, len(shots), tsv))


def check(path, cards, total, fps):
    shots = json.load(open(path, encoding="utf-8-sig"))
    total_frames = int(round(total * fps))
    bad, warn = [], []

    if not shots:
        return ["shotlist is empty"], warn

    frames = 0
    prev = 0
    for s in shots:
        f0, f1 = s["frames"]
        frames += f1 - f0
        if f0 != prev:
            bad.append("%s: frames start at %d, previous shot ended at %d" % (s["id"], f0, prev))
        if f1 <= f0:
            bad.append("%s: zero-length shot" % s["id"])
        prev = f1
        dur = (f1 - f0) / float(fps)
        if abs(float(s.get("start", -1)) - f0 / float(fps)) > 0.01:
            bad.append("%s: start %.2f does not match frame %d" % (s["id"], s.get("start", -1), f0))
        if abs(float(s.get("end", -1)) - f1 / float(fps)) > 0.01:
            bad.append("%s: end %.2f does not match frame %d" % (s["id"], s.get("end", -1), f1))
        if dur > HI + 0.10:
            bad.append("%s: %.2f s is over the %.1f s limit" % (s["id"], dur, HI))
        if dur < LO - 0.10:
            warn.append("%s: %.2f s is under %.1f s (fast captions)" % (s["id"], dur, LO))
        for k in CREATIVE:
            v = s.get(k)
            if not v:
                bad.append("%s: %s is empty" % (s["id"], k))
        if s.get("transition_out") not in (None, "", "hard_cut"):
            bad.append("%s: transition_out must be hard_cut" % s["id"])
        if not s.get("tail") and not s.get("caption"):
            bad.append("%s: no caption words" % s["id"])

    if abs(frames - total_frames) > 1:
        bad.append("frames sum to %d, voice duration is %d (%.2f s @ %d fps)" %
                   (frames, total_frames, total, fps))
    if prev > total_frames + 1:
        bad.append("last shot ends at frame %d, past the voice at %d" % (prev, total_frames))

    want = sum(len(str(c["text"]).split()) for c in cards)
    got = sum(len(s.get("caption", [])) for s in shots)
    if want != got:
        bad.append("caption words: %d in the shotlist, %d in captions.json" % (got, want))

    ids = [s["id"] for s in shots]
    if len(set(ids)) != len(ids):
        bad.append("duplicate shot ids")
    return bad, warn


def main(argv=None):
    ap = argparse.ArgumentParser(description="captions -> frame-exact shot skeleton")
    ap.add_argument("captions", nargs="?", default="build/captions.json")
    ap.add_argument("--audio", default="build/audio.json", help="vo_timing run record (duration)")
    ap.add_argument("--duration", type=float, help="override the duration in seconds")
    ap.add_argument("--fps", type=int, default=FPS)
    ap.add_argument("--out", default="build/shotlist.json")
    ap.add_argument("--md", default="analysis/SHOTLIST.md")
    ap.add_argument("--check", action="store_true", help="validate an existing shotlist")
    ap.add_argument("--fill", help="TSV: id, beat, scene, characters, action, camera")
    ap.add_argument("--force", action="store_true", help="overwrite authored fields")
    args = ap.parse_args(argv)

    cards = load_cards(args.captions)
    total = duration_of(args, cards)

    if args.check:
        if not os.path.exists(args.out):
            print("no %s — build it first" % args.out)
            return 2
        bad, warn = check(args.out, cards, total, args.fps)
        for w in warn:
            print("warn:", w)
        for b in bad:
            print("FAIL:", b)
        shots = json.load(open(args.out))
        frames = sum(s["frames"][1] - s["frames"][0] for s in shots)
        print("\n%d shots · %d frames (voice %d) · %.2f s" %
              (len(shots), frames, int(round(total * args.fps)), total))
        print("PASS" if not bad else "%d failing" % len(bad))
        return 0 if not bad else 1

    if not os.path.exists(args.out) or args.force:
        shots, total_frames, over = build(cards, total, args.fps)
        os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
        json.dump(shots, open(args.out, "w", encoding="utf-8"), indent=1)
        write_md(shots, args.fps, args.md)
        if over:
            print("warn: %d caption(s) end past the audio (%.2f s); clamped to the last frame" %
                  (len(over), total))
        print("%d shots · %d frames · %.2f s @ %d fps" %
              (len(shots), total_frames, total, args.fps))
        print("%-4s %7s %7s %6s  %s" % ("id", "in", "out", "sec", "caption"))
        for s in shots:
            print("%-4s %7.2f %7.2f %6.2f  %s" %
                  (s["id"], s["start"], s["end"], s["end"] - s["start"],
                   " ".join(s["caption"])[:44]))
        print("\nwrote %s and %s" % (args.out, args.md))
        if not args.fill:
            print("next: fill beat, scene, characters, action, camera — then --check")
            return 0
    if os.path.exists(args.out) and args.fill:
        apply_fill(args.out, args.fill, args.md, args.fps)
        return 0
    if os.path.exists(args.out):
        cur = json.load(open(args.out))
        filled = [s["id"] for s in cur if s.get("beat")]
        print("%s already exists (%d shots, %d with a beat).\n"
              "  --check   validate it\n"
              "  --fill    add story fields from a table\n"
              "  --force   regenerate timings (discards authored fields)" %
              (args.out, len(cur), len(filled)))
        return 2
    return 0


if __name__ == "__main__":
    sys.exit(main())
