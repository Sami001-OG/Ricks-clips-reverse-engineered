#!/usr/bin/env python3
"""plate3d.py — build a 1080x1920 3D plate from a scene spec, on the CPU.

A plate is the world behind the actors: no characters, no captions. This tool is
deterministic, needs no image model and no GPU, and reports its own numbers so
stage 4 can be checked without a vision pass.

    python3 scripts/plate3d.py --demo                      # writes build/scenes/demo.json + out/plates/demo.png
    python3 scripts/plate3d.py --scene build/scenes/mine.json
    python3 scripts/plate3d.py --scene build/scenes/mine.json --record build/plates.json
    python3 scripts/plate3d.py --probe                     # JSON: is 3D available here?

Engine: pyrender on Mesa llvmpipe through EGL (offscreen only). If that is
missing, exit 3 — the caller falls back to the vector plate in
`references/world.md` C.0. Never a blank background.

Scene spec (all lengths in metres, right-handed, +Y up, camera looks at target):

{
  "location": "mine_tunnel_night",
  "size": [1080, 1920],
  "camera": {"pos": [0.18, 1.62, 0.0], "target": [0.0, 1.42, 9.0], "yfov_deg": 58},
  "floor_y": 0.0,
  "feet_at": [0.0, 3.0],
  "materials": {
    "stone":  {"texture": "rock_wall_08", "tile": 0.95, "roughness": 0.88, "normal_strength": 0.42},
    "cobble": {"texture": "cobblestone_floor_08", "tile": 1.05, "roughness": 0.82},
    "wood":   {"texture": "dark_wooden_planks", "tile": 0.62, "roughness": 0.62},
    "iron":   {"texture": "green_metal_rust", "tile": 0.5, "roughness": 0.42, "metallic": 0.8},
    "lamp":   {"emissive": [9.0, 5.6, 2.6], "color": [1.0, 0.72, 0.42]},
    "warm":   {"color": [0.55, 0.36, 0.22], "roughness": 0.7},
    "paint":  {"solid": true, "color": [0.62, 0.63, 0.62], "roughness": 0.7},
    "fabric": {"solid": true, "color": [0.16, 0.20, 0.30], "roughness": 0.96},
    "sky":    {"sky": true, "top": [0.13, 0.21, 0.42], "bottom": [1.0, 0.62, 0.36]}
  },
  "geometry": [
    {"type": "room", "center": [0, 2.1, 0], "size": [2.4, 4.2, 16], "material": "stone", "open": ["front"]},
    {"type": "floor", "center": [0, 0, 8], "size": [2.4, 16], "material": "cobble"},
    {"type": "box", "center": [0.0, 0.02, 9.0], "size": [2.4, 0.05, 0.09], "material": "iron"}
  ],
  "lights": [
    {"type": "directional", "pos": [6, 5, -3], "target": [0, 1, 8],
     "color": [0.52, 0.64, 0.86], "intensity": 4.6, "shadow": true},
    {"type": "point", "pos": [0.68, 3.5, 4.6], "target": [1.4, 0, 5.8],
     "color": [1.0, 0.70, 0.42], "intensity": 95.0}
  ],
  "post": {"exposure": 2.05, "seed": 7, "ssao": {"radius": 0.45, "strength": 0.42},
           "haze": {"start": 6.0, "falloff": 18.0, "max": 0.55, "color": [0.16, 0.20, 0.27]},
           "dof": {"start": 5.0, "falloff": 9.0, "radius": 2.6},
           "grain": 0.012, "vignette": 0.32, "bloom": [[9, 0.55], [34, 0.35]]}
}

Materials resolve `texture` from assets/textures/<id>_{diffuse,nor_gl}.jpg when
`scripts/fetch_textures.py` has cached it, otherwise they are generated
procedurally (fBm + a wear pattern), so the tool works offline and first run.

Three material kinds cover a modern interior, which no stone scan will:

- `{"solid": true, "color": [...]}` — manufactured surface: paint, panel,
  seat fabric, carpet. Flat tint plus micro-grain, no photo. A rock scan on a
  cabin wall is a bug: use this for anything a factory made.
- `{"sky": true, "top": [...], "bottom": [...]}` — a gradient emissive panel,
  unit-mapped, for sky and horizon. Pair it with `haze` and a low `exposure`.
- `{"emissive": [...], "color": [...]}` — lights, windows, signage, sun.

`room` takes `"faces": {"floor": "carpet", "ceiling": "panel", ...}` so a
corridor can have a different material on each of its six surfaces.

`post.lift` (0–0.03) raises the black point; use ~0.01 for a dark interior so
shadows do not crush to a single colour. Warning: pyrender's `ambient` is
**additive**, not multiplied by albedo — 0.1 paints grey over every black in
the frame. Keep it at 0.02–0.05 and use a dim directional as fill instead.

Outputs
  PNG plate (1080x1920)
  plates.json record: feet line in px, material ids, seed, engine, seconds, sha256,
                      measured flat_coverage / flat_lit / contrast / hue count

`flat_coverage` is the largest colour bucket over the whole frame; `flat_lit`
is the same over pixels brighter than 0.10 luma. Judge a plate on `flat_lit`:
a night interior is legitimately half black, and that is not a flat wash.

Exit codes: 0 ok, 2 bad spec, 3 no 3D engine (fall back to C.0)
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import math
import os
import shutil
import subprocess
import sys
import time

import numpy as np
from PIL import Image, ImageFilter

# ---------------------------------------------------------------- engine shim
# pyrender 0.1.45 imports pyglet's window for its Viewer (no display on Android)
# and uses a few NumPy 1.x aliases that NumPy 2 removed.
for _n, _v in (("infty", np.inf), ("float", float), ("int", int), ("bool", bool)):
    if not hasattr(np, _n):
        setattr(np, _n, _v)

def _ensure_display():
    """Mesa's EGL here needs an X display to create a context. Start a throwaway
    Xvfb if the sandbox has none, so the plate path does not depend on the
    caller remembering DISPLAY=:99."""
    os.environ.setdefault("PYOPENGL_PLATFORM", "egl")
    if os.environ.get("DISPLAY") or not shutil.which("Xvfb"):
        return
    disp = ":99"
    try:
        subprocess.Popen(["Xvfb", disp, "-screen", "0", "1080x1920x24"],
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                         start_new_session=True)
        time.sleep(1.8)
        os.environ["DISPLAY"] = disp
    except Exception:
        pass


ENGINE = None
try:
    _ensure_display()
    import types

    _viewer = types.ModuleType("pyrender.viewer")
    _viewer.Viewer = object
    sys.modules.setdefault("pyrender.viewer", _viewer)
    import pyrender  # noqa: E402

    ENGINE = "pyrender"
except Exception as _e:  # pragma: no cover - reported by --probe
    pyrender = None
    ENGINE_ERR = str(_e)

TEX_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                       "assets", "textures")


# ---------------------------------------------------------------- colour
def srgb_to_linear(a):
    a = np.asarray(a, dtype=np.float32)
    return np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)


def linear_to_srgb(a):
    a = np.clip(a, 0.0, 1.0)
    return np.where(a <= 0.0031308, a * 12.92, 1.055 * a ** (1 / 2.4) - 0.055)


# ---------------------------------------------------------------- textures
def _value_noise(n, freq, rng):
    """Tileable value noise on a freq x freq lattice, bilinear + smoothstep."""
    g = rng.random((freq, freq), dtype=np.float32)
    t = np.linspace(0, freq, n, endpoint=False, dtype=np.float32)
    i0 = np.floor(t).astype(np.int32)
    f = t - i0
    f = f * f * (3 - 2 * f)
    i1 = (i0 + 1) % freq
    i0 = i0 % freq
    g00 = g[np.ix_(i0, i0)]
    g10 = g[np.ix_(i1, i0)]
    g01 = g[np.ix_(i0, i1)]
    g11 = g[np.ix_(i1, i1)]
    fy = f[:, None]
    fx = f[None, :]
    return ((g00 * (1 - fx) + g10 * fx) * (1 - fy) + (g01 * (1 - fx) + g11 * fx) * fy)


def _fbm(n, seed, octaves=5, base=4):
    rng = np.random.default_rng(seed)
    out = np.zeros((n, n), np.float32)
    amp, norm = 1.0, 0.0
    for k in range(octaves):
        out += _value_noise(n, base * (2 ** k), rng) * amp
        norm += amp
        amp *= 0.5
    return out / norm


def _normal_from_height(h, strength):
    gy, gx = np.gradient(h.astype(np.float32) * strength)
    n = np.stack([-gx, -gy, np.ones_like(h)], -1)
    n /= np.linalg.norm(n, axis=-1, keepdims=True) + 1e-9
    return np.clip(n * 0.5 + 0.5, 0, 1)


def _cellmap(n, rows, cols, seed):
    """Tileable cell grid: per-pixel cell value + fractional position in the cell."""
    rng = np.random.default_rng(seed)
    vals = rng.random((rows, cols), dtype=np.float32)
    yv = np.arange(n, dtype=np.float32) * rows / n
    xv = np.arange(n, dtype=np.float32) * cols / n
    iy = np.floor(yv).astype(np.int32) % rows
    ix = np.floor(xv).astype(np.int32) % cols
    fy = (yv - np.floor(yv))[:, None]
    fx = (xv - np.floor(xv))[None, :]
    return vals[np.ix_(iy, ix)], fx, fy


def procedural_material(name, seed, tile_px=512):
    """No photo available: albedo + height from tileable fBm and a wear pattern.
    Deliberately conservative — stone reads stone, wood reads wood, metal reads
    rusted metal. It is the offline floor, not the ceiling."""
    n = tile_px
    ys, xs = np.mgrid[0:n, 0:n].astype(np.float32) / n
    base = _fbm(n, seed, 5, 4)
    fine = _fbm(n, seed + 11, 4, 16)
    h = 0.6 * base + 0.4 * fine

    if "wood" in name:
        grain = 0.5 + 0.5 * np.sin((xs * 34 + base * 9) * math.pi)
        h = 0.35 * h + 0.65 * grain
        alb = np.stack([0.44, 0.30, 0.19], -1) * (0.62 + 0.55 * h[..., None])
    elif "metal" in name or "iron" in name:
        rust = np.clip((fine - 0.55) * 3.0, 0, 1)
        alb = (np.stack([0.22, 0.24, 0.23], -1) * (0.7 + 0.5 * h[..., None])
               * (1 - rust[..., None]) + np.stack([0.36, 0.16, 0.07], -1) * rust[..., None])
        h = 0.4 * h + 0.6 * rust
    elif "cobble" in name or "floor" in name or "ground" in name:
        # broken ground: dense stones, thin dark seams, no regular grid
        seam = np.abs(_fbm(n, seed + 41, 4, 10) - 0.5)
        gap = np.clip((0.045 - seam) * 55.0, 0, 1)
        alb = np.stack([0.47, 0.44, 0.40], -1) * (0.55 + 0.75 * h[..., None])
        alb = alb * (1 - 0.72 * gap[..., None])
        h = 0.75 * h + 0.25 * (1 - gap)
    else:  # rock face: low-frequency mass, high-frequency grit, dark seams
        mass = _fbm(n, seed + 51, 3, 3)
        seam = np.abs(_fbm(n, seed + 61, 4, 9) - 0.5)
        gap = np.clip((0.05 - seam) * 40.0, 0, 1)
        alb = np.stack([0.45, 0.44, 0.42], -1) * (0.55 + 0.65 * mass[..., None] + 0.25 * h[..., None])
        alb = alb * (1 - 0.65 * gap[..., None])
        h = 0.55 * mass + 0.45 * h
    return np.clip(alb, 0, 1).astype(np.float32), _normal_from_height(h, 0.55)


def load_material(tex, mode):
    """-> (albedo sRGB array, normal array or None, source label)"""
    if tex and mode != "procedural":
        d = os.path.join(TEX_DIR, tex + "_diffuse.jpg")
        nrm = os.path.join(TEX_DIR, tex + "_nor_gl.jpg")
        if os.path.exists(d):
            alb = np.asarray(Image.open(d).convert("RGB"), dtype=np.float32) / 255.0
            n = (np.asarray(Image.open(nrm).convert("RGB"), dtype=np.float32) / 255.0
                 if os.path.exists(nrm) else None)
            return alb, n, "photo:" + tex
    seed = abs(hash(tex or "solid")) % 9999
    alb, n = procedural_material(tex or "stone", seed)
    return alb, n, "procedural"


# ---------------------------------------------------------------- geometry
def look_at(eye, target, up=(0, 1, 0)):
    eye = np.array(eye, float)
    tgt = np.array(target, float)
    f = tgt - eye
    n = np.linalg.norm(f)
    if n < 1e-6:
        raise ValueError("camera target coincides with its position")
    f /= n
    up = np.array(up, float)
    if abs(float(np.dot(f, up))) > 0.999:
        up = np.array([0.0, 0.0, 1.0])          # looking straight up/down
    r = np.cross(f, up)
    r /= np.linalg.norm(r) + 1e-9
    u = np.cross(r, f)
    m = np.eye(4)
    m[:3, 0], m[:3, 1], m[:3, 2], m[:3, 3] = r, u, -f, eye
    return m


class Material:
    def __init__(self, mid, spec, mode):
        self.id = mid
        self.tile = float(spec.get("tile", 1.0))
        self.emissive = spec.get("emissive")
        if self.emissive:
            col = np.array(spec.get("color", [1, 1, 1]), np.float32)
            self.material = pyrender.MetallicRoughnessMaterial(
                baseColorFactor=[float(c) for c in col] + [1.0],
                emissiveFactor=[float(c) for c in self.emissive],
                roughnessFactor=1.0, metallicFactor=0.0)
            self.source = "emissive"
            return
        if spec.get("sky"):
            # A gradient panel standing in for sky and dawn horizon. Emissive so
            # it is not lit by the scene rig, and unit-mapped so the gradient
            # runs once across the quad instead of tiling.
            top = np.array(spec.get("top", [0.3, 0.4, 0.6]), np.float32)
            bot = np.array(spec.get("bottom", [0.9, 0.7, 0.55]), np.float32)
            t = (np.linspace(0, 1, 128) ** 1.7)[:, None, None]
            grad = srgb_to_linear(top * (1 - t) + bot * t).astype(np.float32)
            tex = np.repeat(grad, 4, axis=1)
            self.material = pyrender.MetallicRoughnessMaterial(
                baseColorFactor=[0.0, 0.0, 0.0, 1.0], emissiveTexture=tex,
                emissiveFactor=[1.0, 1.0, 1.0], roughnessFactor=1.0, metallicFactor=0.0)
            self.unit_uv = True
            self.source = "sky"
            return
        if spec.get("solid"):
            # Manufactured surface: paint, panel, seat fabric. A photo scan of
            # rock on a cabin wall is a bug, not texture. Flat tint + micro
            # grain, tiled small, so it shades but never reads as stone.
            tint = np.array(spec.get("color", [0.8, 0.8, 0.8]), np.float32)
            n = 96
            f = _fbm(n, abs(hash(mid)) % 9999, 4, 6)
            f = 0.5 + (f - f.mean()) * 1.6
            alb = np.clip(tint[None, None, :] * (0.88 + 0.24 * f[..., None]), 0, 1)
            self.alb = srgb_to_linear(alb.astype(np.float32))
            self.source = "solid"
            self.tile = float(spec.get("tile", 0.28))
            self.material = pyrender.MetallicRoughnessMaterial(
                baseColorTexture=self.alb, baseColorFactor=[1.0, 1.0, 1.0, 1.0],
                metallicFactor=float(spec.get("metallic", 0.0)),
                roughnessFactor=float(spec.get("roughness", 0.85)))
            return
        alb, nrm, self.source = load_material(spec.get("texture"), mode)
        self.alb = srgb_to_linear(alb)
        strength = float(spec.get("normal_strength", 0.55))
        if nrm is not None:
            nrm = np.clip(0.5 + (nrm - 0.5) * strength, 0, 1)
            nrm[..., 2] = np.maximum(nrm[..., 2], 0.55)
        tint = spec.get("color", [1, 1, 1])
        self.material = pyrender.MetallicRoughnessMaterial(
            baseColorTexture=self.alb, normalTexture=nrm,
            baseColorFactor=[float(c) for c in tint] + [1.0],
            metallicFactor=float(spec.get("metallic", 0.0)),
            roughnessFactor=float(spec.get("roughness", 0.8)))


def add_quad(prims, p0, p1, p2, p3, mat, tile=None, seen_from=None):
    """Any winding; the normal is oriented toward `seen_from` so a surface can
    never be culled by accident."""
    p = np.array([p0, p1, p2, p3], dtype=np.float64)
    n = np.cross(p[1] - p[0], p[2] - p[0])
    n /= np.linalg.norm(n) + 1e-9
    if seen_from is not None and n @ (np.asarray(seen_from, float) - p.mean(0)) < 0:
        p = p[::-1]
        n = -n
    if getattr(mat, "unit_uv", False):
        lo, hi = p.min(0), p.max(0)
        span = np.maximum(hi - lo, 1e-6)
        uv = np.stack([(p[:, 0] - lo[0]) / span[0], (p[:, 1] - lo[1]) / span[1]], 1)
    else:
        ax = np.argsort(np.abs(n))[:2]
        t = tile or mat.tile
        uv = np.stack([p[:, ax[1]] / t, p[:, ax[0]] / t], 1)
    prims.append(pyrender.Primitive(
        positions=p.astype(np.float32),
        normals=np.tile(n.astype(np.float32), (4, 1)),
        texcoord_0=uv.astype(np.float32),
        indices=np.array([[0, 1, 2], [0, 2, 3]], dtype=np.uint32),
        material=mat.material, mode=4))


def add_box(prims, c, s, mat):
    x0, x1 = c[0] - s[0] / 2, c[0] + s[0] / 2
    y0, y1 = c[1] - s[1] / 2, c[1] + s[1] / 2
    z0, z1 = c[2] - s[2] / 2, c[2] + s[2] / 2
    o = tuple(c)
    add_quad(prims, (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1), mat, seen_from=o)
    add_quad(prims, (x1, y0, z0), (x0, y0, z0), (x0, y1, z0), (x1, y1, z0), mat, seen_from=o)
    add_quad(prims, (x0, y1, z1), (x1, y1, z1), (x1, y1, z0), (x0, y1, z0), mat, seen_from=o)
    add_quad(prims, (x0, y0, z0), (x1, y0, z0), (x1, y0, z1), (x0, y0, z1), mat, seen_from=o)
    add_quad(prims, (x1, y0, z1), (x1, y0, z0), (x1, y1, z0), (x1, y1, z1), mat, seen_from=o)
    add_quad(prims, (x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0), mat, seen_from=o)


def add_room(prims, c, s, mat, eye, open_faces=(), faces=None):
    fm = faces or {}
    mat_floor, mat_ceil = fm.get("floor", mat), fm.get("ceiling", mat)
    mat_left, mat_right = fm.get("left", mat), fm.get("right", mat)
    mat_back, mat_front = fm.get("back", mat), fm.get("front", mat)
    x0, x1 = c[0] - s[0] / 2, c[0] + s[0] / 2
    y0, y1 = c[1] - s[1] / 2, c[1] + s[1] / 2
    z0, z1 = c[2] - s[2] / 2, c[2] + s[2] / 2
    if "floor" not in open_faces:
        add_quad(prims, (x0, y0, z0), (x0, y0, z1), (x1, y0, z1), (x1, y0, z0), mat_floor, seen_from=eye)
    if "ceiling" not in open_faces:
        add_quad(prims, (x0, y1, z0), (x0, y1, z1), (x1, y1, z1), (x1, y1, z0), mat_ceil, seen_from=eye)
    if "left" not in open_faces:
        add_quad(prims, (x0, y0, z0), (x0, y0, z1), (x0, y1, z1), (x0, y1, z0), mat_left, seen_from=eye)
    if "right" not in open_faces:
        add_quad(prims, (x1, y0, z0), (x1, y0, z1), (x1, y1, z1), (x1, y1, z0), mat_right, seen_from=eye)
    if "back" not in open_faces:
        add_quad(prims, (x0, y0, z1), (x1, y0, z1), (x1, y1, z1), (x0, y1, z1), mat_back, seen_from=eye)
    if "front" not in open_faces:
        add_quad(prims, (x0, y0, z0), (x1, y0, z0), (x1, y1, z0), (x0, y1, z0), mat_front, seen_from=eye)


def build(spec, mode):
    mats = {k: Material(k, v, mode) for k, v in spec.get("materials", {}).items()}
    prims, used = [], set()
    eye = tuple(spec["camera"]["pos"])
    for g in spec.get("geometry", []):
        m = mats.get(g.get("material"))
        if m is None:
            raise SystemExit("geometry refers to unknown material %r" % g.get("material"))
        used.add(g["material"])
        if g["type"] == "room":
            fmap = {k: mats[v] for k, v in (g.get("faces") or {}).items()}
            used.update((g.get("faces") or {}).values())
            add_room(prims, g["center"], g["size"], m, eye, g.get("open", ()), fmap)
        elif g["type"] == "box":
            add_box(prims, g["center"], g["size"], m)
        elif g["type"] == "floor":
            c, s = g["center"], g["size"]
            add_quad(prims, (c[0] - s[0] / 2, c[1], c[2] - s[1] / 2),
                     (c[0] - s[0] / 2, c[1], c[2] + s[1] / 2),
                     (c[0] + s[0] / 2, c[1], c[2] + s[1] / 2),
                     (c[0] + s[0] / 2, c[1], c[2] - s[1] / 2), m, seen_from=eye)
        elif g["type"] == "quad":
            add_quad(prims, *g["points"], m, seen_from=g.get("seen_from", eye))
        else:
            raise SystemExit("unknown geometry type %r" % g["type"])
    return prims, mats, used


# ---------------------------------------------------------------- render
def render(prims, spec):
    w, h = spec.get("size", [1080, 1920])
    scene = pyrender.Scene(bg_color=[0, 0, 0, 1],
                           ambient_light=list(spec.get("ambient", [0.085, 0.095, 0.12])))
    scene.add_node(pyrender.Node(mesh=pyrender.Mesh(prims), matrix=np.eye(4)))

    cam_spec = spec["camera"]
    yfov = math.radians(float(cam_spec.get("yfov_deg", 58)))
    cam = pyrender.PerspectiveCamera(yfov=yfov, aspectRatio=w / float(h))
    pose = look_at(cam_spec["pos"], cam_spec["target"])
    scene.add(cam, pose=pose)

    flags = pyrender.RenderFlags.RGBA
    for L in spec.get("lights", []):
        col = np.array(L.get("color", [1, 1, 1]), dtype=float)
        inten = float(L.get("intensity", 1.0))
        kind = L["type"]
        if kind == "directional":
            light = pyrender.DirectionalLight(color=col, intensity=inten)
            if L.get("shadow"):
                flags |= pyrender.RenderFlags.SHADOWS_DIRECTIONAL
        elif kind == "point":
            light = pyrender.PointLight(color=col, intensity=inten)
            if L.get("shadow"):
                flags |= pyrender.RenderFlags.SHADOWS_POINT
        elif kind == "spot":
            light = pyrender.SpotLight(color=col, intensity=inten,
                                       innerConeAngle=float(L.get("inner_deg", 30)) * math.pi / 180,
                                       outerConeAngle=float(L.get("outer_deg", 55)) * math.pi / 180)
            if L.get("shadow"):
                flags |= pyrender.RenderFlags.SHADOWS_SPOT
        else:
            raise SystemExit("unknown light type %r" % kind)
        scene.add(light, pose=look_at(L["pos"], L.get("target", [0, 0, 0])))
        if L.get("shadow"):
            light.castShadow = True

    r = pyrender.OffscreenRenderer(w, h)
    t0 = time.time()
    color, depth = r.render(scene, flags=flags)
    dt = time.time() - t0
    r.delete()
    return color, depth, pose, yfov, dt


def project(cam_pose, yfov, w, h, p):
    R = cam_pose[:3, :3]
    v = R.T @ (np.array(p, float) - cam_pose[:3, 3])
    z = -v[2]
    if z <= 0.01:
        return None
    f = (h / 2.0) / math.tan(yfov / 2.0)
    return (w / 2.0 + v[0] / z * f, h / 2.0 - v[1] / z * f, z)


# ---------------------------------------------------------------- post
def ssao(depth, yfov, scale=2, samples=12, radius=0.45, bias=0.035, seed=3):
    """Screen-space ambient occlusion from the depth buffer. Raster alone gives
    every surface the same ambient term; this is what darkens crevices and
    puts objects on the floor. Computed at 1/scale and upsampled."""
    h, w = depth.shape
    h2, w2 = max(1, h // scale), max(1, w // scale)
    z = np.asarray(Image.fromarray(depth.astype(np.float32)).resize((w2, h2), Image.NEAREST),
                   np.float32)
    z = np.where(z <= 0, 0.0, z)
    f = (h2 / 2.0) / math.tan(yfov / 2.0)
    yy, xx = np.mgrid[0:h2, 0:w2].astype(np.float32)
    px = (xx - w2 / 2.0) / f * z
    py = -(yy - h2 / 2.0) / f * z
    pos = np.stack([px, py, -z], -1).astype(np.float32)

    dx = np.gradient(pos, axis=1)
    dy = np.gradient(pos, axis=0)
    n = np.cross(dx, dy)
    n /= (np.linalg.norm(n, axis=-1, keepdims=True) + 1e-9)
    n *= np.sign(n[..., 2:3] + 1e-6)

    rng = np.random.default_rng(seed)
    u = np.c_[rng.normal(size=samples), rng.normal(size=samples),
              np.abs(rng.normal(size=samples)) + 0.35]
    u /= np.linalg.norm(u, axis=1, keepdims=True)

    up = np.where(np.abs(n[..., 1:2]) < 0.9,
                  np.array([0.0, 1.0, 0.0], np.float32),
                  np.array([1.0, 0.0, 0.0], np.float32))
    t = np.cross(up, n)
    t /= (np.linalg.norm(t, axis=-1, keepdims=True) + 1e-9)
    b = np.cross(n, t)

    occ = np.zeros((h2, w2), np.float32)
    for k in range(samples):
        d = t * u[k, 0] + b * u[k, 1] + n * u[k, 2]
        sp = pos + d * radius
        sz = -sp[..., 2]
        sx = np.clip(sp[..., 0] / np.maximum(sz, 1e-6) * f + w2 / 2.0, 0, w2 - 1).astype(np.int32)
        sy = np.clip(-sp[..., 1] / np.maximum(sz, 1e-6) * f + h2 / 2.0, 0, h2 - 1).astype(np.int32)
        scene_z = z[sy, sx]
        occ += ((scene_z > 0) & (scene_z < sz - bias)).astype(np.float32)
    ao = 1.0 - np.clip(occ / samples * 1.35, 0, 0.92)
    ao = np.where(z <= 0, 1.0, ao)

    img = Image.fromarray((ao * 255).astype(np.uint8)).resize((w, h), Image.BILINEAR)
    return np.asarray(img.filter(ImageFilter.GaussianBlur(1.6)), np.float32) / 255.0


def blur8(arr, radius):
    if radius < 0.3:
        return arr
    a = (np.clip(arr, 0, 1) * 255).astype(np.uint8)
    return np.asarray(Image.fromarray(a).filter(ImageFilter.GaussianBlur(radius)),
                      np.float32) / 255.0


def tonemap(x):
    a, b, c, d, e = 2.51, 0.03, 2.43, 0.59, 0.14
    return np.clip((x * (a * x + b)) / (x * (c * x + d) + e), 0, 1)


def post(color, depth, spec, yfov):
    p = spec.get("post", {})
    h, w = depth.shape
    x = srgb_to_linear(color.astype(np.float32)[..., :3] / 255.0)

    ao_spec = p.get("ssao", {})
    if ao_spec.get("strength", 0.42) > 0:
        ao = ssao(depth, yfov, radius=float(ao_spec.get("radius", 0.45)),
                  seed=int(p.get("seed", 7)) + 1)
        s = float(ao_spec.get("strength", 0.42))
        x = x * ((1.0 - s) + s * ao[..., None])

    x = x * float(p.get("exposure", 1.8))
    lift = float(p.get("lift", 0.0))
    if lift > 0:
        x = x + lift * np.clip(1.0 - x, 0, 1)
    x = tonemap(x)

    hz = p.get("haze")
    if hz:
        col = np.array(hz.get("color", [0.16, 0.20, 0.27]), np.float32)
        z = np.where(depth <= 0, 80.0, depth)
        f = np.clip(1.0 - np.exp(-np.maximum(z - float(hz.get("start", 5.0)), 0)
                                 / float(hz.get("falloff", 15.0))), 0, float(hz.get("max", 0.6)))
        x = x * (1 - f[..., None]) + col * f[..., None]

    for rad, amt in p.get("bloom", [[9, 0.55], [34, 0.35]]):
        lum = x @ np.array([0.2126, 0.7152, 0.0722], np.float32)
        hi = np.clip((lum - 0.72) / 0.28, 0, 1)[..., None] * x
        x = x + blur8(hi, rad) * amt

    dof = p.get("dof")
    if dof:
        soft = blur8(x, float(dof.get("radius", 2.6)))
        z = np.where(depth <= 0, 80.0, depth)
        m = np.clip((z - float(dof.get("start", 5.0))) / float(dof.get("falloff", 9.0)),
                    0, 1)[..., None]
        x = x * (1 - m) + soft * m

    x[..., 0] = np.roll(x[..., 0], 1, axis=1)
    x[..., 2] = np.roll(x[..., 2], -1, axis=1)

    l2 = (x @ np.array([0.2126, 0.7152, 0.0722], np.float32))[..., None]
    x *= ((1.0 + (1 - l2) * np.array([-0.02, 0.01, 0.07], np.float32))
          * (1.0 + l2 * np.array([0.05, 0.01, -0.05], np.float32)))

    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    r = np.sqrt(((xx - w / 2) / (w / 2)) ** 2 + ((yy - h / 2) / (h / 2)) ** 2)
    x *= (1.0 - float(p.get("vignette", 0.32)) * np.clip(r, 0, 1.6) ** 2)[..., None]

    rng = np.random.default_rng(int(p.get("seed", 7)))
    g = rng.normal(0, 1, (h, w, 1)).astype(np.float32)
    # Grain multiplies the signal: additive grain crushes every dark pixel to
    # black once the noise goes negative, which is a hole, not film.
    x = np.maximum(x, 0.0) * (1.0 + g * float(p.get("grain", 0.012)) * 3.2)

    return (linear_to_srgb(np.clip(x, 0, 1)) * 255).astype(np.uint8)


# ---------------------------------------------------------------- measure
def measure(img):
    a = img.astype(np.float32) / 255.0
    lum = a @ np.array([0.2126, 0.7152, 0.0722], np.float32)
    q = (img >> 4)
    key = (q[..., 0].astype(np.uint32) << 8) | (q[..., 1].astype(np.uint32) << 4) | q[..., 2]
    counts = np.bincount(key.ravel(), minlength=4096)
    flat = float(counts.max()) / key.size
    lit = lum > 0.10
    counts_lit = np.bincount(key[lit].ravel(), minlength=4096) if lit.any() else counts
    flat_lit = float(counts_lit.max()) / max(1, int(lit.sum()))
    p5, p95 = np.percentile(lum, [5, 95])
    mx = a.max(-1) + 1e-6
    mn = a.min(-1)
    sat = (mx - mn) / mx
    hue = np.zeros_like(mx)
    rr, gg, bb = a[..., 0], a[..., 1], a[..., 2]
    d = mx - mn
    hue = np.where(mx == rr, ((gg - bb) / (d + 1e-6)) % 6,
                   np.where(mx == gg, (bb - rr) / (d + 1e-6) + 2,
                            (rr - gg) / (d + 1e-6) + 4)) * 60.0
    mask = sat > 0.15
    buckets = set((hue[mask] // 30).astype(int).tolist()) if mask.any() else set()
    return {"flat_coverage": round(flat, 3), "flat_lit": round(flat_lit, 3),
            "contrast": round(float(p95 - p5), 3),
            "hue_clusters": len(buckets),
            "mean_luma": round(float(lum.mean()), 3)}


# ---------------------------------------------------------------- demo spec
DEMO = {
    "location": "demo_tunnel",
    "size": [1080, 1920],
    "camera": {"pos": [0.18, 1.62, 0.0], "target": [0.0, 1.42, 9.0], "yfov_deg": 58},
    "floor_y": 0.0,
    "feet_at": [0.0, 3.2],
    "ambient": [0.085, 0.095, 0.12],
    "materials": {
        "stone": {"texture": "rock_wall_08", "tile": 0.95, "roughness": 0.88, "normal_strength": 0.42},
        "cobble": {"texture": "cobblestone_floor_08", "tile": 1.05, "roughness": 0.82},
        "wood": {"texture": "dark_wooden_planks", "tile": 0.62, "roughness": 0.62, "normal_strength": 0.5},
        "iron": {"texture": "green_metal_rust", "tile": 0.5, "roughness": 0.42, "metallic": 0.8},
        "lamp": {"emissive": [9.0, 5.6, 2.6], "color": [1.0, 0.72, 0.42]},
    },
    "geometry": [
        {"type": "room", "center": [0, 2.1, 8.1], "size": [2.4, 4.2, 16.2], "material": "stone",
         "open": ["front"]},
        {"type": "floor", "center": [0, 0.004, 8.1], "size": [2.4, 16.2], "material": "cobble"},
        {"type": "box", "center": [0, 4.15, 2.8], "size": [2.5, 0.28, 0.22], "material": "wood"},
        {"type": "box", "center": [0, 4.15, 5.6], "size": [2.5, 0.28, 0.22], "material": "wood"},
        {"type": "box", "center": [0, 4.15, 8.4], "size": [2.5, 0.28, 0.22], "material": "wood"},
        {"type": "box", "center": [0, 4.15, 11.2], "size": [2.5, 0.28, 0.22], "material": "wood"},
        {"type": "box", "center": [-0.75, 0.32, 4.2], "size": [0.62, 0.64, 0.6], "material": "wood"},
        {"type": "box", "center": [-0.55, 0.80, 4.35], "size": [0.5, 0.5, 0.45], "material": "wood"},
        {"type": "box", "center": [0.82, 0.24, 6.6], "size": [0.42, 0.46, 0.42], "material": "iron"},
        {"type": "box", "center": [0.0, 0.02, 9.0], "size": [2.4, 0.05, 0.09], "material": "iron"},
        {"type": "box", "center": [1.06, 1.2, 3.4], "size": [0.18, 2.4, 0.18], "material": "wood"},
        {"type": "box", "center": [1.06, 1.2, 7.0], "size": [0.18, 2.4, 0.18], "material": "wood"},
        {"type": "box", "center": [1.06, 1.2, 10.6], "size": [0.18, 2.4, 0.18], "material": "wood"},
        {"type": "box", "center": [0.55, 3.62, 4.6], "size": [0.26, 0.10, 0.26], "material": "iron"},
        {"type": "quad", "material": "lamp", "seen_from": [0.7, 2.0, 4.6],
         "points": [[0.56, 3.56, 4.48], [0.56, 3.56, 4.72], [0.80, 3.56, 4.72], [0.80, 3.56, 4.48]]},
    ],
    "lights": [
        {"type": "directional", "pos": [6, 5, -3], "target": [0, 1, 8],
         "color": [0.52, 0.64, 0.86], "intensity": 4.6, "shadow": True},
        {"type": "point", "pos": [0.68, 3.5, 4.6], "target": [1.4, 0, 5.8],
         "color": [1.0, 0.70, 0.42], "intensity": 95.0},
    ],
    "post": {
        "exposure": 2.05, "seed": 7,
        "ssao": {"radius": 0.45, "strength": 0.42},
        "haze": {"start": 6.0, "falloff": 18.0, "max": 0.55, "color": [0.16, 0.20, 0.27]},
        "dof": {"start": 5.0, "falloff": 9.0, "radius": 2.6},
        "grain": 0.012, "vignette": 0.32, "bloom": [[9, 0.55], [34, 0.35]],
    },
}


def build_plate(spec, out, material_mode):
    t0 = time.time()
    prims, mats, used = build(spec, material_mode)
    color, depth, pose, yfov, render_s = render(prims, spec)
    img = post(color, depth, spec, yfov)

    w, h = spec.get("size", [1080, 1920])
    feet = None
    if "feet_at" in spec:
        fx, fz = spec["feet_at"][0], spec["feet_at"][1]
        p = project(pose, yfov, w, h, [fx, float(spec.get("floor_y", 0.0)), fz])
        if p:
            feet = {"x": round(float(p[0]), 1), "y": round(float(p[1]), 1),
                    "distance_m": round(float(p[2]), 2)}

    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    Image.fromarray(img).save(out)
    sha = hashlib.sha256(open(out, "rb").read()).hexdigest()[:16]

    stats = measure(img)
    rec = {
        "location": spec.get("location", os.path.splitext(os.path.basename(out))[0]),
        "path": out, "size": [w, h], "engine": "%s/llvmpipe" % ENGINE,
        "materials": sorted(used),
        "material_sources": {k: mats[k].source for k in sorted(used)},
        "seed": spec.get("post", {}).get("seed", 7),
        "feet": feet,
        "render_s": round(render_s, 1),
        "total_s": round(time.time() - t0, 1),
        "sha256": sha,
    }
    rec.update(stats)
    return img, rec


def main(argv=None):
    ap = argparse.ArgumentParser(description="3D plate from a scene spec")
    ap.add_argument("--scene", help="scene spec JSON")
    ap.add_argument("--out", help="output PNG (default out/plates/<location>.png)")
    ap.add_argument("--record", default="build/plates.json", help="append a record here")
    ap.add_argument("--demo", action="store_true", help="write and render the demo scene")
    ap.add_argument("--probe", action="store_true", help="print engine capability JSON")
    ap.add_argument("--materials", choices=["auto", "procedural"], default="auto",
                    help="auto uses cached photo textures when present")
    args = ap.parse_args(argv)

    if args.probe:
        print(json.dumps({"engine": ENGINE,
                          "ok": ENGINE is not None,
                          "error": None if ENGINE else ENGINE_ERR,
                          "textures_cached": len(glob.glob(os.path.join(TEX_DIR, "*_diffuse.jpg"))),
                          "fallback": "references/world.md C.0 procedural plate"}))
        return 0

    if ENGINE is None:
        print("no 3D engine: %s" % ENGINE_ERR, file=sys.stderr)
        print("fall back to the vector plate in references/world.md C.0", file=sys.stderr)
        return 3

    if args.demo:
        os.makedirs("build/scenes", exist_ok=True)
        json.dump(DEMO, open("build/scenes/demo.json", "w"), indent=1)
        spec = DEMO
    elif args.scene:
        spec = json.load(open(args.scene))
    else:
        ap.error("give --scene FILE or --demo")

    out = args.out or os.path.join("out", "plates", "%s.png" % spec.get("location", "plate"))
    img, rec = build_plate(spec, out, args.materials)

    os.makedirs(os.path.dirname(args.record) or ".", exist_ok=True)
    data = {}
    if os.path.exists(args.record):
        try:
            data = json.load(open(args.record))
        except Exception:
            data = {}
    if isinstance(data, list):
        data = {r.get("location", str(i)): r for i, r in enumerate(data)}
    data[rec["location"]] = rec
    json.dump(data, open(args.record, "w"), indent=1)

    print("%-34s %dx%d  feet %s  flat %.2f  contrast %.2f  hues %d  %.1fs"
          % (out, rec["size"][0], rec["size"][1],
             ("y=%s x=%s" % (rec["feet"]["y"], rec["feet"]["x"])) if rec["feet"] else "—",
             rec["flat_coverage"], rec["contrast"], rec["hue_clusters"], rec["total_s"]))
    print("recorded in %s (sha %s)" % (args.record, rec["sha256"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
