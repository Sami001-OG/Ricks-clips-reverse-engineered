#!/usr/bin/env python3
"""Turn a voiceover into word timings and a caption track — no model required.

The problem this solves: in a sandbox with no ASR model (Hugging Face blocked, no
Whisper download), you cannot invent word timings, and you must not silently guess.
This script gets the best timings the audio actually supports, tells you which mode
it used, and refuses to write captions it cannot justify.

Modes, best first (--mode auto picks the first one available):

  srt       A real SRT/VTT was supplied. Cue times are exact; words are spread
            inside each cue. Highest fidelity, zero inference.
  asr       A local model is importable (faster-whisper, openai-whisper, vosk).
            Real word timings. Fails over cleanly if the model cannot download.
  align     Transcript supplied, no model. Forced alignment: speech is segmented
            from the energy envelope, sentences are distributed over segments by
            duration-vs-syllable matching, and every internal word boundary is
            snapped to the nearest local energy minimum. This is not a guess
            spread evenly — boundaries land on the pauses that actually exist.
  estimate  Transcript supplied, --mode estimate. Even syllable spread inside each
            segment, no snapping. Every caption is flagged est:true. Only when the
            user explicitly asks for estimates.
  segments  No text at all. Writes build/segments.json and exits 2 with a table of
            speech segments, so the only question left to ask is "paste the
            transcript". It never writes captions.json in this mode.

Usage:
  python3 scripts/vo_timing.py voice.mp3 --transcript script.txt
  python3 scripts/vo_timing.py voice.mp3 --srt captions.srt
  python3 scripts/vo_timing.py voice.mp3                      # tells you what's missing
  python3 scripts/vo_timing.py voice.mp3 --transcript t.txt --mode estimate

Outputs (into --out, default build/):
  segments.json  speech segments with dB
  words.json     one entry per word: w, start, end, seg, conf, est
  captions.json  1-4 word groups with start/end, ready for caption_cards.py
  audio.json     duration, sample rate, mode, warnings — the provenance record
"""
from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import subprocess
import sys

import numpy as np

SR = 16000          # 16 kHz mono: enough for energy VAD, cheap to decode
FRAME = 320         # 20 ms analysis window
HOP = 160           # 10 ms hop -> 10 ms boundary resolution
MIN_SPEECH = 0.08   # shorter than this is a click, not a word
MIN_SILENCE = 0.14  # shorter than this is an inter-word gap, not a pause
PAD = 0.03          # segment padding so the first phoneme is not clipped
COMFORT = 878       # 900 px caption box minus the 11 px stroke on both sides
SIZE, STROKE = 70, 11
BASELINE = 1376

WORD_CHARS = re.compile(r"[A-Za-z']+")


# --------------------------------------------------------------------------- io

def ffmpeg_exe():
    exe = shutil.which("ffmpeg")
    if exe:
        return exe
    try:
        import imageio_ffmpeg
        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def decode(path):
    exe = ffmpeg_exe()
    if not exe:
        raise SystemExit("ffmpeg not found — install it (bash scripts/bootstrap.sh).")
    cmd = [exe, "-v", "error", "-i", path, "-ac", "1", "-ar", str(SR), "-f", "s16le", "-"]
    proc = subprocess.run(cmd, capture_output=True)
    if proc.returncode != 0:
        raise SystemExit("could not decode %s:\n%s" % (path, proc.stderr.decode("utf-8", "replace")[:400]))
    x = np.frombuffer(proc.stdout, dtype="<i2").astype(np.float32) / 32768.0
    if x.size < SR // 10:
        raise SystemExit("audio shorter than 100 ms — nothing to time")
    return x


def envelope(x):
    """Per-hop RMS in dB. Time of hop i is i * HOP / SR."""
    n = 1 + max(0, (len(x) - FRAME) // HOP)
    idx = np.arange(FRAME)[None, :] + HOP * np.arange(n)[:, None]
    frames = x[idx]
    rms = np.sqrt((frames ** 2).mean(axis=1) + 1e-12)
    return 20.0 * np.log10(rms + 1e-9)


def hop_time(i):
    return i * HOP / float(SR)


# ------------------------------------------------------------------------- vad

def find_segments(db, min_speech=MIN_SPEECH, min_silence=MIN_SILENCE,
                  rel_hi=0.35, rel_lo=0.22, pad=PAD):
    """Hysteresis VAD: `lo` decides where speech extends, `hi` decides it exists.

    Two thresholds, because a single one either clips quiet consonants or lets
    breaths through. Runs of `above lo` that never reach `hi` are discarded as
    noise; runs separated by less than `min_silence` are merged as one phrase.
    """
    noise = float(np.percentile(db, 15))
    peak = float(np.percentile(db, 95))
    spread = peak - noise
    if spread < 6.0:
        return [], {"noise_db": noise, "peak_db": peak,
                    "warn": "no speech dynamics: peak-noise is %.1f dB (<6). "
                            "Is this music, silence, or a very quiet recording?" % spread}

    hi = noise + rel_hi * spread
    lo = noise + rel_lo * spread
    mask = db >= lo

    runs, i, n = [], 0, len(mask)
    while i < n:
        if mask[i]:
            j = i
            while j + 1 < n and mask[j + 1]:
                j += 1
            runs.append([i, j])
            i = j + 1
        else:
            i += 1

    merged = []
    for a, b in runs:
        if merged and (a - merged[-1][1] - 1) * HOP / SR < min_silence:
            merged[-1][1] = b
        else:
            merged.append([a, b])

    segs = []
    for a, b in merged:
        if (b - a + 1) * HOP / SR < min_speech:
            continue
        if float(db[a:b + 1].max()) < hi:
            continue
        start = max(0.0, a * HOP / SR - pad)
        end = min(len(db) * HOP / SR, (b + 1) * HOP / SR + pad)
        segs.append({"i": len(segs), "start": round(start, 3), "end": round(end, 3),
                     "dur": round(end - start, 3),
                     "db": round(float(db[a:b + 1].mean()), 1)})
    return segs, {"noise_db": round(noise, 1), "peak_db": round(peak, 1),
                  "threshold_hi": round(hi, 1), "threshold_lo": round(lo, 1)}


# -------------------------------------------------------------------- text math

def syllables(word):
    """Cheap, deterministic syllable count. Good enough for duration weighting;
    words are never split by it, only proportioned."""
    w = word.lower().strip(".,!?;:\"()[]—-")
    if not w:
        return 1
    digits = len(re.findall(r"\d", w))
    if digits:
        return max(1, digits)
    groups = re.findall(r"[aeiouy]+", w)
    n = len(groups)
    if n > 1 and w.endswith("e") and not w.endswith(("le", "ee")):
        n -= 1
    return max(1, n)


def tokenize(text):
    return [t for t in re.split(r"\s+", text.strip()) if t]


def sentences(text):
    """Sentence-ish units: split on terminal punctuation and line breaks.
    Returns a list of token lists. Empty input -> []."""
    out = []
    for chunk in re.split(r"(?<=[.!?…])\s+|\n+", text.strip()):
        toks = tokenize(chunk)
        if toks:
            out.append(toks)
    return out


def is_break_after(tok):
    return bool(re.search(r"[.!?…,;:]$", tok))


def srt_ts(s):
    s = s.strip().replace(",", ".")
    h, m, rest = s.split(":")
    return int(h) * 3600 + int(m) * 60 + float(rest)


def parse_srt(path):
    """SRT or VTT -> [(start, end, text)]. Cue times are exact; word times inside
    a cue are interpolated (the only thing a cue does not tell us)."""
    raw = open(path, encoding="utf-8-sig").read().replace("\r\n", "\n")
    cues = []
    for block in re.split(r"\n\s*\n", raw):
        m = re.search(r"(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3})\s*-->\s*(\d{1,2}:\d{2}:\d{2}[.,]\d{1,3})", block)
        if not m:
            continue
        text = " ".join(l for l in block.split("\n")
                        if "-->" not in l and not re.fullmatch(r"\d+", l.strip())
                        and not l.strip().upper().startswith(("WEBVTT", "NOTE")))
        text = re.sub(r"<[^>]+>", "", text).strip()
        if text:
            cues.append((srt_ts(m.group(1)), srt_ts(m.group(2)), text))
    return sorted(cues, key=lambda c: c[0])


# ------------------------------------------------------------------ alignment

def distribute(words, t0, t1):
    """Spread tokens across [t0,t1] by syllable weight. Returns [(w, start, end)]."""
    if not words or t1 <= t0:
        return []
    wts = [syllables(w) for w in words]
    total = float(sum(wts))
    span = (t1 - t0) / total
    out, cur = [], t0
    for w, wt in zip(words, wts):
        d = span * wt
        out.append([w, cur, cur + d])
        cur += d
    out[-1][2] = t1
    return out


def assign_sentences_blocks(sents, segs):
    """Partition sentences over segments, monotonic and contiguous, minimising the
    mismatch between each segment's share of speech time and its share of
    syllables. Handles 30 sentences over 30 segments, and 3 sentences inside one
    long segment, with the same code."""
    S, G = len(sents), len(segs)
    syl = [sum(syllables(w) for w in s) for s in sents]
    tot_syl = float(sum(syl)) or 1.0
    tot_dur = float(sum(s["dur"] for s in segs)) or 1.0

    def cost(i, j, k):                       # sentences i..j-1 -> segment k
        share_txt = sum(syl[i:j]) / tot_syl
        share_dur = segs[k]["dur"] / tot_dur
        return abs(share_txt - share_dur) * 1000.0

    INF = float("inf")
    dp = [[INF] * (S + 1) for _ in range(G + 1)]
    back = [[None] * (S + 1) for _ in range(G + 1)]
    dp[0][0] = 0.0
    for k in range(1, G + 1):
        for j in range(S + 1):
            lo = 0 if (S < G) else max(0, j - (S - (G - k)))
            for i in range(lo, j + 1):
                if dp[k - 1][i] == INF:
                    continue
                c = dp[k - 1][i] + cost(i, j, k - 1)
                if c < dp[k][j]:
                    dp[k][j] = c
                    back[k][j] = i
    if dp[G][S] == INF:                      # cannot happen with lo=0, kept as a guard
        return [[(0, [s])] for s in sents][:G]

    blocks, j = [], S
    for k in range(G, 0, -1):
        i = back[k][j]
        blocks.append((i, j))
        j = i
    blocks.reverse()
    return [[t for s in sents[a:b] for t in s] for a, b in blocks]


def snap(db, pred, lo, hi, frac=0.30, floor=0.04, ceil=0.25):
    """Move a predicted boundary to the middle of the quietest run nearby — the
    pause the speaker actually made. Midpoint, not the first low hop: cutting a
    caption at the instant the voice drops clips the tail of the previous word.
    Returns (time, confidence 0..1, valley_depth_db)."""
    w = min(ceil, max(floor, frac * min(pred - lo, hi - pred)))
    a = int(max(0, math.floor((pred - w) * SR / HOP)))
    b = int(min(len(db) - 1, math.ceil((pred + w) * SR / HOP)))
    if b <= a:
        return pred, 0.0, 0.0
    window = db[a:b + 1]
    k = int(np.argmin(window))
    floor_db = float(window[k])
    i, j = k, k
    while i > 0 and window[i - 1] <= floor_db + 3.0:   # 3 dB: the same pause, not a new one
        i -= 1
    while j < len(window) - 1 and window[j + 1] <= floor_db + 3.0:
        j += 1
    t = (a + (i + j) / 2.0) * HOP / float(SR)
    t = min(max(t, lo + 0.03), hi - 0.03)
    pred_db = float(np.interp(pred, [i * HOP / float(SR) for i in (a, b)], [db[a], db[b]]))
    depth = pred_db - floor_db
    conf = max(0.0, min(1.0, 1.0 - abs(t - pred) / (w + 1e-9)))
    return t, conf, max(0.0, depth)


def align_text(db, segs, text, do_snap=True):
    """Place words inside their own segment and snap only *internal* boundaries.

    Segment edges are already real silences measured by the VAD, so a boundary
    between two segments must never be dragged into the gap: one word would end
    late and the next would start early, and the caption would hang through the
    pause.
    """
    sents = sentences(text)
    if not sents:
        return [], {"warn": "transcript has no words"}
    blocks = assign_sentences_blocks(sents, segs)

    words, snaps, depths = [], 0, []
    for seg, toks in zip(segs, blocks):
        if not toks:
            # a segment with no text: music sting, breath, or a mis-detected run
            continue
        spread = distribute(toks, seg["start"], seg["end"])
        if do_snap and len(spread) > 1:
            for i in range(len(spread) - 1):
                a, b = spread[i], spread[i + 1]
                t, conf, depth = snap(db, b[1], a[1], b[2])
                a[2] = t
                b[1] = t
                if depth >= 3.0:
                    snaps += 1
                depths.append(depth)
                spread[i].append(conf)
        for row in spread:
            conf = row[3] if len(row) > 3 else 0.5
            words.append({"w": row[0], "start": row[1], "end": row[2], "seg": seg["i"],
                          "conf": round(conf, 2) if do_snap else 0.0,
                          "est": not do_snap})

    if not words:
        return [], {"warn": "no words placed"}

    return words, {"snapped": snaps, "boundaries": len(depths),
                   "mean_valley_db": round(float(np.mean(depths)), 1) if depths else 0.0}


# ------------------------------------------------------------------- captions

def text_px(s):
    try:
        from PIL import ImageFont
        root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
        f = ImageFont.truetype(os.path.join(root, "assets", "fonts", "Montserrat-ExtraBold.ttf"), SIZE)
        return float(f.getlength(s))
    except Exception:
        return len(s) * SIZE * 0.55      # conservative fallback: no font, still bounded


def group(words, max_words=4, max_px=COMFORT, gap_cut=0.25):
    """1-4 words per caption, broken on punctuation, pauses and segment edges —
    never on a fixed timer, and never across a silence longer than gap_cut."""
    groups, cur = [], []
    for i, w in enumerate(words):
        nxt = words[i + 1] if i + 1 < len(words) else None
        if cur:
            trial = " ".join([c["w"] for c in cur] + [w["w"]])
            too_wide = text_px(trial) + 2 * STROKE > 900
            gap = w["start"] - cur[-1]["end"]
            new_seg = w["seg"] != cur[-1]["seg"]
            if too_wide or len(cur) >= max_words or gap > gap_cut or (new_seg and gap > 0.12):
                groups.append(cur)
                cur = []
            elif is_break_after(cur[-1]["w"]):
                groups.append(cur)
                cur = []
        cur.append(w)
        if nxt is None:
            groups.append(cur)
            cur = []
    if cur:
        groups.append(cur)
    return groups


def to_cards(groups, lead=0.04, hold=0.08, min_show=0.20, join_gap=0.30):
    cards = []
    for g in groups:
        text = " ".join(w["w"] for w in g)
        start = max(0.0, g[0]["start"] - lead)
        end = g[-1]["end"] + hold
        if end - start < min_show:
            end = start + min_show
        cards.append({"text": text, "start": round(start, 3), "end": round(end, 3),
                      "words": [g[0]["w"], g[-1]["w"]],
                      "est": any(w.get("est") for w in g)})
    for a, b in zip(cards, cards[1:]):
        # hold a caption through a short gap so the screen does not flicker, but
        # let it clear across a real sentence pause (0.3s+)
        if b["start"] - a["end"] <= join_gap and b["start"] > a["start"]:
            a["end"] = b["start"]
    for a, b in zip(cards, cards[1:]):
        if a["end"] > b["start"]:
            a["end"] = b["start"]
    return cards


# ----------------------------------------------------------------------- asr

def try_asr(audio, model_size="small.en", language="en"):
    """Returns (words, note) or (None, why). Never raises, never hangs on a
    blocked download beyond the library's own timeout."""
    try:
        from faster_whisper import WhisperModel
        m = WhisperModel(model_size, device="cpu", compute_type="int8")
        segs, _ = m.transcribe(audio, language=language, word_timestamps=True, vad_filter=True)
        out = []
        for s in segs:
            for w in (s.words or []):
                out.append({"w": w.word.strip(), "start": float(w.start),
                            "end": float(w.end), "seg": -1, "conf": 0.9, "est": False})
        if out:
            return out, "faster-whisper %s" % model_size
    except Exception as e:
        note = "faster-whisper: %s" % str(e).split("\n")[0][:160]
    else:
        note = "faster-whisper: no words returned"

    try:
        import whisper
        m = whisper.load_model(model_size)
        r = m.transcribe(audio, language=language, word_timestamps=True)
        out = [{"w": w["word"].strip(), "start": float(w["start"]), "end": float(w["end"]),
                "seg": -1, "conf": 0.9, "est": False}
               for s in r.get("segments", []) for w in s.get("words", [])]
        if out:
            return out, "openai-whisper %s" % model_size
        note += " | openai-whisper: no words"
    except Exception as e:
        note += " | openai-whisper: %s" % str(e).split("\n")[0][:120]

    return None, note


# ---------------------------------------------------------------------- main

def main(argv=None):
    ap = argparse.ArgumentParser(description="voiceover -> word timings -> captions")
    ap.add_argument("audio")
    ap.add_argument("--transcript", help="plain text of what is said (enables forced alignment)")
    ap.add_argument("--srt", help="SRT/VTT with real cue times (best)")
    ap.add_argument("--mode", default="auto",
                    choices=["auto", "srt", "asr", "align", "estimate", "segments"])
    ap.add_argument("--model", default="small.en", help="ASR model size when one is available")
    ap.add_argument("--out", default="build")
    ap.add_argument("--max-words", type=int, default=4)
    ap.add_argument("--min-silence", type=float, default=MIN_SILENCE)
    ap.add_argument("--gap-cut", type=float, default=0.25)
    args = ap.parse_args(argv)

    os.makedirs(args.out, exist_ok=True)
    os.makedirs("analysis", exist_ok=True)

    x = decode(args.audio)
    duration = len(x) / float(SR)
    db = envelope(x)
    segs, vad = find_segments(db, min_silence=args.min_silence)

    text = open(args.transcript, encoding="utf-8-sig").read() if args.transcript else ""
    srt_cues = parse_srt(args.srt) if args.srt else []

    mode = args.mode
    if mode == "auto":
        mode = "srt" if srt_cues else ("align" if text.strip() else "segments")

    words, note, warn = [], "", []
    if mode == "srt" and srt_cues:
        for s, e, t in srt_cues:
            for w, ws, we in distribute(tokenize(t), s, e):
                words.append({"w": w, "start": ws, "end": we, "seg": -1, "conf": 0.95, "est": False})
        note = "%d cues: cue times exact, words spread inside each cue" % len(srt_cues)
    elif mode == "asr":
        got, note = try_asr(args.audio, args.model)
        if got:
            words = got
        else:
            warn.append("ASR unavailable (%s); fell back to forced alignment" % note)
            mode = "align" if text.strip() else "segments"
    if mode == "segments":
        pass
    elif mode in ("align", "estimate"):
        if not text.strip():
            warn.append("--mode %s needs --transcript; nothing to align" % mode)
            mode = "segments"
        else:
            if not segs:
                raise SystemExit("no speech segments found — check the audio")
            words, stats = align_text(db, segs, text, do_snap=(mode == "align"))
            if "warn" in stats:
                warn.append(stats["warn"])
            if mode == "align":
                note = ("forced alignment: %d segments, %d boundaries snapped to energy "
                        "valleys" % (len(segs), stats.get("snapped", 0)))
            else:
                note = "estimated spread by syllable weight (est:true on every caption)"
                warn.append("captions are ESTIMATED and may drift by a few frames")

    if not segs:
        warn.append("no speech detected (silence, music, or clipping?)")

    payload = {"audio": args.audio, "duration": round(duration, 3), "mode": mode,
               "note": note, "segments": len(segs), "words": len(words),
               "vad": vad, "warnings": warn}

    if words and mode != "segments":
        groups = group(words, max_words=args.max_words, gap_cut=args.gap_cut)
        cards = to_cards(groups)
        payload["captions"] = len(cards)
        payload["mean_conf"] = round(float(np.mean([w["conf"] for w in words])), 2)
        payload["longest_word_s"] = round(max(w["end"] - w["start"] for w in words), 2)
        json.dump(words, open(os.path.join(args.out, "words.json"), "w"), indent=1)
        json.dump(cards, open(os.path.join(args.out, "captions.json"), "w"), indent=1)
    elif mode == "segments":
        payload["captions"] = 0
        payload["next"] = ("ask for the transcript — one question, not a menu: "
                           "'paste the words you said (or an SRT) and I'll place captions'")
        payload["segments_table"] = [{"i": s["i"], "start": s["start"], "end": s["end"],
                                      "dur": s["dur"]} for s in segs]

    json.dump(segs, open(os.path.join(args.out, "segments.json"), "w"), indent=1)
    json.dump(payload, open(os.path.join(args.out, "audio.json"), "w"), indent=1)
    json.dump(payload, open(os.path.join("analysis", "vo_report.json"), "w"), indent=1)

    print(json.dumps(payload, indent=2))
    return 0 if words else 2


if __name__ == "__main__":
    raise SystemExit(main())
