#!/usr/bin/env python3
"""selftest.py — prove the elaboration and object gates actually fire.

Runs a synthetic "postmaster" voiceover end to end through the contracts (no
rendering): word timings -> elaborate -> shotlist -> both --check passes. Then
it corrupts the plan into one-location / one-shot-size and asserts the checks
FAIL. A gate that has never failed is not a gate.

    python3 scripts/selftest.py
"""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import tempfile

HERE = os.path.dirname(os.path.abspath(__file__))

VOICE = """The postmaster opened the post office before dawn.
He sorted every envelope and checked the stamp on each parcel.
The clerk weighed a package while a customer waited at the counter.
Then he locked the almirah and carried the mailbag outside."""


def run(script, *args, cwd=None):
    p = subprocess.run([sys.executable, os.path.join(HERE, script)] + list(args),
                       cwd=cwd, capture_output=True, text=True)
    return p.returncode, p.stdout + p.stderr


def make_inputs(d):
    os.makedirs(os.path.join(d, "build"), exist_ok=True)
    toks = VOICE.replace("\n", " ").split()
    total, t0 = 18.0, 0.12
    step = (total - 0.7) / len(toks)
    words = []
    for i, w in enumerate(toks):
        words.append({"w": w.strip(".,"), "start": round(t0 + i * step, 3),
                      "end": round(t0 + (i + 1) * step - 0.02, 3), "est": False})
    json.dump(words, open(os.path.join(d, "build", "words.json"), "w"), indent=1)

    caps, group = [], []
    for w in words:
        group.append(w["w"])
        if len(group) == 4:
            caps.append({"text": " ".join(group), "start": group and w["start"] - step * 3,
                         "end": w["end"]})
            group = []
    if group:
        caps.append({"text": " ".join(group), "start": caps[-1]["end"] if caps else 0.1,
                     "end": words[-1]["end"]})
    for i, c in enumerate(caps):
        c["start"] = round(max(0.05, i * (total - 0.8) / len(caps)), 3)
        c["end"] = round((i + 1) * (total - 0.8) / len(caps), 3)
        c["words"] = c["text"].split()
    json.dump(caps, open(os.path.join(d, "build", "captions.json"), "w"), indent=1)
    json.dump({"duration": total, "mode": "align", "words": len(words)},
              open(os.path.join(d, "build", "audio.json"), "w"), indent=1)
    open(os.path.join(d, "script.txt"), "w").write(VOICE + "\n")


def main():
    d = tempfile.mkdtemp(prefix="rick-elab-selftest-")
    results = []

    def check(name, cond, detail=""):
        results.append((name, bool(cond), detail))
        print(("  PASS  " if cond else "  FAIL  ") + name + ((" — " + detail) if detail else ""))

    try:
        make_inputs(d)
        cmd = ["--voice", "script.txt", "--words", "build/words.json",
               "--captions", "build/captions.json", "--audio", "build/audio.json",
               "--domain", "post_office", "--detail", "3"]

        print("== encoder profile: fastest working path is usable ==")
        rc, out = run("fastencode.py", "--check", cwd=d)
        check("encoder profile probe", rc == 0 and "works" in out, out.strip().splitlines()[-1] if out else "")

        print("== 3D props: sprites ship and resolve ==")
        rc, out = run("prop3d.py", "--probe", cwd=d)
        assets = os.path.join(os.path.dirname(HERE), "assets",
                              "props", "3d")
        sprites = os.path.isdir(assets) and all(
            os.path.exists(os.path.join(assets, k + ".png")) for k in ("bag", "phone", "mail"))
        check("3D prop engine + shipped sprites", rc == 0 and sprites,
              out.strip().replace("\n", " "))
        sys.path.insert(0, HERE)
        import prop3d, puppet
        check("prop alias maps in sync",
              prop3d.ALIAS == puppet.PROP3D_ALIAS,
              "%d vs %d" % (len(prop3d.ALIAS), len(puppet.PROP3D_ALIAS)))
        sk = puppet.build_rig({"id": "h", "height_px": 700, "body": "capsule",
                               "hair_kind": "short",
                               "hex": {"garment": "#C8282C", "accent": "#E0B020", "hat": "#222"}})
        embedded = puppet.prop3d_svg("bag", (540, 1400), 0, 1.0, sk["height"])
        check("3D sprite embeds at hand socket",
              bool(embedded) and "data:image/png;base64" in embedded)

        print("== measurement blockers: sheets + SFX ==")
        sheets = os.path.join(d, "sheets")
        json.dump([{"id": "hero", "height_px": 700, "body": "capsule",
                    "hair_kind": "short",
                    "hex": {"garment": "#C8282C", "accent": "#E0B020", "hat": "#222222"}}],
                  open(os.path.join(d, "build", "sheet_card.json"), "w"))
        rc, out = run("make_sheet.py", "--chars", os.path.join(d, "build", "sheet_card.json"),
                      "--out", sheets, cwd=d)
        ok = (rc == 0 and os.path.exists(os.path.join(sheets, "hero", "sheet.png"))
              and len([f for f in os.listdir(os.path.join(sheets, "hero"))
                       if f.startswith("sheet_")]) >= 8)
        check("character sheet + pose masks", ok, out.strip().splitlines()[-1] if out else "")
        rc, out = run("make_sfx.py", "--audio", "build/audio.json",
                      "--captions", "build/captions.json", "--out", "build/sfx.wav", cwd=d)
        check("deterministic SFX bed", rc == 0 and
              os.path.getsize(os.path.join(d, "build", "sfx.wav")) > 1000,
              out.strip().splitlines()[-1] if out else "")

        print("== positive: postmaster VO elaborates into a post office ==")
        rc, out = run("elaborate.py", *cmd, cwd=d)
        check("elaborate draft", rc == 0, out.strip().splitlines()[-1] if out else "")
        bible = json.load(open(os.path.join(d, "build", "story_bible.json")))
        check("domain detected", bible["domain"] == "post_office", bible["domain"])
        check("three locations", len(bible["locations"]) == 3,
              ", ".join(l["id"] for l in bible["locations"]))
        oids = {o["id"] for o in bible["objects"]}
        need = {"envelope", "counter", "cabinet", "stamp", "scale", "bag", "parcel"}
        check("story objects authored", need <= oids, ", ".join(sorted(need - oids)) or "all present")
        roles = {c["role"] for c in bible["cast"]}
        check("cast invented", {"postmaster", "counter clerk", "customer"} <= roles,
              ", ".join(sorted(roles)))
        fr = {e["framing"] for e in bible["expanded_script"]}
        check("four or more shot sizes", len(fr) >= 4, "/".join(sorted(fr)))
        check("insert present", any(e["framing"] == "insert" for e in bible["expanded_script"]))
        sigs = [l["theme"]["signature"] for l in bible["locations"]]
        check("distinct theme per location", len(set(sigs)) == len(sigs), str(len(set(sigs))))
        acts = [e["action"] for e in bible["expanded_script"]]
        check("distinct actions across shots", len(set(acts)) >= 4, "%d actions" % len(set(acts)))
        check("no 3 repeated actions", all(not (i >= 2 and acts[i] == acts[i-1] == acts[i-2])
                                           for i in range(len(acts))))
        check("every shot has all eight atoms",
              all(len(e["atoms"]) == 8 and all(e["atoms"].values())
                  for e in bible["expanded_script"]))
        check("no unclassified words", not bible["unclassified"],
              ", ".join(bible["unclassified"][:5]))

        print("== shotlist accepts the drafted contracts ==")
        rc, out = run("shotlist.py", "build/captions.json", "--audio", "build/audio.json", cwd=d)
        check("shotlist build", rc == 0)
        rc, out = run("shotlist.py", "build/captions.json", "--audio", "build/audio.json",
                      "--fill", "build/beats.tsv", cwd=d)
        check("8-column beat table fills every shot", rc == 0, out.strip())
        rc, out = run("shotlist.py", "build/captions.json", "--audio", "build/audio.json",
                      "--check", "--objects", "build/objects.json",
                      "--words", "build/words.json", cwd=d)
        check("shotlist --check PASS", rc == 0 and out.strip().endswith("PASS"),
              out.strip().splitlines()[-1] if out else "")
        rc, out = run("elaborate.py", "--check", "build/story_bible.json",
                      "--words", "build/words.json", "--shotlist", "build/shotlist.json", cwd=d)
        check("elaborate --check PASS", rc == 0 and out.strip().endswith("PASS"),
              out.strip().splitlines()[-1] if out else "")

        print("== prop parenting: contract must reach anim.json ==")
        shots = json.load(open(os.path.join(d, "build", "shotlist.json")))
        objs = json.load(open(os.path.join(d, "build", "objects.json")))["objects"]
        hand = {o["id"]: o["make"][7:] for o in objs if o.get("make", "").startswith("puppet:")}
        anim = [{"shot": s["id"],
                 "actors": [{"id": "postmaster",
                             "props": [{"id": hand[oid]} for oid in s.get("objects", [])
                                       if oid in hand]}]} for s in shots]
        json.dump(anim, open(os.path.join(d, "build", "anim.json"), "w"), indent=1)
        rc, out = run("elaborate.py", "--check", "build/story_bible.json",
                      "--words", "build/words.json", "--shotlist", "build/shotlist.json",
                      "--anim", "build/anim.json", cwd=d)
        check("props parented -> PASS", rc == 0 and out.strip().endswith("PASS"),
              out.strip().splitlines()[-1] if out else "")
        for a in anim:
            a["actors"][0]["props"] = []
        json.dump(anim, open(os.path.join(d, "build", "anim.json"), "w"), indent=1)
        rc, out = run("elaborate.py", "--check", "build/story_bible.json",
                      "--words", "build/words.json", "--shotlist", "build/shotlist.json",
                      "--anim", "build/anim.json", cwd=d)
        check("props dropped -> FAIL", rc != 0 and "not in anim.json" in out,
              " | ".join(x for x in out.splitlines() if x.startswith("FAIL"))[:140])
        os.remove(os.path.join(d, "build", "anim.json"))

        print("== negative: the same gate must reject a one-location, one-size plan ==")
        bad = os.path.join(d, "bad_shotlist.json")
        shots = json.load(open(os.path.join(d, "build", "shotlist.json")))
        for s in shots:
            s["scene"] = "one_bare_room"
            s["framing"] = "medium"
            s["objects"] = []
        json.dump(shots, open(bad, "w"), indent=1)
        rc, out = run("elaborate.py", "--check", "build/story_bible.json",
                      "--words", "build/words.json", "--shotlist", bad, cwd=d)
        check("single place / size rejected", rc != 0 and
              ("only 1 distinct location" in out or "shot size" in out),
              " | ".join(x for x in out.splitlines() if x.startswith("FAIL"))[:160])

        for s in shots:
            s["scene"] = "one_bare_room"
        json.dump(shots, open(bad, "w"), indent=1)
        rc, out = run("shotlist.py", "build/captions.json", "--audio", "build/audio.json",
                      "--check", "--out", bad, "--objects", "build/objects.json",
                      "--words", "build/words.json", cwd=d)
        check("shotlist variety gate rejects it", rc != 0 and ("location" in out.lower() or "shot size" in out),
              " | ".join(x for x in out.splitlines() if x.startswith("FAIL"))[:160])

        print("== negative: diverged FINAL plan must fail, not just the bible ==")
        final = json.load(open(os.path.join(d, "build", "shotlist.json")))
        for s in final:
            s["action"] = "holds still"
            s["theme"] = "same|same|same|same"
        fp = os.path.join(d, "bad_final.json")
        json.dump(final, open(fp, "w"), indent=1)
        rc, out = run("elaborate.py", "--check", "build/story_bible.json",
                      "--words", "build/words.json", "--shotlist", fp, cwd=d)
        check("final action/theme divergence rejected", rc != 0 and
              ("distinct action" in out or "theme signature" in out),
              " | ".join(x for x in out.splitlines() if x.startswith("FAIL"))[:150])
    finally:
        shutil.rmtree(d, ignore_errors=True)

    fails = [n for n, ok, _ in results if not ok]
    print("\n%d/%d passed" % (len(results) - len(fails), len(results)))
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
