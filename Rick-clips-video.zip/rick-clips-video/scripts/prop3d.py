#!/usr/bin/env python3
"""prop3d.py — render hand props as real 3D objects with alpha.

The old prop path drew flat SVG cutouts (bag, phone, envelope...). This tool
builds the same props from 3D primitives, lights them with the same key/fill
logic as the plates, and writes transparent PNG sprites. `puppet.py` embeds
those sprites at the hand socket, so a held object is lit and shaped in 3D
while the actor stays a flat outlined cutout.

    python3 scripts/prop3d.py --build              # all canonical props
    python3 scripts/prop3d.py --kind phone --build # one prop
    python3 scripts/prop3d.py --list               # alias -> sprite map
    python3 scripts/prop3d.py --probe              # is the 3D engine usable?

Sprites are cached by kind + renderer; the 2D `prop_svg` path remains as an
automatic fallback when pyrender or a sprite is unavailable.
"""
from __future__ import annotations

import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import numpy as np
from PIL import Image

import plate3d

OUT = os.path.join(os.path.dirname(HERE), "assets", "props", "3d")

# Every accepted puppet prop kind -> canonical 3D build recipe.
ALIAS = {
    "bag": "bag", "handbag": "bag", "tote": "bag", "backpack": "backpack", "rucksack": "backpack",
    "phone": "phone", "mobile": "phone", "smartphone": "phone",
    "envelope": "mail", "mail": "mail", "letter": "mail", "note": "mail",
    "parcel": "parcel", "package": "parcel", "box": "parcel",
    "cup": "cup", "mug": "cup", "coffee": "cup", "tray": "tray", "plate": "tray",
    "clipboard": "clipboard", "board": "clipboard", "book": "book", "notebook": "book",
    "key": "key", "stamp": "stamp", "stamp_book": "stamp_book", "booklet": "stamp_book",
    "ticket": "ticket", "bottle": "bottle", "water_bottle": "bottle", "umbrella": "umbrella",
    "hammer": "hammer", "pickaxe": "pickaxe", "pan": "pan", "fuse": "fuse",
    "flag": "flag", "lantern": "lantern", "scale": "scale", "weighing_scale": "scale",
}
CANON = sorted(set(ALIAS.values()))


def _mats():
    return {
        "leather": {"solid": True, "color": [0.40, 0.23, 0.13], "roughness": 0.72, "tile": 0.15},
        "leather_dark": {"solid": True, "color": [0.24, 0.13, 0.08], "roughness": 0.78, "tile": 0.15},
        "paper": {"solid": True, "color": [0.90, 0.86, 0.75], "roughness": 0.95, "tile": 0.12},
        "ink": {"solid": True, "color": [0.10, 0.11, 0.14], "roughness": 0.42, "tile": 0.10},
        "screen": {"emissive": [2.6, 3.4, 4.2], "color": [0.46, 0.66, 0.86]},
        "glass": {"solid": True, "color": [0.10, 0.13, 0.17], "roughness": 0.18,
                  "metallic": 0.35, "tile": 0.1},
        "card": {"solid": True, "color": [0.58, 0.42, 0.26], "roughness": 0.92, "tile": 0.12},
        "metal": {"solid": True, "color": [0.61, 0.63, 0.66], "roughness": 0.34,
                  "metallic": 0.85, "tile": 0.1},
        "brass": {"solid": True, "color": [0.72, 0.55, 0.25], "roughness": 0.33,
                  "metallic": 0.9, "tile": 0.1},
        "wood": {"solid": True, "color": [0.45, 0.29, 0.16], "roughness": 0.68, "tile": 0.12},
        "fabric": {"solid": True, "color": [0.20, 0.30, 0.44], "roughness": 0.94, "tile": 0.12},
        "red": {"solid": True, "color": [0.70, 0.18, 0.14], "roughness": 0.6, "tile": 0.1},
        "glow": {"emissive": [5.0, 3.0, 1.2], "color": [1.0, 0.72, 0.38]},
        "white": {"solid": True, "color": [0.88, 0.88, 0.86], "roughness": 0.8, "tile": 0.1},
    }


def box(c, s, m):
    return {"type": "box", "center": list(c), "size": list(s), "material": m}


def cyl(c, r, h, m, axis="y"):
    return {"type": "cylinder", "center": list(c), "radius": r, "height": h,
            "material": m, "axis": axis, "segments": 20}


def sph(c, r, m):
    return {"type": "sphere", "center": list(c), "radius": r, "material": m, "segments": 16}


def cone(c, r, h, m):
    return {"type": "cone", "center": list(c), "radius": r, "height": h,
            "material": m, "segments": 20}


def quad(pts, m, eye=(0, 0, 5)):
    return {"type": "quad", "points": [list(p) for p in pts], "material": m, "seen_from": list(eye)}


def arc(cx, cy, r, steps, m, w=0.018):
    """Semicircular handle from small boxes (no torus primitive needed)."""
    out = []
    import math
    for i in range(steps):
        a = math.pi * (i + 0.5) / steps
        out.append(box((cx + r * math.cos(a), cy + r * math.sin(a), 0),
                       (w * 2.2, w, w), m))
    return out


def recipe(kind):
    g = []
    if kind == "bag":
        g += [box((0, -0.07, 0), (0.42, 0.30, 0.16), "leather"),
              box((0, 0.05, 0.085), (0.40, 0.12, 0.02), "leather_dark"),
              cyl((0, 0.01, 0.10), 0.018, 0.025, "brass", axis="z")]
        g += arc(-0.12, 0.08, 0.10, 5, "leather_dark") + arc(0.12, 0.08, 0.10, 5, "leather_dark")
    elif kind == "backpack":
        g += [box((0, -0.05, 0), (0.36, 0.42, 0.18), "fabric"),
              box((0, -0.10, 0.10), (0.26, 0.16, 0.03), "leather_dark"),
              box((-0.10, -0.02, 0.095), (0.035, 0.30, 0.02), "leather"),
              box((0.10, -0.02, 0.095), (0.035, 0.30, 0.02), "leather")]
        g += arc(0, 0.16, 0.09, 5, "leather")
    elif kind == "phone":
        g += [box((0, 0, 0), (0.20, 0.34, 0.024), "glass"),
              quad([(-0.084, 0.14, 0.014), (0.084, 0.14, 0.014),
                    (0.084, -0.13, 0.014), (-0.084, -0.13, 0.014)], "screen"),
              cyl((0, 0.156, 0.014), 0.007, 0.004, "metal", axis="z")]
    elif kind == "mail":
        g += [box((0, 0, 0), (0.38, 0.25, 0.012), "paper"),
              quad([(-0.19, 0.125, 0.008), (0, -0.01, 0.008),
                    (0.19, 0.125, 0.008), (0.19, 0.125, 0.008)], "white"),
              box((0.11, 0.075, 0.010), (0.07, 0.05, 0.003), "red"),
              box((0, -0.04, 0.010), (0.11, 0.006, 0.003), "ink")]
    elif kind == "parcel":
        g += [box((0, 0, 0), (0.36, 0.30, 0.26), "card"),
              box((0, 0, 0.132), (0.045, 0.31, 0.006), "paper"),
              box((0, 0.05, 0.135), (0.37, 0.045, 0.006), "paper"),
              box((-0.08, -0.08, 0.138), (0.14, 0.08, 0.004), "white")]
    elif kind == "cup":
        g += [cyl((0, -0.03, 0), 0.115, 0.24, "white"),
              cyl((0, 0.09, 0), 0.125, 0.02, "metal"),
              box((0.15, -0.02, 0), (0.07, 0.025, 0.025), "white"),
              box((0.19, -0.02, 0), (0.025, 0.13, 0.025), "white"),
              box((0.15, -0.09, 0), (0.07, 0.025, 0.025), "white")]
    elif kind == "tray":
        g += [cyl((0, 0, 0), 0.23, 0.018, "metal"),
              cyl((0, 0.006, 0), 0.245, 0.024, "brass")]
    elif kind == "clipboard":
        g += [box((0, 0, 0), (0.28, 0.40, 0.018), "wood"),
              box((0, -0.02, 0.012), (0.23, 0.32, 0.004), "paper"),
              box((0, 0.18, 0.016), (0.12, 0.035, 0.016), "metal")]
    elif kind == "key":
        g += [cyl((-0.13, 0, 0), 0.075, 0.018, "brass", axis="z"),
              box((0.04, 0, 0), (0.24, 0.028, 0.018), "brass"),
              box((0.13, -0.04, 0), (0.025, 0.055, 0.018), "brass"),
              box((0.19, -0.04, 0), (0.025, 0.055, 0.018), "brass")]
    elif kind == "book":
        g += [box((0, 0, -0.012), (0.30, 0.40, 0.02), "leather_dark"),
              box((0, 0, 0.012), (0.30, 0.40, 0.02), "leather"),
              box((0, 0, 0), (0.27, 0.37, 0.05), "paper"),
              box((-0.14, 0, 0), (0.012, 0.40, 0.06), "brass")]
    elif kind == "stamp":
        g += [cyl((0, 0.09, 0), 0.04, 0.20, "wood"),
              cone((0, -0.055, 0), 0.10, 0.08, "wood"),
              box((0, -0.10, 0), (0.13, 0.025, 0.13), "red")]
    elif kind == "stamp_book":
        g += [box((0, 0, 0), (0.28, 0.22, 0.016), "paper"),
              box((0, 0, -0.011), (0.30, 0.24, 0.008), "red")]
        for i in range(3):
            for j in range(2):
                g.append(box((-0.07 + i * 0.07, -0.045 + j * 0.07, 0.011),
                             (0.055, 0.055, 0.003), "white"))
    elif kind == "ticket":
        g += [box((0, 0, 0), (0.36, 0.18, 0.01), "paper"),
              box((-0.10, 0, 0.008), (0.10, 0.008, 0.003), "ink"),
              cyl((-0.17, 0, 0), 0.012, 0.004, "white", axis="z")]
    elif kind == "bottle":
        g += [cyl((0, -0.07, 0), 0.09, 0.32, "glass"),
              cone((0, 0.13, 0), 0.06, 0.10, "glass"),
              cyl((0, 0.21, 0), 0.045, 0.05, "brass"),
              box((0, -0.08, 0.091), (0.12, 0.10, 0.004), "white")]
    elif kind == "umbrella":
        g += [cone((0, 0.13, 0), 0.28, 0.20, "fabric"),
              cyl((0, -0.10, 0), 0.012, 0.38, "wood"),
              box((0.04, -0.28, 0), (0.09, 0.025, 0.025), "wood"),
              box((0.08, -0.24, 0), (0.025, 0.08, 0.025), "wood")]
    elif kind == "hammer":
        g += [cyl((0, -0.10, 0), 0.026, 0.34, "wood"),
              box((0, 0.10, 0), (0.24, 0.075, 0.075), "metal")]
    elif kind == "pickaxe":
        g += [cyl((0, -0.08, 0), 0.024, 0.38, "wood"),
              box((0, 0.12, 0), (0.32, 0.045, 0.045), "metal"),
              cone((-0.18, 0.12, 0), 0.04, 0.10, "metal")]
    elif kind == "pan":
        g += [cyl((0, 0, 0), 0.20, 0.05, "metal"),
              cyl((0.30, 0, 0), 0.022, 0.30, "wood", axis="x")]
    elif kind == "fuse":
        g += [cyl((0, -0.07, 0), 0.032, 0.26, "paper"),
              sph((0, 0.10, 0), 0.05, "glow")]
    elif kind == "flag":
        g += [cyl((-0.14, -0.04, 0), 0.014, 0.52, "wood"),
              quad([(-0.12, 0.22, 0), (0.16, 0.16, 0),
                    (-0.12, 0.02, 0), (-0.12, 0.02, 0)], "red")]
    elif kind == "lantern":
        g += [box((0, -0.03, 0), (0.24, 0.30, 0.20), "metal"),
              quad([(-0.09, 0.06, 0.101), (0.09, 0.06, 0.101),
                    (0.09, -0.09, 0.101), (-0.09, -0.09, 0.101)], "glow")]
        g += arc(0, 0.12, 0.09, 5, "metal")
    elif kind == "scale":
        g += [cyl((0, -0.12, 0), 0.05, 0.26, "brass"),
              box((0, 0.02, 0), (0.36, 0.02, 0.02), "brass"),
              cyl((-0.17, -0.08, 0), 0.08, 0.012, "brass"),
              cyl((0.17, -0.08, 0), 0.08, 0.012, "brass")]
    else:
        return None
    return g


def spec_for(kind):
    g = recipe(kind)
    if not g:
        return None
    return {
        "location": kind, "size": [320, 320],
        "camera": {"pos": [0, 0, 5], "target": [0, 0, 0], "yfov_deg": 32},
        "ambient": [0.04, 0.045, 0.055],
        "materials": _mats(), "geometry": g,
        "lights": [
            {"type": "directional", "pos": [3, 5, 5], "target": [0, 0, 0],
             "color": [1.0, 0.88, 0.72], "intensity": 3.0},
            {"type": "directional", "pos": [-4, 1, 3], "target": [0, 0, 0],
             "color": [0.62, 0.74, 0.96], "intensity": 1.1},
        ],
    }


def render_sprite(kind, quality="standard"):
    import pyrender
    spec = spec_for(kind)
    if spec is None:
        raise SystemExit("no 3D recipe for %r" % kind)
    prims, mats, used = plate3d.build(spec, "auto", quality)
    scene = pyrender.Scene(bg_color=[0, 0, 0, 0], ambient_light=spec["ambient"])
    scene.add_node(pyrender.Node(mesh=pyrender.Mesh(prims), matrix=np.eye(4)))
    w, h = spec["size"]
    cam = pyrender.OrthographicCamera(xmag=0.72, ymag=0.72)
    scene.add(cam, pose=plate3d.look_at((0, 0, 5), (0, 0, 0)))
    for L in spec["lights"]:
        light = pyrender.DirectionalLight(color=np.array(L["color"]), intensity=L["intensity"])
        scene.add(light, pose=plate3d.look_at(L["pos"], L["target"]))
    r = pyrender.OffscreenRenderer(w, h)
    color, _ = r.render(scene, flags=pyrender.RenderFlags.RGBA)
    r.delete()
    img = Image.fromarray(color.astype(np.uint8), "RGBA")
    bbox = img.getchannel("A").getbbox()
    if not bbox:
        raise SystemExit("prop %s rendered empty" % kind)
    pad = 6
    x0, y0, x1, y1 = bbox
    img = img.crop((max(0, x0 - pad), max(0, y0 - pad),
                    min(w, x1 + pad), min(h, y1 + pad)))
    if max(img.size) > 260:
        scale = 260.0 / max(img.size)
        img = img.resize((int(img.width * scale), int(img.height * scale)), Image.LANCZOS)
    return img


def build_all(only=None, quality="standard"):
    if plate3d.ENGINE is None:
        print("no 3D engine: %s" % plate3d.ENGINE_ERR, file=sys.stderr)
        return 3
    os.makedirs(OUT, exist_ok=True)
    kinds = [only] if only else CANON
    manifest = {}
    mp = os.path.join(OUT, "manifest.json")
    if os.path.exists(mp):
        try:
            manifest = json.load(open(mp))
        except Exception:
            manifest = {}
    for k in kinds:
        img = render_sprite(k, quality)
        path = os.path.join(OUT, k + ".png")
        img.save(path)
        manifest[k] = {"path": path, "size": list(img.size),
                       "alpha_coverage": round(float((np.asarray(img)[..., 3] > 16).mean()), 4),
                       "quality": quality, "renderer": plate3d.ENGINE}
        print("%-12s %3dx%-3d  alpha %.3f" % (k, img.width, img.height,
                                               manifest[k]["alpha_coverage"]))
    json.dump(manifest, open(mp, "w"), indent=1)
    print("wrote %d sprites -> %s" % (len(kinds), OUT))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description="3D hand-prop sprite renderer")
    ap.add_argument("--build", action="store_true")
    ap.add_argument("--kind")
    ap.add_argument("--quality", default="standard", choices=sorted(plate3d.QUALITY))
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--probe", action="store_true")
    a = ap.parse_args(argv)
    if a.list:
        print(json.dumps({"alias": ALIAS, "canonical": CANON}))
        return 0
    if a.probe:
        print(json.dumps({"engine": plate3d.ENGINE, "ok": plate3d.ENGINE is not None,
                          "out": OUT, "count": len(CANON)}))
        return 0
    if a.build:
        return build_all(a.kind, a.quality)
    ap.error("give --build, --list or --probe")


if __name__ == "__main__":
    sys.exit(main())
