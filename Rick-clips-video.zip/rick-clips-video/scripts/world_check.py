#!/usr/bin/env python3
"""
world_check.py — measure the cheap, objective half of the Section C world QA.

Measured from rendered frames:
  * flat coverage      : % of frame in near-uniform 32x32 blocks  (target < 35%)
  * colour clusters    : distinct dominant colours > 1% area       (target >= 6)
  * material families  : distinct hue clusters in the mid band      (target >= 3)
  * contrast           : p95 - p5 luma                              (target 0.42 - 0.92)
  * split tone         : shadows cooler than highlights             (target >= +4 R-B delta)
  * clipping           : % pixels at pure black / pure white        (target < 6% / < 4%)
  * depth sharpness    : detail(fg) / detail(bg)                    (target >= 1.15)
  * atmosphere         : luma variance in the top 25% band          (target > 25 => haze/gradient)

Not measurable from pixels (requires a human or vision pass, listed honestly):
  shadow-direction agreement with the key light, material *names* (wood vs stone),
  whether practicals motivate the atmosphere.

Usage:
  python3 scripts/world_check.py analysis/frames/s07   # a folder of frames for one shot
  python3 scripts/world_check.py analysis/frames --all  # every subfolder
"""
import argparse, glob, os, sys
import numpy as np
from PIL import Image


def features(path):
    im = Image.open(path).convert("RGB")
    im = im.resize((270, 480), Image.BILINEAR)
    a = np.asarray(im, dtype=np.float32) / 255.0
    H, W, _ = a.shape
    lum = a @ np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)

    # flat coverage in 32x32 blocks
    bs = 32
    flats = 0
    total = 0
    for y in range(0, H - bs + 1, bs):
        for x in range(0, W - bs + 1, bs):
            b = a[y:y + bs, x:x + bs]
            total += 1
            if b.reshape(-1, 3).std(axis=0).max() < 0.015:
                flats += 1
    flat = flats / max(total, 1)

    # colour clusters: quantise to 32 levels, keep clusters > 1%
    q = (a.reshape(-1, 3) * 7).astype(np.int16)
    keys, counts = np.unique(q, axis=0, return_counts=True)
    frac = counts / counts.sum()
    clusters = int((frac > 0.01).sum())

    # hue spread in the mid band (materials)
    mid = a[int(H * 0.30):int(H * 0.75)]
    mx = mid.max(axis=2)
    mn = mid.min(axis=2)
    sat = mx - mn
    sel = sat > 0.12
    hues = 0
    if sel.sum() > 50:
        px = mid[sel]
        hsv_h = np.arctan2(np.sqrt(3) * (px[:, 1] - px[:, 2]),
                           2 * px[:, 0] - px[:, 1] - px[:, 2])
        hb = ((hsv_h / (2 * np.pi)) % 1.0 * 12).astype(int) % 12
        k, c = np.unique(hb, return_counts=True)
        hues = int((c / c.sum() > 0.06).sum())

    contrast = float(np.percentile(lum, 95) - np.percentile(lum, 5))
    clip_b = float((lum < 0.02).mean())
    clip_w = float((lum > 0.98).mean())

    # split tone: mean R-B of the darkest and brightest 15%
    lo = np.percentile(lum, 15)
    hi = np.percentile(lum, 85)
    rb = a[:, :, 0] - a[:, :, 2]
    sh = float(rb[lum <= lo].mean()) if (lum <= lo).any() else 0.0
    hi_rb = float(rb[lum >= hi].mean()) if (lum >= hi).any() else 0.0
    split = (hi_rb - sh) * 255.0

    # depth sharpness: laplacian energy in the bottom-middle (foreground) vs top third
    def detail(band):
        g = band @ np.array([0.2126, 0.7152, 0.0722], dtype=np.float32)
        lap = np.abs(4 * g[1:-1, 1:-1] - g[:-2, 1:-1] - g[2:, 1:-1]
                     - g[1:-1, :-2] - g[1:-1, 2:])
        return float(lap.mean()) + 1e-6
    fg = detail(a[int(H * 0.55):int(H * 0.90), int(W * 0.15):int(W * 0.85)])
    bg = detail(a[:int(H * 0.30)])
    depth = fg / bg

    top = lum[:int(H * 0.25)]
    atmos = float(top.std() * 255)

    return {
        "flat": round(flat, 3), "clusters": clusters, "hues": hues,
        "contrast": round(contrast, 3), "clip_black": round(clip_b, 4),
        "clip_white": round(clip_w, 4), "split": round(split, 1),
        "depth": round(depth, 2), "atmos": round(atmos, 1),
    }


def verdict(f):
    """Hard fails are only the checks that are unambiguous from a single frame.
    Everything else is advisory, because a wide aerial legitimately has few
    material families and a neutral-shadow plate is legitimate too."""
    hard, warn = [], []
    if f["flat"] > 0.35:
        hard.append("FLAT")                 # >35% uniform fill = untextured set
    if f["clusters"] < 6:
        hard.append("PALETTE_THIN")
    if f["clip_black"] > 0.06:
        hard.append("CRUSHED_BLACKS")
    if f["clip_white"] > 0.04:
        hard.append("BLOWN_HIGHLIGHTS")
    if f["hues"] < 2:
        warn.append("MATERIALS")            # expect >=3 in a mid/close shot
    if not (0.42 <= f["contrast"] <= 0.92):
        warn.append("CONTRAST")
    if f["split"] < 4:
        warn.append("NEUTRAL_SPLIT")
    if f["depth"] < 1.15:
        warn.append("LOW_DEPTH")            # normal for aerials
    if f["atmos"] < 8:
        warn.append("NO_AIR")
    return hard, warn


def run_dir(d):
    files = sorted(glob.glob(os.path.join(d, "*.png")) + glob.glob(os.path.join(d, "*.jpg")))
    files = [f for f in files if "caption" not in os.path.basename(f).lower()]
    if not files:
        return 2
    sample = files[:: max(1, len(files) // 6)][:6]
    worst = 0
    for p in sample:
        f = features(p)
        hard, warn = verdict(f)
        worst = max(worst, 1 if hard else 0)
        tag = "PASS" if not hard and not warn else (
            "FAIL:" + "+".join(hard) if hard else "ok (warn " + "+".join(warn) + ")")
        print(f"  {os.path.basename(p):<26} flat={f['flat']:<6} clusters={f['clusters']:<3} "
              f"hues={f['hues']:<3} contrast={f['contrast']:<6} split={f['split']:<7} "
              f"depth={f['depth']:<5} atmos={f['atmos']:<6} {tag}")
    return worst


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("path", help="frame folder, or a parent folder with --all")
    ap.add_argument("--all", action="store_true")
    args = ap.parse_args()
    code = 0
    if args.all:
        for d in sorted(glob.glob(os.path.join(args.path, "*"))):
            if os.path.isdir(d):
                print(os.path.basename(d))
                code |= run_dir(d)
    else:
        code = run_dir(args.path)
    print("\nNOTE: shadow-direction agreement and material identification still need a visual pass.")
    return code


if __name__ == "__main__":
    sys.exit(main())
