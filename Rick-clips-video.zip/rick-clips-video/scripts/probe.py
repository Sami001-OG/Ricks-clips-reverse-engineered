#!/usr/bin/env python3
"""Capability probe for the shorts pipeline.

Prints a JSON report and picks the best render tier available in this sandbox:
  tier 1  Remotion (React, exact CSS text + transforms)
  tier 2  Chromium + HTML/CSS (Playwright screenshots per frame)
  tier 3  SVG rasterise + PIL caption cards + ffmpeg (always available)

Also reports whether SVG puppets can be rasterised without a browser
(cairosvg or resvg) — that is what gives tier 3 real limb animation.

Run:  python3 scripts/probe.py
"""
import json
import os
import shutil
import subprocess
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def have(cmd):
    return shutil.which(cmd) is not None


def module(name):
    # A capability report must not pay the import cost of cv2 / numpy /
    # faster_whisper. `find_spec` answers "is it installed" without loading it.
    import importlib.util
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, ValueError):
        return False


def ffmpeg_path():
    if have("ffmpeg"):
        return shutil.which("ffmpeg")
    try:
        import imageio_ffmpeg

        return imageio_ffmpeg.get_ffmpeg_exe()
    except Exception:
        return None


def node_major():
    if not have("node"):
        return None
    try:
        out = subprocess.run(["node", "-v"], capture_output=True, text=True, timeout=15).stdout.strip()
        return int(out.lstrip("v").split(".")[0])
    except Exception:
        return None


def remotion_ready():
    pkg = os.path.join(ROOT, "video", "node_modules", "remotion")
    cli = os.path.join(ROOT, "video", "node_modules", ".bin", "remotion")
    chrome = os.path.expanduser("~/.cache/remotion")
    return os.path.isdir(pkg) and os.path.exists(cli) and os.path.isdir(chrome)


def chromium_ready():
    caches = [
        os.path.expanduser("~/.cache/ms-playwright"),
        os.path.expanduser("~/.cache/puppeteer"),
    ]
    return any(os.path.isdir(c) and os.listdir(c) for c in caches if os.path.isdir(c))


def asr_ready():
    """Which local speech-recognition path exists, if any. Loud and explicit so the
    skill never plans word-synced captions it cannot measure."""
    st = {
        "faster_whisper": module("faster_whisper"),
        "openai_whisper": module("whisper"),
        "vosk": module("vosk"),
        "whisper_cpp": have("whisper-cli") or have("whisper.cpp") or have("main"),
    }
    return st


def plate3d_capability():
    """Is the 3D plate path usable here? Answer by asking the tool itself."""
    try:
        out = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "plate3d.py"),
                              "--probe"], capture_output=True, text=True, timeout=120)
        data = json.loads(out.stdout.strip().splitlines()[-1])
        return data
    except Exception as e:
        return {"ok": False, "engine": None, "error": str(e)[:120],
                "fallback": "references/world.md C.0 procedural plate"}


def main():
    font = os.path.join(ROOT, "assets", "fonts", "Montserrat-ExtraBold.ttf")
    ff = ffmpeg_path()
    asr = asr_ready()
    report = {
        "ffmpeg": ff,
        "ffprobe": have("ffprobe"),
        "python": sys.version.split()[0],
        "node_major": node_major(),
        "npm": have("npm"),
        "git": have("git"),
        "font_montserrat": os.path.exists(font),
        "modules": {
            m: module(m)
            for m in ("PIL", "numpy", "cv2", "pysubs2", "soundfile", "pyloudnorm",
                      "faster_whisper", "cairosvg")
        },
        "svg_rasteriser": "cairosvg" if module("cairosvg") else ("resvg" if have("resvg") else None),
        "remotion_installed": remotion_ready(),
        "chromium_installed": chromium_ready(),
        "gpu": os.path.exists("/dev/nvidia0") or "CUDA_VISIBLE_DEVICES" in os.environ,
    }

    plate = plate3d_capability()
    report["plate3d"] = plate
    # The GL renderer string from a real context beats guessing from device files.
    if "gpu" in plate:
        report["gpu"] = bool(plate["gpu"])
        report["gl_renderer"] = plate.get("gl_renderer")
        report["gl_vendor"] = plate.get("gl_vendor")
    quality = plate.get("quality_recommendation", "standard")
    report["world"] = {
        "plate": "3d" if plate.get("ok") else "vector",
        "quality": quality,
        "note": ("pyrender + EGL, renderer %s (gpu=%s). Stage 4 uses --quality %s; "
                 "on a GPU machine use high or cinema and verify gpu=true in plates.json"
                 % (plate.get("gl_renderer", "unknown"), report["gpu"], quality)
                 if plate.get("ok") else
                 "no 3D engine: stage 4 uses the procedural plate in world.md C.0")}

    report["asr"] = asr
    if any(asr.values()):
        report["voice"] = {"mode": "asr",
                           "note": "a local ASR path exists; vo_timing.py will use it, "
                                   "and fall back to forced alignment if the model cannot load"}
    else:
        report["voice"] = {"mode": "align",
                           "note": "no ASR model. vo_timing.py still produces word timings "
                                   "from the audio + transcript (energy-aligned), so word-synced "
                                   "captions are NOT blocked — only free transcription is"}


    if report["remotion_installed"]:
        report["tier"] = 1
        report["pipeline"] = "remotion"
    elif report["chromium_installed"] and have("node"):
        report["tier"] = 2
        report["pipeline"] = "html+chromium"
    elif report["ffmpeg"] and report["modules"]["PIL"]:
        report["tier"] = 3
        report["pipeline"] = ("svg+cards+ffmpeg" if report.get("svg_rasteriser")
                              else "cards+ffmpeg (static cutouts only — install cairosvg for limb animation)")
    else:
        report["tier"] = 0
        report["pipeline"] = "blocked"
        report["fix"] = "pip install imageio-ffmpeg pillow numpy  (see scripts/bootstrap.sh)"

    print(json.dumps(report, indent=2))
    return 0 if report["tier"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
