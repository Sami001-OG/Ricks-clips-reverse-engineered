#!/usr/bin/env python3
"""Burn captions onto a video with the exact reference metrics.

Input: captions.json (written by scripts/vo_timing.py, never typed by hand)
  [{"text": "it gets", "start": 12.40, "end": 12.95}, ...]

Output: build/cards/card_0001.png ... (1080x1920 RGBA, transparent)
        build/cards/overlay.sh          (the ffmpeg command, ready to run)

Usage:
  python3 scripts/caption_cards.py build/captions.json
  python3 scripts/caption_cards.py build/captions.json --base out/shot.mp4 --out out/capped.mp4 --run

Metrics (measured from the references, see references/text-and-audio.md):
  font      Montserrat ExtraBold (assets/fonts/Montserrat-ExtraBold.ttf)
  size      70 px @1080 wide
  fill      #FFFFFF
  stroke    #000000, 11 px
  shadow    +3px y, 6px blur, 50% black
  position  centred, baseline y = 1376
  wrap      <= 900 px wide, line-height 1.15
"""
import argparse
import json
import os
import subprocess
import sys

from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FONT = os.path.join(ROOT, "assets", "fonts", "Montserrat-ExtraBold.ttf")

W, H = 1080, 1920
SIZE = 70
STROKE = 11
BASELINE = 1376
MAX_W = 900
LINE_H = int(round(SIZE * 1.15))
SHADOW_DY = 3
SHADOW_BLUR = 6
SHADOW_ALPHA = 128
# Captions only ever occupy a band around the baseline. Burning a full-frame RGBA
# overlay per card costs 1080*1920*4 = 8 MB each; 26 cards is ~500 MB of peak
# memory and OOMs a phone. Cropping each card to this band and overlaying it at
# BAND_Y is pixel-identical and 1/12th the memory.
BAND_Y, BAND_H = 1288, 160


def wrap(text, font, draw):
    words = text.split()
    lines, cur = [], ""
    for word in words:
        trial = f"{cur} {word}".strip()
        if draw.textlength(trial, font=font) + STROKE * 2 <= MAX_W or not cur:
            cur = trial
        else:
            lines.append(cur)
            cur = word
    if cur:
        lines.append(cur)
    return lines or [""]


def optical_dx(draw, line, font):
    """Centre on the ink, not on the advance width.

    PIL's anchor centres the typographic advance, so a line ending in a period
    (wide right side bearing) sits ~8 px left of centre — enough to fail the
    caption gate's ±8 px centre tolerance. This shifts by the ink-bbox error.
    """
    bb = draw.textbbox((0, 0), line, font=font, stroke_width=STROKE, anchor="ms")
    return -(bb[0] + bb[2]) / 2.0


def render(text, path):
    font = ImageFont.truetype(FONT, SIZE)
    scratch = ImageDraw.Draw(Image.new("RGBA", (W, H)))
    lines = wrap(text, font, scratch)
    n = len(lines)
    # block bottom baseline stays at BASELINE; earlier lines stack above it
    first_baseline = BASELINE - (n - 1) * LINE_H

    # shadow layer
    shadow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow)
    for i, line in enumerate(lines):
        y = first_baseline + i * LINE_H + SHADOW_DY
        dx = optical_dx(scratch, line, font)
        sd.text((W // 2 + dx, y), line, font=font, anchor="ms",
                fill=(0, 0, 0, SHADOW_ALPHA), stroke_width=STROKE, stroke_fill=(0, 0, 0, SHADOW_ALPHA))
    shadow = shadow.filter(ImageFilter.GaussianBlur(SHADOW_BLUR))

    # text layer
    body = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    bd = ImageDraw.Draw(body)
    for i, line in enumerate(lines):
        y = first_baseline + i * LINE_H
        dx = optical_dx(scratch, line, font)
        bd.text((W // 2 + dx, y), line, font=font, anchor="ms",
                fill=(255, 255, 255, 255), stroke_width=STROKE, stroke_fill=(0, 0, 0, 255))

    out = Image.alpha_composite(shadow, body)
    out.save(path)


def main(argv=None):
    ap = argparse.ArgumentParser(description="exact-metric caption cards + overlay")
    ap.add_argument("captions", nargs="?", default=os.path.join(ROOT, "build", "captions.json"))
    ap.add_argument("--base", default=os.path.join(ROOT, "build", "base.mp4"),
                    help="video to burn onto (default build/base.mp4)")
    ap.add_argument("--out", default=os.path.join(ROOT, "out", "final.mp4"),
                    help="output video (default out/final.mp4)")
    ap.add_argument("--run", action="store_true",
                    help="execute the ffmpeg command instead of only writing overlay.sh")
    args = ap.parse_args(argv)

    with open(args.captions) as fh:
        cards = json.load(fh)

    outdir = os.path.join(ROOT, "build", "cards")
    os.makedirs(outdir, exist_ok=True)
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    files = []
    banddir = os.path.join(outdir, "band")
    os.makedirs(banddir, exist_ok=True)
    for i, c in enumerate(cards, 1):
        path = os.path.join(outdir, f"card_{i:04d}.png")
        render(c["text"], path)
        band = os.path.join(banddir, f"card_{i:04d}.png")
        im = Image.open(path).convert("RGBA")
        im.crop((0, BAND_Y, im.width, BAND_Y + BAND_H)).save(band)
        files.append((band, float(c["start"]), float(c["end"])))

    # one ffmpeg command that overlays every card in its own time window
    lines = ["#!/usr/bin/env bash", "set -euo pipefail", f'cd "{ROOT}"', "",
             f'ffmpeg -y -i "{os.path.relpath(args.base, ROOT)}" \\']
    for path, _, _ in files:
        lines.append(f'  -loop 1 -i "{os.path.relpath(path, ROOT)}" \\')
    fc = []
    prev = "0:v"
    for idx, (_, start, end) in enumerate(files, 1):
        label = f"v{idx}"
        fc.append(f"[{prev}][{idx}:v]overlay=0:{BAND_Y}:enable='between(t,{start:.3f},{end:.3f})'[{label}]")
        prev = label
    lines.append(f'  -filter_complex "{";".join(fc)}" \\')
    lines.append(f'  -map "[{prev}]" -map 0:a? -c:v libx264 -preset slow -crf 19 -pix_fmt yuv420p \\')
    # -shortest can drop the last video frame when the audio stream is a few ms
    # shorter; bound the output at the base's own duration instead.
    dur = ""
    try:
        dur = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                              "-of", "csv=p=0", args.base],
                             capture_output=True, text=True, check=True).stdout.strip()
    except Exception:
        pass
    bound = f" -t {float(dur):.3f}" if dur else ""
    lines.append(f'  -c:a aac -b:a 192k{bound} -movflags +faststart "{os.path.relpath(args.out, ROOT)}"')
    script = "\n".join(lines) + "\n"
    script_path = os.path.join(outdir, "overlay.sh")
    with open(script_path, "w") as fh:
        fh.write(script)
    os.chmod(script_path, 0o755)
    print(f"rendered {len(files)} cards -> {outdir}")
    print(f"wrote {os.path.relpath(script_path, ROOT)}")

    if args.run:
        if not os.path.exists(args.base):
            raise SystemExit(f"base video not found: {args.base}")
        print(f"burning captions -> {args.out}")
        subprocess.run(["bash", script_path], check=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
