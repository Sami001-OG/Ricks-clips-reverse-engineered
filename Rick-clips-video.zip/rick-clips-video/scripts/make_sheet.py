#!/usr/bin/env python3
"""make_sheet.py — generate the character sheets the consistency gate needs.

Writes two things per character:
  assets/characters/<id>/sheet_<pose>.png   alpha silhouettes for IoU checks
  assets/characters/<id>/sheet.png          4096x2048 contact sheet (views + expressions)

Without this, gate 9 (silhouette IoU / garment ΔE) cannot be measured and the
QA report has to mark continuity as a claim. Everything here is derived from
the same rig the renderer uses, so the references cannot drift from the cast.

    python3 scripts/make_sheet.py
    python3 scripts/make_sheet.py --chars assets/characters/characters.json
"""
from __future__ import annotations

import argparse
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
if HERE not in sys.path:
    sys.path.insert(0, HERE)

import cairosvg
import numpy as np
from PIL import Image, ImageDraw

import puppet

ROOT = os.path.dirname(HERE)
CHARS = os.path.join(ROOT, "assets", "characters")

POSES = {
    "stand": {},
    "reach": {"sh_r": 58, "el_r": 22, "torso": -3},
    "grip": {"sh_r": 70, "el_r": 10, "torso": -3},
    "lift": {"sh_r": 42, "el_r": -28, "torso": -5},
    "point": {"sh_r": 72, "el_r": 4, "head": -3},
    "walk": {"hip_l": 18, "hip_r": -18, "kn_l": -12},
    "happy": {"expr": "happy"},
    "sad": {"expr": "sad"},
    "angry": {"expr": "angry"},
    "surprised": {"expr": "surprised"},
}


def load_cards(path):
    if os.path.exists(path):
        data = json.load(open(path, encoding="utf-8"))
        if isinstance(data, dict):
            data = data.get("characters") or list(data.values())
        return data
    bible = os.path.join(ROOT, "build", "story_bible.json")
    if os.path.exists(bible):
        cast = json.load(open(bible, encoding="utf-8")).get("cast") or []
        cards = []
        for c in cast:
            hexv = c.get("hex") or {}
            if isinstance(hexv, str):
                hexv = {"garment": hexv, "accent": "#E0B020", "hat": "#222222"}
            cards.append({"id": c["id"], "role": c.get("role", c["id"]),
                          "height_px": 700, "body": c.get("body", "capsule"),
                          "hair_kind": "short", "hex": hexv,
                          "silhouette_cue": c.get("role", "")})
        return cards
    raise SystemExit("no characters.json and no build/story_bible.json")


def silhouette(card, delta, scale=0.85):
    rig = puppet.build_rig(card)
    pose = puppet.idle_pose(0, rig)
    pose.update(delta)
    actor = {"rig": rig, "pose": pose, "root": (540, 1700), "scale": scale}
    svg = puppet.scene_svg([actor], "", (1.0, 0.0, 0.0, 540, 1700))
    raw = cairosvg.svg2png(bytestring=svg.encode(), output_width=puppet.W,
                           output_height=puppet.H)
    import io
    im = Image.open(io.BytesIO(raw)).convert("RGBA")
    bbox = im.getchannel("A").getbbox()
    if not bbox:
        raise SystemExit("empty silhouette for %s" % card.get("id"))
    return im.crop(bbox)


def build_sheet(card, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    tiles = []
    for name, delta in POSES.items():
        im = silhouette(card, delta)
        im.save(os.path.join(out_dir, "sheet_%s.png" % name))
        im.thumbnail((760, 900), Image.LANCZOS)
        tiles.append((name, im.copy()))

    sheet = Image.new("RGB", (4096, 2048), (18, 18, 22))
    d = ImageDraw.Draw(sheet)
    cols, cw, ch = 5, 800, 1000
    for i, (name, im) in enumerate(tiles):
        x = (i % cols) * cw + (cw - im.width) // 2
        y = (i // cols) * ch + 30
        sheet.paste(im, (x, y), im)
        d.text((x + 8, y + im.height + 8), name, fill=(220, 220, 220))
    sheet.save(os.path.join(out_dir, "sheet.png"))
    return len(tiles)


def main(argv=None):
    ap = argparse.ArgumentParser(description="generate character reference sheets")
    ap.add_argument("--chars", default=os.path.join(CHARS, "characters.json"))
    ap.add_argument("--only", help="single character id")
    ap.add_argument("--out", default=CHARS, help="output root (default assets/characters)")
    a = ap.parse_args(argv)
    cards = load_cards(a.chars)
    total = 0
    for card in cards:
        if a.only and card.get("id") != a.only:
            continue
        cid = card.get("id", "character")
        n = build_sheet(card, os.path.join(a.out, cid))
        total += n
        print("%-14s %d poses + sheet.png" % (cid, n))
    print("wrote %d pose sheets" % total)
    return 0


if __name__ == "__main__":
    sys.exit(main())
