#!/usr/bin/env python3
"""make_sfx.py — deterministic cut punctuation and prop sounds from the plan.

No samples, no downloads: short synthesiser voices made with numpy. The event
list comes from the generated contracts, so every cut/caption swap gets a soft
click, camera moves get a whoosh, and action beats get an impact or prop ping.

    python3 scripts/make_sfx.py --audio build/audio.json \
            --captions build/captions.json --shotlist build/shotlist.json \
            --out build/sfx.wav
"""
from __future__ import annotations

import argparse
import json
import math
import os
import wave

import numpy as np

SR = 48000


def env(n, attack=0.005, release=0.9):
    a = max(1, int(n * attack))
    e = np.ones(n, np.float32)
    e[:a] = np.linspace(0, 1, a)
    e[int(n * release):] *= np.linspace(1, 0, n - int(n * release))
    return e


def voice(kind, rng, seconds):
    n = int(SR * seconds)
    t = np.arange(n, dtype=np.float32) / SR
    noise = rng.standard_normal(n).astype(np.float32)
    if kind == "click":
        x = noise * np.exp(-t * 180.0)
    elif kind == "whoosh":
        f = 180 + 900 * np.sin(np.pi * t / max(seconds, 1e-6))
        x = noise * np.sin(2 * np.pi * np.cumsum(f) / SR)
    elif kind == "impact":
        x = 0.65 * np.sin(2 * np.pi * 62 * t) + 0.35 * noise
        x *= np.exp(-t * 24.0)
    elif kind == "rumble":
        x = np.sin(2 * np.pi * 42 * t) * 0.7 + noise * 0.3
    else:  # ping
        x = (np.sin(2 * np.pi * 880 * t) + 0.4 * np.sin(2 * np.pi * 1320 * t)) * np.exp(-t * 16)
    return x * env(n) / (np.max(np.abs(x)) + 1e-6)


def events(caps, shots):
    out = []
    for c in caps:
        out.append((float(c["start"]), "click", 0.10))
    for s in shots:
        t = float(s["start"])
        camera = str(s.get("camera", "")).lower()
        action = str(s.get("action", "")).lower()
        if any(k in camera for k in ("push", "truck", "crane", "pan", "tilt")):
            out.append((t, "whoosh", 0.16))
        if any(k in action for k in ("strike", "lift", "push", "throw", "grip")):
            out.append((t + 0.35, "impact", 0.20))
        elif any(k in action for k in ("slides", "presses", "writes", "marks", "hands")):
            out.append((t + 0.30, "ping", 0.12))
    return sorted(out)


def main(argv=None):
    ap = argparse.ArgumentParser(description="deterministic SFX bed from the contracts")
    ap.add_argument("--audio", default="build/audio.json")
    ap.add_argument("--captions", default="build/captions.json")
    ap.add_argument("--shotlist", default="build/shotlist.json")
    ap.add_argument("--out", default="build/sfx.wav")
    a = ap.parse_args(argv)

    duration = 30.0
    if os.path.exists(a.audio):
        duration = float(json.load(open(a.audio)).get("duration", duration))
    caps = json.load(open(a.captions, encoding="utf-8")) if os.path.exists(a.captions) else []
    shots = json.load(open(a.shotlist, encoding="utf-8")) if os.path.exists(a.shotlist) else []
    bed = np.zeros(int(duration * SR) + SR, np.float32)
    rng = np.random.default_rng(20261119)          # seeded: identical every run
    ev = events(caps, shots)
    for t, kind, amp in ev:
        seconds = {"click": 0.045, "whoosh": 0.32, "impact": 0.28,
                   "ping": 0.20, "rumble": 0.5}[kind]
        v = voice(kind, rng, seconds) * amp
        i = int(max(0.0, t) * SR)
        bed[i:i + len(v)] += v[:len(bed) - i]
    bed = bed[:int(duration * SR)]
    bed = np.clip(bed * 0.85, -1, 1)
    os.makedirs(os.path.dirname(a.out) or ".", exist_ok=True)
    with wave.open(a.out, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(SR)
        w.writeframes((bed * 32767).astype("<i2").tobytes())
    print("wrote %s: %.2fs, %d events" % (a.out, duration, len(ev)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
