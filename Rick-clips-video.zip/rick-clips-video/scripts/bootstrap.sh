#!/usr/bin/env bash
# One-shot setup for a Linux sandbox (root or not). Safe to re-run.
# Installs only what is missing; never fails the whole run because of an optional tool.
set -uo pipefail
cd "$(dirname "$0")/.." || exit 1

echo "== shorts pipeline bootstrap =="
mkdir -p assets/fonts assets/bg assets/props assets/audio build out analysis \
  assets/characters assets/rigs assets/textures

PY=python3
command -v "$PY" >/dev/null || { echo "python3 missing"; exit 1; }

# Warm runs skip every pip/network operation. The marker is keyed to the script
# AND to the installed versions of the core modules, so deleting a dependency
# cannot leave a stale "already bootstrapped" state.
SUM=$($PY - <<'PYEOF'
import hashlib, sys, importlib.metadata as md
h = hashlib.sha256(open(sys.argv[1], "rb").read()).hexdigest().encode()
for name in ("pillow", "numpy", "imageio-ffmpeg", "cairosvg", "pyrender"):
    try:
        h += (name + "=" + md.version(name)).encode()
    except Exception:
        h += (name + "=missing").encode()
print(hashlib.sha256(h).hexdigest()[:20])
PYEOF
)
MARK="build/.bootstrapped"
if [ -s "$MARK" ] && [ "$(cat "$MARK")" = "$SUM" ]; then
  echo "already bootstrapped ($SUM); skipping installs"
  echo "now run: python3 scripts/probe.py"
  exit 0
fi

echo "-- python deps"
$PY -m pip install --quiet imageio-ffmpeg pillow numpy 2>/dev/null || echo "warn: core pip install failed"
$PY -m pip install --quiet pysubs2 soundfile pyloudnorm opencv-python-headless scikit-image 2>/dev/null \
  || echo "warn: optional python deps unavailable"
# SVG puppet rasterisation: this is what lets tier 3 animate limbs without a browser
$PY -m pip install --quiet cairosvg 2>/dev/null || echo "skip: cairosvg (install libcairo, or use the resvg binary)"
command -v resvg >/dev/null || echo "note: resvg not present (cairosvg is the fallback rasteriser)"

# 3D plates (stage 4). Optional: with no engine, plate3d.py exits 3 and the world
# falls back to the layered-vector recipe in references/world.md C.0.
# pyrender needs a GL context. A container has no display and no GPU, so it renders
# through Mesa's software rasteriser over EGL; plate3d.py starts its own Xvfb :99
# when DISPLAY is unset. System packages are not pip-installable:
#   Debian/Ubuntu: apt-get install -y libegl1 libgl1-mesa-dri xvfb
#   Termux:        pkg install x11-repo && pkg install mesa xvfb python-scipy
export PYOPENGL_PLATFORM=${PYOPENGL_PLATFORM:-egl}
$PY -m pip install --quiet --no-deps pyrender PyOpenGL trimesh pyglet 2>/dev/null \
  && $PY -m pip install --quiet six networkx freetype-py imageio 2>/dev/null \
  && $PY scripts/plate3d.py --probe >/dev/null 2>&1 \
  && echo "  ok 3D plates (pyrender)" \
  || echo "  skip: pyrender unavailable — stage 4 uses vector plates (world.md C.0)"

# Optional speech recognition. Never required: vo_timing.py aligns a transcript to
# the audio's own pauses, so word-synced captions work with no model at all.
if [ "${WITH_ASR:-0}" = "1" ]; then
  echo "-- ASR (optional)"
  $PY -m pip install --quiet faster-whisper 2>/dev/null \
    && echo "  ok faster-whisper (models still download on first use)" \
    || echo "  skip: faster-whisper unavailable — vo_timing.py falls back to forced alignment"
fi

echo "-- QA tools"
for t in consistency_check anim_check world_check measure_captions caption_cards probe plate3d fetch_textures; do
  [ -f "scripts/$t.py" ] && echo "  ok scripts/$t.py" || echo "  MISSING scripts/$t.py"
done

echo "-- ffmpeg"
if ! command -v ffmpeg >/dev/null; then
  $PY - <<'PY'
import imageio_ffmpeg, os, shutil, sys
exe = imageio_ffmpeg.get_ffmpeg_exe()
link = os.path.join(os.path.dirname(sys.executable), "ffmpeg")
if not os.path.exists(link):
    try:
        os.symlink(exe, link)
    except OSError:
        pass
print("ffmpeg:", exe)
PY
else
  echo "ffmpeg: $(command -v ffmpeg)"
fi

echo "-- font (Montserrat ExtraBold, exact caption face)"
if [ ! -s assets/fonts/Montserrat-ExtraBold.ttf ]; then
  curl -sL --max-time 60 -o assets/fonts/Montserrat-ExtraBold.ttf \
    "https://fonts.gstatic.com/s/montserrat/v31/JTUHjIg1_i6t8kCHKm4532VJOt5-QNFgpCvr70w-.ttf" \
    || echo "warn: font download failed — bundle assets/fonts/Montserrat-ExtraBold.ttf manually"
fi
if command -v fc-cache >/dev/null && [ -s assets/fonts/Montserrat-ExtraBold.ttf ]; then
  mkdir -p "$HOME/.fonts" && cp assets/fonts/Montserrat-ExtraBold.ttf "$HOME/.fonts/" 2>/dev/null
  fc-cache -f >/dev/null 2>&1 || true
fi

echo "-- optional: node + Remotion"
if command -v npm >/dev/null; then
  if [ ! -d video/node_modules/remotion ]; then
    ( cd video && npm install --silent --no-audit --no-fund remotion @remotion/cli react react-dom ) \
      || echo "warn: remotion install failed"
  fi
  if [ -d video/node_modules/remotion ]; then
    ( cd video && npx --yes remotion browser ensure ) >/dev/null 2>&1 || echo "skip: remotion chromium"
  fi
else
  echo "skip: node/npm not present (Remotion unavailable; tier 3 fallback applies)"
fi

if [ "${WITH_BROWSER:-0}" = "1" ]; then
  echo "-- optional: Playwright chromium (WITH_BROWSER=1)"
  $PY -m pip install --quiet playwright 2>/dev/null && $PY -m playwright install chromium >/dev/null 2>&1 \
    || echo "skip: playwright chromium"
fi

echo "$SUM" > "$MARK"
echo "bootstrap complete. Now run: python3 scripts/probe.py"
