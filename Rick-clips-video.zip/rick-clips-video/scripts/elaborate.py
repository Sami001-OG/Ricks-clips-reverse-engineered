#!/usr/bin/env python3
"""elaborate.py — turn a voiceover seed into an atom-level production script.

The voice is the master clock and is NEVER changed. What this tool adds is
everything the voice implies but does not say: the place, the furniture, the
things in the characters' hands, the dressing on the surfaces and floor, the
light, the human trace, and the camera size that makes each detail readable.
Every added atom is bound to a word time and to a shot in the frame-exact
shotlist, so "what is in the script must be in the video" is a check, not a hope.

    # draft the bible from the timed voice (stage 1b, after vo_timing.py)
    python3 scripts/elaborate.py --voice script.txt \
            --words build/words.json --captions build/captions.json \
            --audio build/audio.json --detail 3

    # review build/expanded_script.md, fix the bible, then validate
    python3 scripts/elaborate.py --check build/story_bible.json \
            --words build/words.json --shotlist build/shotlist.json

Outputs: build/story_bible.json (machine truth), build/expanded_script.md
(human truth), build/objects.json (shotlist contract), build/beats.tsv
(shotlist --fill, eight columns), build/scene_manifest.json (plate inventory).
"""
from __future__ import annotations

import argparse
import json
import os
import random
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
LIB_PATH = os.path.join(ROOT, "references", "library", "domains.json")

PLATE_PRIMITIVES = ("box", "quad", "room", "floor", "cylinder", "sphere", "cone")

FRAMING = {
    "wide":   {"yfov_deg": 58, "note": "establish the place; full body and the room"},
    "medium": {"yfov_deg": 50, "note": "waist up, context still readable"},
    "close":  {"yfov_deg": 42, "note": "face and hands; the named object fills a third of frame"},
    "insert": {"yfov_deg": 36, "note": "the object alone; a hand enters and takes it"},
    "ots":    {"yfov_deg": 48, "note": "over the shoulder; the second character in frame"},
    "low":    {"yfov_deg": 66, "note": "camera below the knee line, ceiling in frame"},
    "high":   {"yfov_deg": 32, "note": "camera above eye line, floor pattern in frame"},
}

ATOMS = ("place", "in_hand", "surfaces", "walls", "floor", "light", "human_trace", "change")
ACTION_ALTERNATES = (
    "turns toward the second character, then back",
    "pauses and checks the working surface",
    "steps back and reassesses the room",
    "sets the object down carefully and lets go",
    "looks up toward the practical light",
    "hands the object across and watches the reaction",
)

VERBS = {
    "envelope": "slides the envelope across the counter",
    "stamp": "presses the stamp down and lifts it",
    "parcel": "sets the parcel down and turns it to face the label",
    "bag": "swings the bag up onto the shoulder",
    "phone": "brings the phone up until the screen lights the face",
    "key": "turns the key once in the lock",
    "cup": "sets the cup down and lets go of the handle",
    "clipboard": "tilts the clipboard toward the second character",
    "book": "opens the book flat",
    "ticket": "holds the ticket up to the light",
    "scale": "settles the weighing scale and reads the pans",
    "stamp_book": "flicks open the stamp booklet",
    "paperwork": "sorts the paperwork into two piles",
    "tray": "extends the tray with both hands",
    "hammer": "lifts the hammer and checks its head",
    "wrench": "turns the wrench a quarter turn",
    "chart": "marks the chart with the pen",
    "stethoscope": "settles the stethoscope around the neck",
    "menu": "opens the menu at the second page",
    "bill": "folds the bill once and hands it over",
    "notebook": "writes one line in the notebook",
    "basket": "sets the basket on the surface",
    "bottle": "caps the bottle",
    "keycard": "swipes the keycard",
}


# ------------------------------------------------------------------ helpers
def load_library():
    with open(LIB_PATH, encoding="utf-8") as f:
        return json.load(f)


def norm(tok):
    t = re.sub(r"[^a-z']", "", str(tok).lower())
    if len(t) > 3 and t.endswith("ies"):
        t = t[:-3] + "y"
    elif len(t) > 3 and t.endswith("es"):
        t = t[:-2]
    elif len(t) > 3 and t.endswith("s") and not t.endswith("ss"):
        t = t[:-1]
    return t


def wordset(lib):
    """trigger token -> set of object ids; one token can name several objects."""
    out = {}
    for oid, o in lib["catalog"].items():
        for w in o["words"]:
            out.setdefault(norm(w), set()).add(oid)
    return out


def detect_domain(text, lib, explicit=None):
    if explicit:
        if explicit not in lib["domains"]:
            raise SystemExit("unknown domain %r; known: %s" %
                             (explicit, ", ".join(lib["domains"])))
        return explicit
    toks = [norm(t) for t in re.findall(r"[A-Za-z']+", text.lower())]
    scores = {}
    for did, d in lib["domains"].items():
        s = 0.0
        for trig in d["triggers"]:
            tn = norm(trig)
            if not tn:
                continue
            s += sum(2.0 if t == tn else 0.5 for t in toks if " " not in trig)
        if did == "generic":
            s *= 0.05
        scores[did] = s
    best = max(scores, key=lambda k: scores[k])
    return best if scores[best] >= 2.0 else "generic"


def read_voice(args):
    if args.voice and os.path.exists(args.voice):
        return open(args.voice, encoding="utf-8").read()
    if os.path.exists(args.captions):
        cards = json.load(open(args.captions, encoding="utf-8"))
        return " ".join(c.get("text", "") for c in cards)
    raise SystemExit("give --voice FILE or an existing --captions file")


def duration_of(args, voice):
    if args.duration:
        return float(args.duration)
    if os.path.exists(args.audio):
        d = json.load(open(args.audio, encoding="utf-8")).get("duration")
        if d:
            return float(d)
    if os.path.exists(args.captions):
        cards = json.load(open(args.captions, encoding="utf-8"))
        return max(float(c.get("end", 0)) for c in cards) + 0.5
    return max(12.0, len(voice.split()) / 2.8)


def prelim_shots(captions_path, total, fps=30):
    """Reuse shotlist.build so the IDs and windows are identical to stage 3."""
    sys.path.insert(0, HERE)
    import shotlist
    cards = shotlist.load_cards(captions_path)
    shots, frames, _ = shotlist.build(cards, total, fps)
    return shots


def group_by_time(items, t0, t1):
    out = []
    for x in items:
        m = (float(x["start"]) + float(x["end"])) / 2.0
        if t0 <= m < t1:
            out.append(x)
    return out


# ------------------------------------------------------------------ drafting
def classify(words, lib, overrides=None):
    trig = wordset(lib)
    abstract = set(lib["abstract"]) | set(overrides or [])
    hits, unclassified = [], []
    for w in words:
        tok = norm(w.get("w", ""))
        oids = sorted(trig.get(tok, ()))
        if oids:
            hits.append((w, oids))
        elif tok and tok not in abstract and len(tok) > 2:
            unclassified.append(w.get("w"))
    return hits, unclassified


def pick_objects(shot, loc, voice_hits, lib, detail, used_order):
    """Objects physically in frame in this shot. Voice-named ones come first."""
    catalog = lib["catalog"]
    inv = loc["inventory"]
    wanted = max(3, min(10, {1: 4, 2: 6, 3: 8}[detail]))
    picked, seen = [], set()

    def add(oid, source, at=None):
        if oid in seen or oid not in catalog:
            return
        seen.add(oid)
        o = catalog[oid]
        # Where in the frame this object lives. A hand prop gets a socket; a
        # plate object gets a depth/screen slot. This is the "needed spot"
        # contract — an object listed in a shot but placed nowhere is a bug.
        if o["form"] == "hand":
            side = "right" if len(picked) % 2 == 0 else "left"
            anchor = {"x": side, "y": "middle"}
            hand = "r" if side == "right" else "l"
            slot = "hand"
        else:
            slot = o["where"]
            anchor = {"near": {"x": "center", "y": "bottom"},
                      "mid": {"x": "center", "y": "middle"},
                      "far": {"x": "center", "y": "top"}}.get(slot, {"x": "center", "y": "middle"})
            hand = None
        default_at = shot["start"] + (shot["end"] - shot["start"]) * \
                     (0.18 + 0.64 * len(picked) / float(wanted))
        when = default_at if at is None else min(max(at, shot["start"]), shot["end"])
        picked.append({"id": oid, "label": o["label"], "words": o["words"],
                       "form": o["form"], "make": o["make"], "where": o["where"],
                       "detail": o["detail"], "source": source,
                       "slot": slot, "anchor": anchor, "hand": hand,
                       "spot": "%s / %s %s" % (slot, anchor["x"], anchor["y"]),
                       "at": round(when, 3)})

    # 1. what the voice names inside this shot's window — non-negotiable
    for w, oids in voice_hits:
        mid = (float(w["start"]) + float(w["end"])) / 2.0
        if shot["start"] - 0.15 <= mid <= shot["end"] + 0.15:
            for oid in oids:
                add(oid, "voice", at=mid)

    # 2. the location's own inventory. Essential first, then deterministic
    #    rotation so successive shots show different things.
    essentials = [o for o in inv if catalog.get(o, {}).get("form") == "set"]
    rest = [o for o in inv if o not in essentials]
    ordered = essentials + sorted(rest, key=lambda o: (used_order.get(o, 0), o))
    for oid in ordered:
        if len(picked) >= wanted:
            break
        add(oid, "inventory")
    for oid in inv:
        if len(picked) >= wanted:
            break
        add(oid, "inventory")

    # 3. one thing held, if the shot has a character and no hand prop yet
    if not any(p["form"] == "hand" for p in picked):
        hand = next((o for o in inv if catalog.get(o, {}).get("form") == "hand"), None)
        if hand:
            add(hand, "inventory")
    return picked


def choose_framings(shots, scene_ids, picked, total):
    n = len(shots)
    fr = []
    close_on = set(FRAMING)  # replaced by library below
    lib = load_library()
    close_on = set(lib["framing_rules"]["close_on"])
    insert_on = set(lib["framing_rules"]["insert_on"])
    for i in range(n):
        if i == 0:
            fr.append("wide")
            continue
        objs = {o["id"] for o in picked[i]}
        if i >= 2 and i % 4 == 2 and (objs & insert_on):
            fr.append("insert")
            continue
        cycle = ["medium", "close", "ots", "medium", "low", "medium", "high", "close"]
        f = cycle[i % len(cycle)]
        # no repeated size back-to-back, and never three of scene+size in a row
        if f == fr[i - 1]:
            f = next(c for c in cycle if c != fr[i - 1])
        if i >= 2 and (scene_ids[i], f) == (scene_ids[i - 1], fr[i - 1]) == (scene_ids[i - 2], fr[i - 2]):
            f = next(c for c in cycle if c != f)
        fr.append(f)

    # guarantee breadth: at least four distinct sizes, and enough inserts
    have = set(fr)
    for need in ("medium", "close", "insert", "ots", "low", "high"):
        if len(have) >= 4:
            break
        if need in have:
            continue
        idx = min(n - 1, 3 + len(have))
        fr[idx] = need
        have = set(fr)

    need_inserts = max(1, int(total / 20.0))
    got = sum(1 for f in fr if f == "insert")
    for k in range(need_inserts - got):
        idx = 2 + 3 * k
        if idx < n:
            fr[idx] = "insert"
    return fr


def action_for(hand, role, recent):
    """One action per beat, never the same gesture three shots running."""
    base = (VERBS.get(hand["id"], "settles the " + hand["label"] + " into place")
            if hand else "holds still, then turns toward the next beat")
    if base not in recent[-2:]:
        return base
    for alt in ACTION_ALTERNATES:
        if alt not in recent[-2:]:
            return alt
    return base


def atoms_for(shot, loc, objects, framing, cast, total):
    by_where = {"near": [], "mid": [], "far": []}
    hands = []
    for o in objects:
        if o["form"] == "hand":
            hands.append(o)
        else:
            by_where.setdefault(o["where"], []).append(o)

    def phrase(items, fallback):
        return ", ".join(o["detail"] for o in items[:3]) if items else fallback

    f = FRAMING[framing]
    names = ", ".join(c["role"] for c in cast) or "a figure"
    return {
        "place": "%s — %s; %s light, palette %s." %
                 (loc["label"], loc["why"], loc["time_of_day"], "/".join(loc["palette"][:3])),
        "in_hand": "In hand: %s." % phrase(hands, "nothing yet — the hands are empty for this beat"),
        "surfaces": "On the working surfaces: %s." % phrase(by_where["mid"], "a clear, worn edge"),
        "walls": "On the walls and at the back: %s." % phrase(by_where["far"], "bare wall with one shadow line"),
        "floor": "At the feet: %s." % phrase(by_where["near"], "a strip of floor light"),
        "light": "One motivated key from the same direction all shot; %s; %d° lens, %s." %
                 (loc["time_of_day"], f["yfov_deg"], f["note"]),
        "human_trace": "Human trace: %s — left by someone who was here before." %
                       phrase([o for o in objects if o["id"] in ("coat", "newspaper", "cup", "thermos", "paperwork")],
                              "a mug left on the edge"),
        "change": "During the shot: %s; hard cut out." % f["note"],
    }


def build_bible(args):
    lib = load_library()
    voice = read_voice(args)
    total = duration_of(args, voice)
    domain = detect_domain(voice, lib, args.domain)
    dom = lib["domains"][domain]
    locs = dom["locations"][:3]
    words = (json.load(open(args.words, encoding="utf-8")) if os.path.exists(args.words) else [])
    hits, unclassified = classify(words, lib)

    # Stage 3 already ran? Use its exact windows and IDs — the bible must bind
    # atoms to the real shotlist, including any manual splits.
    if os.path.exists(args.shotlist):
        shots = json.load(open(args.shotlist, encoding="utf-8"))
    elif os.path.exists(args.captions):
        shots = prelim_shots(args.captions, total)
    else:
        shots = [{"id": "s%02d" % (i + 1), "start": round(i * 2.2, 3),
               "end": round(min(total, (i + 1) * 2.2), 3),
               "caption": voice.split()[i * 5:i * 5 + 5]}
              for i in range(max(1, int(total / 2.2)))]

    n = len(shots)
    order = {s["id"]: k for k, s in enumerate(shots)}

    scene_ids = [locs[(i * len(locs)) // n % len(locs)]["id"] for i in range(n)]
    loc_by_id = {l["id"]: l for l in locs}
    picked = [pick_objects(shots[i], loc_by_id[scene_ids[i]], hits, lib, args.detail, order)
              for i in range(n)]
    framings = choose_framings(shots, scene_ids, picked, total)

    # Advance the rotation counter per object so repeated locations vary.
    counts = {}
    for i in range(n):
        for o in picked[i]:
            counts[o["id"]] = counts.get(o["id"], 0) + 1
    for i in range(n):
        for o in picked[i]:
            o["index"] = counts[o["id"]]
            counts[o["id"]] -= 1

    cast = []
    for c in dom["cast"]:
        cast.append(dict(c))
    voice_lc = voice.lower()
    for c in cast:
        if any(re.search(r"\b" + re.escape(w.lower()) + r"\b", voice_lc) for w in c["words"]):
            c["in_voice"] = True
    insert_objs = {}
    for i, oid in enumerate(framings):
        if oid == "insert":
            cand = [o for o in picked[i] if o["id"] in lib["framing_rules"]["insert_on"]]
            insert_objs[i] = cand[0]["id"] if cand else (picked[i][0]["id"] if picked[i] else None)

    expanded = []
    for i, s in enumerate(shots):
        objs = picked[i]
        a = atoms_for(s, loc_by_id[scene_ids[i]], objs, framings[i], cast, total)
        expanded.append({
            "shot": s["id"], "start": s["start"], "end": s["end"],
            "voice": " ".join(s.get("caption", [])),
            "scene": scene_ids[i], "framing": framings[i],
            "camera": FRAMING[framings[i]]["note"],
            "action": "",
            "yfov_deg": FRAMING[framings[i]]["yfov_deg"],
            "framing_insert_subject": insert_objs.get(i),
            "characters": [c["id"] for c in cast],
            "on_screen": [o["id"] for o in objs],
            "objects": objs, "atoms": a,
            "detail": (" ".join(a[k] for k in ATOMS)).replace("\n", " "),
        })

    # Author a distinct verb for every beat, then prove the variety.
    recent = []
    role0 = cast[0]["role"] if cast else "the figure"
    for e in expanded:
        hand = next((o for o in e["objects"] if o["form"] == "hand"), None)
        e["action"] = action_for(hand, role0, recent)
        recent.append(e["action"])

    # Flatten object contract, merging every shot where an object appears.
    agg = {}
    for e in expanded:
        for o in e["objects"]:
            rec = agg.setdefault(o["id"], {"id": o["id"], "label": o["label"],
                                           "words": o["words"], "form": o["form"],
                                           "make": o["make"], "where": o["where"],
                                           "slot": o.get("slot"), "anchor": o.get("anchor"),
                                           "hand": o.get("hand"), "spot": o.get("spot"),
                                           "detail": o["detail"], "source": o["source"],
                                           "appears": [], "at": []})
            if e["shot"] not in rec["appears"]:
                rec["appears"].append(e["shot"])
                rec["at"].append(o["at"])
    if args.detail >= 2:
        for c in cast:
            for pid in c["props"]:
                o = lib["catalog"].get(pid)
                if not o:
                    continue
                rec = agg.setdefault(pid, {"id": pid, "label": o["label"], "words": o["words"],
                                           "form": o["form"], "make": o["make"],
                                           "where": o["where"], "detail": o["detail"],
                                           "source": "cast", "appears": [], "at": []})
                # A cast prop is NOT held in every shot: that is how a contract
                # becomes a lie. Use the shots that already place the object,
                # otherwise give it two motivated beats (an opening and a
                # middle insert) so it is authored once and put down again.
                already = [e for e in expanded if pid in e["on_screen"]]
                picks = [e["shot"] for e in already]
                if not picks:
                    idx = [i for i, e in enumerate(expanded) if e["framing"] == "insert"]
                    slots = [0] + ([idx[len(idx) // 2]] if idx else [min(2, len(expanded) - 1)])
                    picks = [expanded[i]["shot"] for i in sorted(set(slots)) if i < len(expanded)]
                for sid in picks:
                    if sid not in rec["appears"]:
                        rec["appears"].append(sid)
                        rec["at"].append(round(next((e["start"] for e in expanded
                                                     if e["shot"] == sid), 0.0), 3))

    bible = {
        "version": 1, "generator": "scripts/elaborate.py", "detail": args.detail,
        "domain": domain, "domain_label": dom["label"],
        "voice": {"script": voice.strip(), "words": len(words), "duration": round(total, 3),
                  "caption_file": args.captions},
        "locations": locs, "cast": cast,
        "objects": list(agg.values()),
        "abstract": sorted(set(lib["abstract"]) | set(a.strip().lower() for a in args.abstract)),
        "unclassified": sorted(set(unclassified)),
        "expanded_script": expanded,
        "coverage": {
            "words_total": len(words),
            "classified": len(words) - len(unclassified),
            "unclassified": sorted(set(unclassified)),
            "objects": len(agg), "locations": len(locs), "shots": len(expanded),
            "distinct_framings": len(set(framings)), "inserts": framings.count("insert"),
            "distinct_actions": len({e["action"] for e in expanded}),
            "distinct_themes": len({l.get("theme", {}).get("signature", l["id"])
                                    for l in locs}),
        },
    }
    return bible


# ------------------------------------------------------------------ outputs
def write_outputs(bible, args):
    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(bible, f, indent=1, ensure_ascii=False)

    obj_path = os.path.join(os.path.dirname(args.out), "objects.json")
    contract = {
        "objects": [{"id": o["id"], "kind": o["form"], "words": o["words"],
                     "appears": o["appears"], "make": o["make"]} for o in bible["objects"]],
        "abstract": bible["abstract"],
    }
    json.dump(contract, open(obj_path, "w", encoding="utf-8"), indent=1, ensure_ascii=False)

    beat_path = os.path.join(os.path.dirname(args.out), "beats.tsv")
    with open(beat_path, "w", encoding="utf-8") as f:
        f.write("id\tbeat\tscene\tcharacters\taction\tcamera\tframing\tobjects\n")
        for e in bible["expanded_script"]:
            action = e.get("action") or "holds still, then turns toward the next beat"
            on = ",".join(o["id"] for o in e["objects"])
            f.write("\t".join([e["shot"], e["voice"][:80] or "silent beat", e["scene"],
                               ",".join(e["characters"]), action,
                               e["camera"], e["framing"], on]) + "\n")

    # Per-shot placement: what is on screen, where, in whose hand, and when.
    # This is the contract the blocking and scene authoring must satisfy.
    placements = []
    for e in bible["expanded_script"]:
        for o in e["objects"]:
            placements.append({"shot": e["shot"], "scene": e["scene"],
                               "start": e["start"], "end": e["end"],
                               "object": o["id"], "form": o["form"], "make": o["make"],
                               "slot": o.get("slot"), "anchor": o.get("anchor"),
                               "hand": o.get("hand"), "spot": o.get("spot"),
                               "at": o["at"], "source": o["source"]})
    place_path = os.path.join(os.path.dirname(args.out), "placements.json")
    json.dump(placements, open(place_path, "w", encoding="utf-8"), indent=1, ensure_ascii=False)
    theme_path = os.path.join(os.path.dirname(args.out), "theme_map.json")
    json.dump({l["id"]: (l.get("theme") or {}).get("signature", l["id"])
               for l in bible["locations"]},
              open(theme_path, "w", encoding="utf-8"), indent=1, ensure_ascii=False)

    manifest = {}
    for loc in bible["locations"]:
        manifest[loc["id"]] = {
            "label": loc["label"], "palette": loc["palette"], "time_of_day": loc["time_of_day"],
            "inventory": [{"id": oid, "make": bible_objects_make(bible, oid)}
                          for oid in loc["inventory"]],
        }
    json.dump(manifest, open(os.path.join(os.path.dirname(args.out), "scene_manifest.json"), "w",
                             encoding="utf-8"), indent=1, ensure_ascii=False)

    md = []
    md.append("# Expanded script — %s" % bible["domain_label"])
    md.append("")
    md.append("_Generated by `scripts/elaborate.py`. The voice is unchanged; every line below is "
              "on-screen detail bound to the word times. Detail density: %d._" % bible["detail"])
    md.append("")
    md.append("- Domain **%s** · %d locations · %d objects · %d shots" %
              (bible["domain"], bible["coverage"]["locations"], bible["coverage"]["objects"],
               bible["coverage"]["shots"]))
    md.append("- Framings: %s" % ", ".join(sorted(set(e["framing"] for e in bible["expanded_script"]))))
    md.append("- Unclassified words: %s" % (", ".join(bible["unclassified"]) or "none"))
    md.append("")
    for e in bible["expanded_script"]:
        md.append("## %s · %.2f–%.2fs · %s · %s" %
                  (e["shot"], e["start"], e["end"], e["scene"], e["framing"].upper()))
        md.append("")
        md.append("> VO: %s" % (e["voice"] or "— silent beat —"))
        md.append("")
        for k in ATOMS:
            md.append("- **%s** — %s" % (k.replace("_", " "), e["atoms"][k]))
        md.append("")
        md.append("On screen: %s" % ", ".join("%s (%s, %s)" %
                                              (o["id"], o["make"], o.get("spot", "unplaced"))
                                              for o in e["objects"]))
        md.append("")
    md_path = os.path.join(os.path.dirname(args.out), "expanded_script.md")
    open(md_path, "w", encoding="utf-8").write("\n".join(md) + "\n")
    return obj_path, beat_path, md_path, place_path


def bible_objects_make(bible, oid):
    for o in bible["objects"]:
        if o["id"] == oid:
            return o["make"]
    return "plate:box"


# --------------------------------------------------------------------- check
def check_bible(path, words_path, shotlist_path, lib, anim_path=None):
    bad, warn = [], []
    if not os.path.exists(path):
        print("FAIL: no %s" % path)
        return 1
    b = json.load(open(path, encoding="utf-8"))
    shots = json.load(open(shotlist_path, encoding="utf-8")) if os.path.exists(shotlist_path) else []
    words = json.load(open(words_path, encoding="utf-8")) if os.path.exists(words_path) else []

    # 26 — locations and inventories
    locs = b.get("locations") or []
    if len(locs) < 3:
        bad.append("only %d locations; need >= 3" % len(locs))
    for l in locs:
        if len(l.get("inventory") or []) < 6:
            bad.append("%s has only %d inventory items; need >= 6" %
                       (l.get("id"), len(l.get("inventory") or [])))

    # 27 — every content word classified
    trig = wordset(lib)
    abstract = set(b.get("abstract") or [])
    unk = sorted(set(w.get("w") for w in words
                     if norm(w.get("w", "")) not in trig
                     and norm(w.get("w", "")) not in abstract
                     and len(norm(w.get("w", ""))) > 2))
    if unk:
        bad.append("unclassified words: %s" % ", ".join(unk[:12]))

    # 28 — bidirectional object visibility
    on = {}
    for s in shots:
        for oid in s.get("objects") or []:
            on.setdefault(oid, []).append(s)
    for o in b.get("objects") or []:
        if o["id"] not in on:
            bad.append("object %s declared but in no shot" % o["id"])
    decl = {}
    for o in b.get("objects") or []:
        for w in o.get("words", [o["id"]]):
            decl.setdefault(norm(w), []).append(o["id"])
    for w in words:
        tok = norm(w.get("w", ""))
        if tok in decl:
            t0, t1 = float(w["start"]), float(w["end"])
            if not [s for oid in decl[tok] for s in on.get(oid, [])
                    if s["start"] <= t0 + 1.0 and s["end"] >= t1 - 1.0]:
                bad.append("%s spoken at %.2fs with no named object on screen" % (w.get("w"), t0))

    # 28b — right shot, right word, right spot. The ±1 s tolerance in
    # shotlist.py answers "is it in the same shot?"; this tighter check answers
    # "is it there when the word lands, and is it actually placed somewhere?"
    for e in b.get("expanded_script") or []:
        for o in e.get("objects") or []:
            if not o.get("slot") or not o.get("anchor"):
                bad.append("%s: %s has no placement slot in frame" % (e.get("shot"), o["id"]))
            if o.get("form") == "hand" and not o.get("hand"):
                bad.append("%s: hand prop %s has no hand socket" % (e.get("shot"), o["id"]))
            when = float(o.get("at", -1))
            if not (float(e["start"]) - 0.01 <= when <= float(e["end"]) + 0.01):
                bad.append("%s: %s placed at %.2fs outside the shot" % (e.get("shot"), o["id"], when))

    trig28 = wordset(lib)
    shot_windows = [(e.get("shot"), float(e["start"]), float(e["end"]),
                     {o["id"] for o in e.get("objects") or []})
                    for e in b.get("expanded_script") or []]
    for w in words:
        tok = norm(w.get("w", ""))
        oids = trig28.get(tok, ())
        if not oids:
            continue
        mid = (float(w["start"]) + float(w["end"])) / 2.0
        ok = any((oid in shown) and (t0 - 0.35 <= mid <= t1 + 0.35)
                 for _, t0, t1, shown in shot_windows for oid in oids)
        if not ok:
            bad.append("%s at %.2fs: named object is not placed in a covering shot"
                       % (w.get("w"), mid))

    # 29 — build source resolvable
    sys.path.insert(0, HERE)
    try:
        import puppet
        kinds = set(getattr(puppet, "PROP_KINDS", ()))
    except Exception:
        kinds = set()
    for o in b.get("objects") or []:
        make = o.get("make", "")
        if make.startswith("puppet:"):
            if make[7:] not in kinds and kinds:
                bad.append("object %s uses unknown puppet prop %s" % (o["id"], make[7:]))
        elif make.startswith("plate:"):
            if make[6:] not in PLATE_PRIMITIVES:
                bad.append("object %s uses unknown plate primitive %s" % (o["id"], make[6:]))
        elif make.startswith("set:"):
            inventory = {x for l in b.get("locations") or [] for x in l.get("inventory") or []}
            if make[4:] not in inventory:
                bad.append("object %s has dressing id %s in no location" % (o["id"], make[4:]))
        else:
            bad.append("object %s has no resolvable make source" % o["id"])
        if make.startswith("puppet:"):
            canon = getattr(sys.modules.get("puppet"), "PROP3D_ALIAS", {}).get(make[7:], make[7:])
            sprite = os.path.join(ROOT, "assets", "props", "3d", canon + ".png")
            if not os.path.exists(sprite):
                bad.append("object %s has no 3D sprite at %s" % (o["id"], sprite))

    # 29b — a prop in the contract must actually be parented to a character.
    # objects.json and shotlist.json are only a plan; anim.json is what the
    # renderer reads. A hand prop absent from it is the "named but never held"
    # failure even though every paper check passed.
    if anim_path and os.path.exists(anim_path):
        try:
            anim = json.load(open(anim_path, encoding="utf-8-sig"))
        except Exception as exc:
            bad.append("anim.json is not valid JSON: %s" % exc)
            anim = None
        if anim is not None:
            entries = anim if isinstance(anim, list) else (anim.get("shots") or anim.get("anim") or [])
            by_shot = {}
            if isinstance(entries, dict):
                for k, v in entries.items():
                    by_shot[k] = v if isinstance(v, list) else (v.get("actors") or [])
            else:
                for e in entries:
                    if isinstance(e, dict):
                        by_shot[str(e.get("shot"))] = e.get("actors") or []
            kind_by_id = {o["id"]: o.get("make", "")[7:]
                          for o in b.get("objects") or [] if o.get("make", "").startswith("puppet:")}
            for s in shots:
                for oid in s.get("objects") or []:
                    if not oid.startswith("_") and oid in kind_by_id:
                        want = {oid, kind_by_id[oid]}
                        actors = by_shot.get(s["id"], [])
                        held = set()
                        for a in actors:
                            if isinstance(a, dict):
                                for p in a.get("props") or []:
                                    if isinstance(p, dict):
                                        held.add(str(p.get("id") or p.get("kind") or ""))
                                    else:
                                        held.add(str(p))
                        if not (want & held):
                            bad.append("%s: hand prop %s is in the contract but not in anim.json"
                                       % (s["id"], oid))

    # Prefer the FINAL contracts when present: a plan that stayed perfect in
    # the story bible but diverged in shotlist.json must not pass the gate.
    shot_actions = [s.get("action", "") for s in shots if s.get("action")]
    if shot_actions:
        actions = shot_actions
    shot_themes = [s.get("theme", "") for s in shots if s.get("theme")]
    used_themes = set(shot_themes) if shot_themes else None
    # 31b — theme separation. Three addresses that share a palette, key ratio
    # and dominant material still look like one location.
    used_scenes = set(sc for e in (b.get("expanded_script") or []) for sc in [e.get("scene")])
    themes = {l["id"]: (l.get("theme") or {}).get("signature") for l in locs}
    for sid in used_scenes:
        if not themes.get(sid):
            bad.append("location %s has no visual theme signature" % sid)
    sigs = [themes.get(sid) for sid in used_scenes if themes.get(sid)]
    if used_themes is not None:
        sigs = list(used_themes)
    if len(set(sigs)) < len(sigs):
        bad.append("two locations share a visual theme signature — change palette, time, key ratio or dominant material")

    # 17b — action variety. A cut where the same gesture repeats three times
    # is the failure the contact sheet exposed, even with perfect object checks.
    if len(set(actions)) < min(4, len(actions)):
        bad.append("only %d distinct action(s) in %d shots" % (len(set(actions)), len(actions)))
    run = 1
    for i in range(1, len(actions)):
        run = run + 1 if actions[i] == actions[i - 1] else 1
        if run >= 3:
            bad.append("%s: three consecutive shots with the same action" %
                       (b["expanded_script"][i].get("shot")))

    # 30/31 — variety. Measure the REAL shotlist when it exists; the expanded
    # script is only the plan, and a plan that stayed perfect while the cut
    # collapsed into one room is the exact failure this gate exists to catch.
    if shots:
        fr = [s.get("framing", "") for s in shots]
        sc = [s.get("scene", "") for s in shots]
    else:
        fr = [e.get("framing") for e in b.get("expanded_script") or []]
        sc = [e.get("scene") for e in b.get("expanded_script") or []]
    if len(set(fr)) < 4:
        bad.append("only %d shot sizes" % len(set(fr)))
    inserts = fr.count("insert")
    dur = float(b.get("voice", {}).get("duration", 0))
    if inserts < max(1, int(dur / 20.0)):
        bad.append("%d inserts; need %d" % (inserts, max(1, int(dur / 20.0))))
    if len(set(sc)) < 3:
        bad.append("only %d distinct locations in the film" % len(set(sc)))
    run = 1
    for i in range(1, len(sc)):
        same = (sc[i], fr[i]) == (sc[i - 1], fr[i - 1])
        run = run + 1 if same else 1
        if run >= 3:
            sid = shots[i].get("id") if shots else b.get("expanded_script", [{}])[i].get("shot")
            bad.append("%s: three in a row at the same place and size" % sid)

    # 32 — expanded script atom coverage
    for e in b.get("expanded_script") or []:
        missing = [a for a in ATOMS if not (e.get("atoms") or {}).get(a)]
        if missing:
            bad.append("%s missing atoms: %s" % (e.get("shot"), ", ".join(missing)))
        if not e.get("on_screen"):
            bad.append("%s has nothing on screen" % e.get("shot"))

    # 33 — cast / prop coherence
    for c in b.get("cast") or []:
        if c.get("location") not in {l["id"] for l in locs}:
            bad.append("cast %s placed outside the story's locations" % c.get("id"))
        for pid in c.get("props") or []:
            if pid not in {o["id"] for o in b.get("objects") or []}:
                warn.append("cast %s carries undeclared prop %s" % (c.get("id"), pid))

    for x in warn:
        print("warn:", x)
    for x in bad:
        print("FAIL:", x)
    print("%d locations · %d objects · %d shots · %d framings · %d inserts" %
          (len(locs), len(b.get("objects") or []), len(b.get("expanded_script") or []),
           len(set(fr)), inserts))
    print("PASS" if not bad else "%d failing" % len(bad))
    return 0 if not bad else 1


def main(argv=None):
    global LIB_PATH
    ap = argparse.ArgumentParser(description="elaborate a voiceover into an atom-level script")
    ap.add_argument("bible", nargs="?", help="story bible to validate in --check mode")
    ap.add_argument("--voice", help="the transcript / script seed")
    ap.add_argument("--words", default="build/words.json")
    ap.add_argument("--captions", default="build/captions.json")
    ap.add_argument("--audio", default="build/audio.json")
    ap.add_argument("--duration", type=float)
    ap.add_argument("--domain", help="force a domain instead of detecting it")
    ap.add_argument("--detail", type=int, choices=(1, 2, 3), default=3)
    ap.add_argument("--abstract", action="append", default=[],
                    help="a content word that is explicitly not a physical object")
    ap.add_argument("--out", default="build/story_bible.json")
    ap.add_argument("--check", action="store_true", help="validate an existing bible")
    ap.add_argument("--shotlist", default="build/shotlist.json")
    ap.add_argument("--anim", default="build/anim.json", help="motion contract for the prop-parenting check")
    ap.add_argument("--library", default=LIB_PATH, help="domain inventory JSON")
    args = ap.parse_args(argv)

    LIB_PATH = args.library
    lib = load_library()
    if args.check:
        return check_bible(args.bible or args.out, args.words, args.shotlist, lib, args.anim)

    bible = build_bible(args)
    obj_path, beat_path, md_path, place_path = write_outputs(bible, args)
    print("domain: %s  detail: %d" % (bible["domain"], bible["detail"]))
    print("locations: %s" % ", ".join(l["id"] for l in bible["locations"]))
    print("objects: %d  shots: %d  framings: %s" %
          (bible["coverage"]["objects"], bible["coverage"]["shots"],
           "/".join(sorted(set(e["framing"] for e in bible["expanded_script"])))))
    if bible["unclassified"]:
        print("warn: %d unclassified word(s): %s" %
              (len(bible["unclassified"]), ", ".join(bible["unclassified"][:12])))
    print("wrote %s, %s, %s, %s, %s" %
          (args.out, obj_path, beat_path, md_path, place_path))
    return 0


if __name__ == "__main__":
    sys.exit(main())
