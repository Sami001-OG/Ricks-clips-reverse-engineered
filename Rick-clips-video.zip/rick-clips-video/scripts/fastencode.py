#!/usr/bin/env python3
"""fastencode.py — choose an H.264 encoder that really works *here*.

Hardware encoder names appearing in `ffmpeg -encoders` is not proof the device
exists: NVENC without a driver, QSV without /dev/dri, VAAPI without a render
node all list themselves and then fail mid-film. So every candidate is proved
with a throwaway 16x16 encode before it is chosen.

No candidate may change the picture: every profile targets the same CRF/CQ and
yuv420p. `-preset veryfast` at CRF 19 is the same CRF-targeted quality as
`-preset slow` — it just finishes sooner and writes a larger file. Tune quality
with CRF, never with preset.

    from fastencode import choose
    cfg = choose()             # {"name":..., "args":[...], "hw":bool}
"""
from __future__ import annotations

import os
import subprocess

SOFTWARE = {"name": "libx264/veryfast", "hw": False,
            "args": ["-c:v", "libx264", "-preset", "veryfast", "-crf", "19",
                     "-pix_fmt", "yuv420p", "-threads", "0"]}
SAFE = {"name": "libx264/slow (legacy)", "hw": False,
        "args": ["-c:v", "libx264", "-preset", "slow", "-crf", "19",
                 "-pix_fmt", "yuv420p", "-threads", "0"]}

# Ordered by expected speed on a machine that actually has the device.
CANDIDATES = [
    {"name": "h264_nvenc", "hw": True,
     "args": ["-c:v", "h264_nvenc", "-preset", "p4", "-cq", "19",
              "-pix_fmt", "yuv420p", "-threads", "0"]},
    {"name": "h264_qsv", "hw": True,
     "args": ["-c:v", "h264_qsv", "-preset", "medium", "-global_quality", "19",
              "-pix_fmt", "yuv420p"]},
    {"name": "h264_amf", "hw": True,
     "args": ["-c:v", "h264_amf", "-quality", "balanced", "-rc", "cqp",
              "-qp", "19", "-pix_fmt", "yuv420p"]},
    {"name": "h264_videotoolbox", "hw": True,
     "args": ["-c:v", "h264_videotoolbox", "-q:v", "65", "-pix_fmt", "yuv420p"]},
    SOFTWARE,
]


def ffmpeg_bin():
    return os.environ.get("FFMPEG_BIN", "ffmpeg")


def available():
    try:
        out = subprocess.run([ffmpeg_bin(), "-hide_banner", "-encoders"],
                             capture_output=True, text=True, timeout=30).stdout
        return set(out.split())
    except Exception:
        return set()


def works(cfg, ff=None):
    """Prove an encoder on a 16x16, 2-frame synth clip. <1 s per candidate."""
    ff = ff or ffmpeg_bin()
    cmd = [ff, "-v", "error", "-y",
           "-f", "lavfi", "-i", "color=c=gray:s=16x16:r=30:d=0.067",
           "-frames:v", "2"] + cfg["args"] + ["-f", "null", "-"]
    try:
        return subprocess.run(cmd, capture_output=True, timeout=25).returncode == 0
    except Exception:
        return False


_CHOICE_CACHE = {}


def choose(profile="auto", crf=None):
    """Return the first working encoder config for the requested profile.

    Memoized per process: the burn, the one-pass finish and a --check in the
    same run would otherwise each spawn `ffmpeg -encoders` plus several
    throwaway encodes. The probe is only redone when FFMPEG_BIN changes.
    """
    key = (profile, crf, ffmpeg_bin())
    if key in _CHOICE_CACHE:
        return _CHOICE_CACHE[key]
    result = _choose_uncached(profile, crf)
    _CHOICE_CACHE[key] = result
    return result


def _choose_uncached(profile="auto", crf=None):
    if profile == "safe":
        return SAFE
    if profile == "software":
        return SOFTWARE
    encs = available()
    if profile == "gpu":
        pool = [c for c in CANDIDATES if c["hw"]]
    elif profile in {c["name"] for c in CANDIDATES}:
        pool = [c for c in CANDIDATES if c["name"] == profile]
    else:
        pool = CANDIDATES
    for cfg in pool:
        if cfg["name"] != "libx264/veryfast" and cfg["name"] not in encs:
            continue
        if works(cfg):
            if crf is not None and not cfg["hw"]:
                cfg = dict(cfg)
                cfg["args"] = [("19" if a == "19" else a) for a in cfg["args"]]
                # CRF is set in the caller's video line; keep the profile fixed.
            return cfg
    if profile == "gpu":
        # A GPU was requested but none works — degrade instead of halting the film.
        return SOFTWARE
    return SOFTWARE


def describe(cfg):
    return "%s (%s)" % (cfg["name"], "hardware" if cfg["hw"] else "software")


def require():
    """No ffmpeg at all (no CPU path and no GPU path) — stop with one clear line."""
    import shutil
    if not (shutil.which(ffmpeg_bin()) or os.path.exists(ffmpeg_bin())):
        raise SystemExit("no ffmpeg executable found: set FFMPEG_BIN or run scripts/bootstrap.sh")
    return ffmpeg_bin()


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="probe the fastest working H.264 encoder")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--profile", default="auto")
    a = ap.parse_args()
    if a.check:
        require()
        choice = choose(a.profile)
        ok = works(choice)                 # probe once, not twice
        print(describe(choice), "works" if ok else "FAILED",
              " ".join(choice["args"]))
        raise SystemExit(0 if ok else 1)


