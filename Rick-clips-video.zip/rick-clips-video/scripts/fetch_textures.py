#!/usr/bin/env python3
"""fetch_textures.py — cache the CC0 surface scans the plates are built from.

Photographic surfaces are what make a cheap raster plate read as a real set.
The files are CC0 (Poly Haven), fetched once, cached in assets/textures/, and
never needed again. Offline or blocked, this exits 0 and plate3d.py falls back
to procedural materials — the pipeline does not stall.

    python3 scripts/fetch_textures.py            # fetch what is missing
    python3 scripts/fetch_textures.py --list     # show the set
    python3 scripts/fetch_textures.py --check    # exit 1 if any file is missing

Each set is <id>_diffuse.jpg + <id>_nor_gl.jpg at 1K (1024 px). 1K tiled at
~1 m per repeat is ~1000 px/m at arm's length — enough for a background plate.
"""
import argparse
import json
import os
import sys
import urllib.request

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEST = os.path.join(ROOT, "assets", "textures")
API = "https://api.polyhaven.com/files/"
UA = {"User-Agent": "rick-clips-video/1.0 (plate texture cache)"}

SETS = {
    "rock_wall_08": "stone walls, tunnels, ruins",
    "cobblestone_floor_08": "ground, streets, yards",
    "dark_wooden_planks": "timber, crates, beams, carts",
    "green_metal_rust": "iron, rails, hardware, armour",
}
KINDS = (("Diffuse", "diffuse"), ("nor_gl", "nor_gl"))


def path(tid, kind):
    return os.path.join(DEST, "%s_%s.jpg" % (tid, kind))


def have(tid):
    """A cached file only counts if it is actually 1K — the bundled copies are
    512 px previews, so the documented 'upgrades to 1K' claim is now true."""
    from PIL import Image
    for _, kind in KINDS:
        f = path(tid, kind)
        if not os.path.exists(f):
            return False
        try:
            if min(Image.open(f).size) < 1024:
                return False
        except Exception:
            return False
    return True


def fetch(url, out):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=60) as r:
        data = r.read()
    with open(out, "wb") as f:
        f.write(data)
    return len(data)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--list", action="store_true")
    ap.add_argument("--check", action="store_true")
    ap.add_argument("--only", nargs="*", help="subset of set ids")
    args = ap.parse_args(argv)

    ids = args.only or list(SETS)
    if args.list:
        for k in ids:
            print("%-24s %-8s %s" % (k, "cached" if have(k) else "-", SETS.get(k, "")))
        return 0
    if args.check:
        missing = [k for k in ids if not have(k)]
        print("missing: %s" % (", ".join(missing) if missing else "none"))
        return 1 if missing else 0

    os.makedirs(DEST, exist_ok=True)
    got = miss = 0
    for tid in ids:
        if have(tid):
            continue
        try:
            meta = json.load(urllib.request.urlopen(
                urllib.request.Request(API + tid, headers=UA), timeout=60))
            for kind, suffix in KINDS:
                url = meta[kind]["1k"]["jpg"]["url"]
                n = fetch(url, path(tid, suffix))
                print("  %-42s %6.1f KB" % ("%s_%s.jpg" % (tid, suffix), n / 1024))
                got += 1
        except Exception as e:
            miss += 1
            print("  %-24s skipped (%s)" % (tid, str(e)[:60]))

    credits = ["# Surface textures", "",
               "CC0 (public domain), Poly Haven — https://polyhaven.com/textures", ""]
    for tid in ids:
        credits.append("- `%s` — %s" % (tid, SETS.get(tid, "")))
    open(os.path.join(DEST, "CREDITS.md"), "w").write("\n".join(credits) + "\n")

    if got:
        print("\ncached %d file(s) in %s" % (got, DEST))
    if miss:
        print("%d set(s) unavailable — plate3d.py will use procedural materials"
              % miss, file=sys.stderr)
    print("offline is fine: run continues with what is cached")
    return 0


if __name__ == "__main__":
    sys.exit(main())
