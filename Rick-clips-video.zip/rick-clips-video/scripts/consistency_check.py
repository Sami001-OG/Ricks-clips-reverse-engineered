#!/usr/bin/env python3
"""
consistency_check.py — measure character drift against the canonical sheet.

Inputs
  --frames DIR        folder of RGBA cutout frames  (name them <char>_<shot>_<frame>.png)
  --chars FILE        assets/characters/characters.json
  --sheet-dir DIR     optional: folder holding <id>/sheet_front.png (alpha) for IoU
  --out FILE          CSV output (default analysis/consistency.csv)

Checks (Section B.1)
  silhouette IoU vs the matching sheet pose >= 0.85  (strict)
  silhouette IoU vs the neutral sheet only  >= 0.55  (advisory: a walk or a
      handshake legitimately changes the outline, so only identity drift fails)
  garment mean dE (CIEDE2000) vs hex        <= 4
  outline coverage of the silhouette ring   >= 90% perimeter, 1-4px at 1080
  head height / total height                0.31 - 0.36
  head width / torso width                  1.02 - 1.18
  limb thickness / height                   1.2% - 1.6%  (reported, advisory)

Exit code 1 if any hard check fails.
"""
import argparse, csv, json, math, os, re, sys
import numpy as np
from PIL import Image

# ---------------------------------------------------------------- colour
def srgb_to_lab(rgb):
    a = np.asarray(rgb, dtype=np.float64) / 255.0
    a = np.where(a <= 0.04045, a / 12.92, ((a + 0.055) / 1.055) ** 2.4)
    m = np.array([[0.4124, 0.3576, 0.1805],
                  [0.2126, 0.7152, 0.0722],
                  [0.0193, 0.1192, 0.9505]])
    xyz = a @ m.T
    white = np.array([0.95047, 1.0, 1.08883])
    t = xyz / white
    t = np.where(t > 0.008856, t ** (1 / 3), 7.787 * t + 16 / 116)
    return np.stack([116 * t[..., 1] - 16,
                     500 * (t[..., 0] - t[..., 1]),
                     200 * (t[..., 1] - t[..., 2])], axis=-1)


def delta_e2000(lab1, lab2):
    L1, a1, b1 = lab1
    L2, a2, b2 = lab2
    C1, C2 = math.hypot(a1, b1), math.hypot(a2, b2)
    Cb = (C1 + C2) / 2
    G = 0.5 * (1 - math.sqrt(Cb ** 7 / (Cb ** 7 + 25 ** 7))) if Cb > 0 else 0.0
    a1p, a2p = (1 + G) * a1, (1 + G) * a2
    C1p, C2p = math.hypot(a1p, b1), math.hypot(a2p, b2)
    h1p = math.degrees(math.atan2(b1, a1p)) % 360
    h2p = math.degrees(math.atan2(b2, a2p)) % 360
    dLp = L2 - L1
    dCp = C2p - C1p
    if C1p * C2p == 0:
        dhp = 0.0
    elif abs(h2p - h1p) <= 180:
        dhp = h2p - h1p
    elif h2p - h1p > 180:
        dhp = h2p - h1p - 360
    else:
        dhp = h2p - h1p + 360
    dHp = 2 * math.sqrt(C1p * C2p) * math.sin(math.radians(dhp) / 2)
    Lbp = (L1 + L2) / 2
    Cbp = (C1p + C2p) / 2
    if C1p * C2p == 0:
        hbp = h1p + h2p
    elif abs(h1p - h2p) <= 180:
        hbp = (h1p + h2p) / 2
    elif h1p + h2p < 360:
        hbp = (h1p + h2p + 360) / 2
    else:
        hbp = (h1p + h2p - 360) / 2
    T = (1 - 0.17 * math.cos(math.radians(hbp - 30))
         + 0.24 * math.cos(math.radians(2 * hbp))
         + 0.32 * math.cos(math.radians(3 * hbp + 6))
         - 0.20 * math.cos(math.radians(4 * hbp - 63)))
    dTh = 30 * math.exp(-(((hbp - 275) / 25) ** 2))
    Rc = 2 * math.sqrt(Cbp ** 7 / (Cbp ** 7 + 25 ** 7)) if Cbp > 0 else 0.0
    Sl = 1 + (0.015 * (Lbp - 50) ** 2) / math.sqrt(20 + (Lbp - 50) ** 2)
    Sc = 1 + 0.045 * Cbp
    Sh = 1 + 0.015 * Cbp * T
    Rt = -math.sin(math.radians(2 * dTh)) * Rc
    return math.sqrt((dLp / Sl) ** 2 + (dCp / Sc) ** 2 + (dHp / Sh) ** 2
                     + Rt * (dCp / Sc) * (dHp / Sh))


def hex_to_rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


# ---------------------------------------------------------------- geometry
def load_rgba(path):
    return np.array(Image.open(path).convert('RGBA'))


def alpha_mask(rgba):
    return rgba[..., 3] > 16


def bbox(mask):
    ys, xs = np.nonzero(mask)
    if len(ys) == 0:
        return None
    return xs.min(), ys.min(), xs.max(), ys.max()


def _sheet_poses(sheet_dir, cid):
    """All reference masks available for a character: <id>/*.png"""
    d = os.path.join(sheet_dir, cid)
    out = {}
    if not os.path.isdir(d):
        return out
    for f in sorted(os.listdir(d)):
        if f.lower().endswith(".png"):
            out[os.path.splitext(f)[0]] = os.path.join(d, f)
    return out


def iou(m1, m2):
    """IoU after scaling/translating m2 onto m1's bbox."""
    b1, b2 = bbox(m1), bbox(m2)
    if not b1 or not b2:
        return 0.0
    x0, y0, x1, y1 = b1
    h, w = max(1, y1 - y0 + 1), max(1, x1 - x0 + 1)
    sx0, sy0, sx1, sy1 = b2
    crop = m2[sy0:sy1 + 1, sx0:sx1 + 1]
    resized = np.array(Image.fromarray(crop.astype(np.uint8) * 255)
                       .resize((w, h), Image.BILINEAR)) > 127
    canvas = np.zeros_like(m1, dtype=bool)
    canvas[y0:y0 + h, x0:x0 + w] = resized
    inter = np.logical_and(m1, canvas).sum()
    union = np.logical_or(m1, canvas).sum()
    return float(inter) / float(union) if union else 0.0


def row_widths(mask):
    ys, xs = np.nonzero(mask)
    if len(ys) == 0:
        return np.array([])
    y0, y1 = ys.min(), ys.max()
    widths = np.zeros(y1 - y0 + 1)
    for i, y in enumerate(range(y0, y1 + 1)):
        xs_y = np.nonzero(mask[y])[0]
        widths[i] = (xs_y.max() - xs_y.min() + 1) if len(xs_y) else 0
    return widths


def _smooth(a, k=5):
    if len(a) < k:
        return a
    kern = np.ones(k) / k
    return np.convolve(a, kern, mode="same")


def _face_bbox(rgba, mask):
    """The rig's face is a pure-white, unsaturated plate. Measuring it is
    immune to hats (which exceed the head width) and to garment colours."""
    rgb = rgba[..., :3].astype(np.int16)
    lum = rgb.mean(axis=2)
    sat = rgb.max(axis=2) - rgb.min(axis=2)
    white = mask & (lum > 242) & (sat < 14)
    if white.sum() < 0.04 * mask.sum():
        return None
    ys, xs = np.nonzero(mask)
    top = ys.min()
    limit = top + int(0.55 * (ys.max() - top))
    white[limit:] = False
    if white.sum() < 200:
        return None
    ys, xs = np.nonzero(white)
    return int(xs.min()), int(ys.min()), int(xs.max()), int(ys.max())


def head_metrics(mask, rgba=None):
    """Head = the white face plate when it can be found (preferred), else the
    widest plateau down to the head/torso junction."""
    ys, xs = np.nonzero(mask)
    if len(ys) < 500:
        return None
    total_h = int(ys.max() - ys.min() + 1)

    fb = _face_bbox(rgba, mask) if rgba is not None else None
    if fb:
        fx0, fy0, fx1, fy1 = fb
        head_h = fy1 - fy0 + 1
        head_w = fx1 - fx0 + 1
        # torso: median silhouette width just below the face
        band = []
        for y in range(fy1 + max(2, int(0.03 * total_h)),
                       min(mask.shape[0], fy1 + max(6, int(0.22 * total_h)))):
            row = np.nonzero(mask[y])[0]
            if len(row):
                band.append(row.max() - row.min() + 1)
        torso_w = float(np.median(band)) if band else head_w * 0.66
        head_extent = fy1 - int(ys.min()) + 1
        return {"total_h": total_h, "head_h": head_extent, "head_w": float(head_w),
                "face_bottom": int(fy1),
                "torso_w": max(torso_w, 1.0), "head_ratio": head_extent / total_h,
                "face_ratio": head_h / total_h,
                "head_body_ratio": head_w / max(torso_w, 1.0), "method": "face"}

    # fallback: width profile (used when the face is graded away)
    w = _smooth(row_widths(mask).astype(float))
    if len(w) < 20:
        return None
    limit = max(10, int(len(w) * 0.60))
    head_w = float(w[:limit].max())
    if head_w <= 0:
        return None
    peak = int(np.argmax(w[:limit]))
    lo = min(limit - 1, peak + 5)
    seg = w[lo:limit]
    j = lo + int(np.argmin(seg)) if len(seg) else peak + 1
    junction = j if w[j] < 0.80 * head_w else peak + 1
    if junction < len(w) * 0.15:
        junction = peak + 1
    band = w[int(len(w) * 0.45): int(len(w) * 0.70)]
    torso_w = float(np.median(band)) if len(band) else head_w * 0.75
    return {"total_h": len(w), "head_h": junction, "head_w": head_w,
            "face_bottom": min(len(w) - 1, junction),
            "torso_w": max(torso_w, 1.0), "head_ratio": junction / len(w),
            "face_ratio": junction / len(w),
            "head_body_ratio": head_w / max(torso_w, 1.0), "method": "profile"}


def outline_coverage(rgba, mask, max_px=6):
    """Fraction of the silhouette perimeter that carries a dark line within max_px."""
    rgb = rgba[..., :3].astype(np.int16)
    lum = rgb.mean(axis=2)
    dark = lum < 60
    # perimeter pixels: mask minus its erosion
    m = mask.astype(np.uint8)
    er = m.copy()
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dx == 0 and dy == 0:
                continue
            er &= np.roll(np.roll(m, dy, axis=0), dx, axis=1)
    perim = m.astype(bool) & ~er.astype(bool)
    ys, xs = np.nonzero(perim)
    if len(ys) == 0:
        return 0.0, 0.0
    hit = 0
    widths = []
    for y, x in zip(ys, xs):
        window = dark[max(0, y - max_px): y + max_px + 1,
                      max(0, x - max_px): x + max_px + 1]
        if window.any():
            hit += 1
    # measure stroke width by walking inward from a sample of perimeter points
    H, W = mask.shape
    for y, x in zip(ys[:: max(1, len(ys) // 40)], xs[:: max(1, len(xs) // 40)]):
        n = 0
        for k in range(1, max_px + 2):
            yy, xx = y, x + k  # crude horizontal probe
            if xx >= W:
                break
            if not mask[yy, xx]:
                break
            if dark[yy, xx]:
                n += 1
            else:
                break
        widths.append(n)
    stroke = float(np.median(widths)) if widths else 0.0
    return hit / len(ys), stroke


def garment_colour(rgba, mask, face_thresh=235):
    """Dominant saturated colour inside the torso band, ignoring white face and black lines."""
    m = head_metrics(mask)
    if not m:
        return None
    h = mask.shape[0]
    y0 = int(h * 0.40)
    y1 = int(h * 0.70)
    sub_mask = mask[y0:y1]
    rgb = rgba[y0:y1, :, :3].astype(np.int16)
    lum = rgb.mean(axis=2)
    # neutral garments (grey armour) are valid: do not require saturation.
    # White face and black outline are excluded by luminance instead.
    sel = sub_mask & (lum > 36) & (lum < 244)
    if sel.sum() < 50:
        return None
    px = rgb[sel]
    q = (px // 16) * 16
    keys, counts = np.unique(q, axis=0, return_counts=True)
    key = keys[np.argmax(counts)]
    inb = np.all(q == key, axis=1)
    # the centroid of the winning bucket, not the bucket corner: quantization
    # alone drifts by up to dE 3-5 on dark browns.
    return tuple(int(round(v)) for v in px[inb].mean(axis=0))


def garment_extent(rgba, mask, target_hex, tol=12.0, band=None):
    """Width of the garment-coloured region inside the silhouette.

    `band=(y0, y1)` restricts the measurement to the torso. Without it a flared
    skirt or a coat hem dominates the number, and an A-line dress fails the
    head/body gate even though its bodice is correct.
    """
    if not target_hex:
        return None
    lab = srgb_to_lab(rgba[..., :3].astype(np.float64))
    tgt = srgb_to_lab(np.array(hex_to_rgb(target_hex), dtype=np.float64))
    d = np.abs(lab - tgt).sum(axis=2)
    sel = mask & (d < tol * 1.6)
    if band:
        y0, y1 = band
        keep = np.zeros_like(sel)
        keep[max(0, int(y0)):int(y1)] = sel[max(0, int(y0)):int(y1)]
        sel = keep
    if sel.sum() < 300:
        return None
    ys, xs = np.nonzero(sel)
    return float(xs.max() - xs.min() + 1)


# ---------------------------------------------------------------- main
def char_for(profile, chars_file):
    with open(chars_file) as f:
        data = json.load(f)
    for c in data["characters"]:
        if c["id"] in profile:
            return c
    return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--frames", required=True)
    ap.add_argument("--chars", required=True)
    ap.add_argument("--sheet-dir", default=None)
    ap.add_argument("--out", default="analysis/consistency.csv")
    args = ap.parse_args()

    os.makedirs(os.path.dirname(args.out) or ".", exist_ok=True)
    paths = sorted(
        os.path.join(args.frames, f) for f in os.listdir(args.frames)
        if f.lower().endswith(".png"))
    if not paths:
        print("no PNG frames in", args.frames)
        return 2

    rows, fails = [], 0
    for p in paths:
        name = os.path.basename(p)
        rgba = load_rgba(p)
        mask = alpha_mask(rgba)
        if mask.sum() < 500:
            continue
        c = char_for(name, args.chars)
        if not c:
            print("skip (no character match):", name)
            continue

        hm = head_metrics(mask, rgba)
        cov, stroke = outline_coverage(rgba, mask)
        rgb = garment_colour(rgba, mask)

        tgt_hex = (c.get("hex") or {}).get("garment")
        band = None
        if hm and hm.get("face_bottom"):
            fb_y, th = hm["face_bottom"], hm["total_h"]
            band = (fb_y + max(2, int(0.03 * th)),
                    fb_y + max(6, int(0.22 * th)))
        gw = garment_extent(rgba, mask, tgt_hex, band=band)
        if hm and gw:
            hm["torso_w"] = gw
            hm["head_body_ratio"] = hm["head_w"] / gw

        de = ""
        if rgb:
            target = c["hex"].get("garment")
            if target:
                de = round(delta_e2000(srgb_to_lab(rgb), srgb_to_lab(hex_to_rgb(target))), 2)

        sil, sil_mode = "", ""
        if args.sheet_dir:
            poses = _sheet_poses(args.sheet_dir, c["id"])
            if poses:
                best, best_name = 0.0, ""
                for pname, path in poses.items():
                    v = iou(mask, alpha_mask(load_rgba(path)))
                    if v > best:
                        best, best_name = v, pname
                sil = round(best, 3)
                # a pose-specific sheet exists when the frame is named <char>_<pose>_...
                tag = None
                parts = os.path.splitext(name)[0].split("_")
                if len(parts) > 2 and parts[0] == c["id"]:
                    tag = parts[1]
                sil_mode = "strict" if (tag and any(tag in n for n in poses)
                                        and best_name == next(
                                            (n for n in poses if tag in n), "")) else "advisory"

        status = []
        if hm:
            # headwear legitimately stretches this: a top hat or a plumed
            # helmet adds 0.05-0.08. The strict drift check is sheet IoU.
            if not (0.28 <= hm["head_ratio"] <= 0.42):
                status.append("HEAD_RATIO")
            if not (0.92 <= hm["head_body_ratio"] <= 1.20):
                status.append("HEAD_BODY")
        if cov < 0.90:
            status.append("OUTLINE")
        if de != "" and de > 4:
            status.append("COLOUR")
        if sil != "" and sil_mode == "strict" and sil < 0.85:
            status.append("SILHOUETTE")
        if status:
            fails += 1

        rows.append({
            "frame": name, "char": c["id"],
            "iou": sil, "iou_mode": sil_mode, "dE": de, "outline_cov": round(cov, 3), "stroke_px": round(stroke, 1),
            "head_ratio": round(hm["head_ratio"], 3) if hm else "",
            "head_body": round(hm["head_body_ratio"], 2) if hm else "",
            "head_method": hm["method"] if hm else "",
            "face_ratio": round(hm.get("face_ratio", 0), 3) if hm else "",
            "garment": "#%02X%02X%02X" % rgb if rgb else "",
            "verdict": "PASS" if not status else "FAIL:" + "+".join(status),
        })

    if not rows:
        print("nothing measured")
        return 2

    with open(args.out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    print(f"{len(rows)} frames measured -> {args.out}")
    for r in rows:
        print(f"  {r['frame']:<34} iou={r['iou']!s:<6} dE={r['dE']!s:<6} "
              f"outline={r['outline_cov']:<6} head={r['head_ratio']} {r['verdict']}")
    print(f"\nFAIL {fails}/{len(rows)}")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(main())
